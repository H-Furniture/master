﻿
namespace HomeFurniture
{
    partial class frmCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcOne = new System.Windows.Forms.TabControl();
            this.tabCustomerInformation = new System.Windows.Forms.TabPage();
            this.btnCancelCust = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlOne = new System.Windows.Forms.Panel();
            this.lblCustID = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lblCustPostalCode = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lblCustUserID = new System.Windows.Forms.Label();
            this.lblCustFax = new System.Windows.Forms.Label();
            this.lblCustFName = new System.Windows.Forms.Label();
            this.lblCustCountry = new System.Windows.Forms.Label();
            this.lblCustLName = new System.Windows.Forms.Label();
            this.lblCustCity = new System.Windows.Forms.Label();
            this.lblCustPhone = new System.Windows.Forms.Label();
            this.lblCustAddress = new System.Windows.Forms.Label();
            this.btnLogout1 = new System.Windows.Forms.Button();
            this.btnSaveCust = new System.Windows.Forms.Button();
            this.btnEditCust = new System.Windows.Forms.Button();
            this.tabCustomerOrders = new System.Windows.Forms.TabPage();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lblOrderEmployeeID = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lblTotalPrice = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lblProducts = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lblOrderPostalCode = new System.Windows.Forms.Label();
            this.lblOrderCustID = new System.Windows.Forms.Label();
            this.lblShippedCountry = new System.Windows.Forms.Label();
            this.lblOrderDate = new System.Windows.Forms.Label();
            this.lblShippedCity = new System.Windows.Forms.Label();
            this.lblShippedDate = new System.Windows.Forms.Label();
            this.lblShippedAddress = new System.Windows.Forms.Label();
            this.btnLogin2 = new System.Windows.Forms.Button();
            this.btnNextOrder = new System.Windows.Forms.Button();
            this.btnPreviousOrder = new System.Windows.Forms.Button();
            this.btnDeleteOrder = new System.Windows.Forms.Button();
            this.tbcOne.SuspendLayout();
            this.tabCustomerInformation.SuspendLayout();
            this.pnlOne.SuspendLayout();
            this.tabCustomerOrders.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcOne
            // 
            this.tbcOne.Controls.Add(this.tabCustomerInformation);
            this.tbcOne.Controls.Add(this.tabCustomerOrders);
            this.tbcOne.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcOne.Location = new System.Drawing.Point(0, 0);
            this.tbcOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbcOne.Multiline = true;
            this.tbcOne.Name = "tbcOne";
            this.tbcOne.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tbcOne.SelectedIndex = 0;
            this.tbcOne.Size = new System.Drawing.Size(753, 625);
            this.tbcOne.TabIndex = 0;
            // 
            // tabCustomerInformation
            // 
            this.tabCustomerInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerInformation.Controls.Add(this.btnCancelCust);
            this.tabCustomerInformation.Controls.Add(this.lblTitle);
            this.tabCustomerInformation.Controls.Add(this.pnlOne);
            this.tabCustomerInformation.Controls.Add(this.btnLogout1);
            this.tabCustomerInformation.Controls.Add(this.btnSaveCust);
            this.tabCustomerInformation.Controls.Add(this.btnEditCust);
            this.tabCustomerInformation.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCustomerInformation.Location = new System.Drawing.Point(4, 26);
            this.tabCustomerInformation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabCustomerInformation.Name = "tabCustomerInformation";
            this.tabCustomerInformation.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabCustomerInformation.Size = new System.Drawing.Size(745, 595);
            this.tabCustomerInformation.TabIndex = 0;
            this.tabCustomerInformation.Text = "Customer Information";
            // 
            // btnCancelCust
            // 
            this.btnCancelCust.BackColor = System.Drawing.Color.Beige;
            this.btnCancelCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelCust.Location = new System.Drawing.Point(375, 454);
            this.btnCancelCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancelCust.Name = "btnCancelCust";
            this.btnCancelCust.Size = new System.Drawing.Size(161, 46);
            this.btnCancelCust.TabIndex = 4;
            this.btnCancelCust.Text = "Cancel";
            this.btnCancelCust.UseVisualStyleBackColor = false;
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Copperplate Gothic Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(103, 24);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(537, 44);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Customer Information";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlOne
            // 
            this.pnlOne.BackColor = System.Drawing.Color.Beige;
            this.pnlOne.Controls.Add(this.lblCustID);
            this.pnlOne.Controls.Add(this.lbl1);
            this.pnlOne.Controls.Add(this.lbl2);
            this.pnlOne.Controls.Add(this.lbl3);
            this.pnlOne.Controls.Add(this.lbl4);
            this.pnlOne.Controls.Add(this.lbl5);
            this.pnlOne.Controls.Add(this.lbl6);
            this.pnlOne.Controls.Add(this.lbl7);
            this.pnlOne.Controls.Add(this.lbl8);
            this.pnlOne.Controls.Add(this.lbl9);
            this.pnlOne.Controls.Add(this.lblCustPostalCode);
            this.pnlOne.Controls.Add(this.lbl10);
            this.pnlOne.Controls.Add(this.lblCustUserID);
            this.pnlOne.Controls.Add(this.lblCustFax);
            this.pnlOne.Controls.Add(this.lblCustFName);
            this.pnlOne.Controls.Add(this.lblCustCountry);
            this.pnlOne.Controls.Add(this.lblCustLName);
            this.pnlOne.Controls.Add(this.lblCustCity);
            this.pnlOne.Controls.Add(this.lblCustPhone);
            this.pnlOne.Controls.Add(this.lblCustAddress);
            this.pnlOne.Location = new System.Drawing.Point(103, 70);
            this.pnlOne.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlOne.Name = "pnlOne";
            this.pnlOne.Size = new System.Drawing.Size(537, 313);
            this.pnlOne.TabIndex = 1;
            // 
            // lblCustID
            // 
            this.lblCustID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustID.Location = new System.Drawing.Point(149, 15);
            this.lblCustID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustID.Name = "lblCustID";
            this.lblCustID.Size = new System.Drawing.Size(367, 28);
            this.lblCustID.TabIndex = 1;
            this.lblCustID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl1
            // 
            this.lbl1.Location = new System.Drawing.Point(20, 15);
            this.lbl1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(121, 28);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Customer ID:";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl2
            // 
            this.lbl2.Location = new System.Drawing.Point(20, 43);
            this.lbl2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(121, 28);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "First Name:";
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl3
            // 
            this.lbl3.Location = new System.Drawing.Point(20, 71);
            this.lbl3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(121, 28);
            this.lbl3.TabIndex = 4;
            this.lbl3.Text = "Last Name:";
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl4
            // 
            this.lbl4.Location = new System.Drawing.Point(20, 100);
            this.lbl4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(121, 28);
            this.lbl4.TabIndex = 6;
            this.lbl4.Text = "Phone Number:";
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl5
            // 
            this.lbl5.Location = new System.Drawing.Point(20, 128);
            this.lbl5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(121, 28);
            this.lbl5.TabIndex = 8;
            this.lbl5.Text = "Address:";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl6
            // 
            this.lbl6.Location = new System.Drawing.Point(20, 156);
            this.lbl6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(121, 28);
            this.lbl6.TabIndex = 10;
            this.lbl6.Text = "City:";
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl7
            // 
            this.lbl7.Location = new System.Drawing.Point(20, 185);
            this.lbl7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(121, 28);
            this.lbl7.TabIndex = 12;
            this.lbl7.Text = "Country:";
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl8
            // 
            this.lbl8.Location = new System.Drawing.Point(20, 213);
            this.lbl8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(121, 28);
            this.lbl8.TabIndex = 14;
            this.lbl8.Text = "Fax:";
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl9
            // 
            this.lbl9.Location = new System.Drawing.Point(20, 241);
            this.lbl9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(121, 28);
            this.lbl9.TabIndex = 16;
            this.lbl9.Text = "User ID:";
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCustPostalCode
            // 
            this.lblCustPostalCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustPostalCode.Location = new System.Drawing.Point(149, 270);
            this.lblCustPostalCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustPostalCode.Name = "lblCustPostalCode";
            this.lblCustPostalCode.Size = new System.Drawing.Size(367, 28);
            this.lblCustPostalCode.TabIndex = 19;
            this.lblCustPostalCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl10
            // 
            this.lbl10.Location = new System.Drawing.Point(20, 270);
            this.lbl10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(121, 28);
            this.lbl10.TabIndex = 18;
            this.lbl10.Text = "Postal Code:";
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCustUserID
            // 
            this.lblCustUserID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustUserID.Location = new System.Drawing.Point(149, 241);
            this.lblCustUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustUserID.Name = "lblCustUserID";
            this.lblCustUserID.Size = new System.Drawing.Size(367, 28);
            this.lblCustUserID.TabIndex = 17;
            this.lblCustUserID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustFax
            // 
            this.lblCustFax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustFax.Location = new System.Drawing.Point(149, 213);
            this.lblCustFax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustFax.Name = "lblCustFax";
            this.lblCustFax.Size = new System.Drawing.Size(367, 28);
            this.lblCustFax.TabIndex = 15;
            this.lblCustFax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustFName
            // 
            this.lblCustFName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustFName.Location = new System.Drawing.Point(149, 43);
            this.lblCustFName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustFName.Name = "lblCustFName";
            this.lblCustFName.Size = new System.Drawing.Size(367, 28);
            this.lblCustFName.TabIndex = 3;
            this.lblCustFName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustCountry
            // 
            this.lblCustCountry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustCountry.Location = new System.Drawing.Point(149, 185);
            this.lblCustCountry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustCountry.Name = "lblCustCountry";
            this.lblCustCountry.Size = new System.Drawing.Size(367, 28);
            this.lblCustCountry.TabIndex = 13;
            this.lblCustCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustLName
            // 
            this.lblCustLName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustLName.Location = new System.Drawing.Point(149, 71);
            this.lblCustLName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustLName.Name = "lblCustLName";
            this.lblCustLName.Size = new System.Drawing.Size(367, 28);
            this.lblCustLName.TabIndex = 5;
            this.lblCustLName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustCity
            // 
            this.lblCustCity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustCity.Location = new System.Drawing.Point(149, 156);
            this.lblCustCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustCity.Name = "lblCustCity";
            this.lblCustCity.Size = new System.Drawing.Size(367, 28);
            this.lblCustCity.TabIndex = 11;
            this.lblCustCity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustPhone
            // 
            this.lblCustPhone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustPhone.Location = new System.Drawing.Point(149, 100);
            this.lblCustPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustPhone.Name = "lblCustPhone";
            this.lblCustPhone.Size = new System.Drawing.Size(367, 28);
            this.lblCustPhone.TabIndex = 7;
            this.lblCustPhone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCustAddress
            // 
            this.lblCustAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustAddress.Location = new System.Drawing.Point(149, 128);
            this.lblCustAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustAddress.Name = "lblCustAddress";
            this.lblCustAddress.Size = new System.Drawing.Size(367, 28);
            this.lblCustAddress.TabIndex = 9;
            this.lblCustAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLogout1
            // 
            this.btnLogout1.BackColor = System.Drawing.Color.Beige;
            this.btnLogout1.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout1.Location = new System.Drawing.Point(11, 526);
            this.btnLogout1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogout1.Name = "btnLogout1";
            this.btnLogout1.Size = new System.Drawing.Size(161, 46);
            this.btnLogout1.TabIndex = 5;
            this.btnLogout1.Text = "Return to Login";
            this.btnLogout1.UseVisualStyleBackColor = false;
            // 
            // btnSaveCust
            // 
            this.btnSaveCust.BackColor = System.Drawing.Color.Beige;
            this.btnSaveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCust.Location = new System.Drawing.Point(205, 454);
            this.btnSaveCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSaveCust.Name = "btnSaveCust";
            this.btnSaveCust.Size = new System.Drawing.Size(161, 46);
            this.btnSaveCust.TabIndex = 3;
            this.btnSaveCust.Text = "Save";
            this.btnSaveCust.UseVisualStyleBackColor = false;
            // 
            // btnEditCust
            // 
            this.btnEditCust.BackColor = System.Drawing.Color.Beige;
            this.btnEditCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditCust.Location = new System.Drawing.Point(291, 389);
            this.btnEditCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEditCust.Name = "btnEditCust";
            this.btnEditCust.Size = new System.Drawing.Size(161, 46);
            this.btnEditCust.TabIndex = 2;
            this.btnEditCust.Text = "Change Information";
            this.btnEditCust.UseVisualStyleBackColor = false;
            // 
            // tabCustomerOrders
            // 
            this.tabCustomerOrders.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerOrders.Controls.Add(this.lblTitle2);
            this.tabCustomerOrders.Controls.Add(this.panel1);
            this.tabCustomerOrders.Controls.Add(this.btnLogin2);
            this.tabCustomerOrders.Controls.Add(this.btnNextOrder);
            this.tabCustomerOrders.Controls.Add(this.btnPreviousOrder);
            this.tabCustomerOrders.Controls.Add(this.btnDeleteOrder);
            this.tabCustomerOrders.Location = new System.Drawing.Point(4, 26);
            this.tabCustomerOrders.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabCustomerOrders.Name = "tabCustomerOrders";
            this.tabCustomerOrders.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabCustomerOrders.Size = new System.Drawing.Size(745, 595);
            this.tabCustomerOrders.TabIndex = 1;
            this.tabCustomerOrders.Text = "Customer Orders";
            // 
            // lblTitle2
            // 
            this.lblTitle2.Font = new System.Drawing.Font("Copperplate Gothic Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle2.Location = new System.Drawing.Point(143, 12);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(456, 44);
            this.lblTitle2.TabIndex = 3;
            this.lblTitle2.Text = "View Orders";
            this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Beige;
            this.panel1.Controls.Add(this.lblOrderID);
            this.panel1.Controls.Add(this.lbl12);
            this.panel1.Controls.Add(this.lbl13);
            this.panel1.Controls.Add(this.lbl14);
            this.panel1.Controls.Add(this.lbl15);
            this.panel1.Controls.Add(this.lbl16);
            this.panel1.Controls.Add(this.lbl17);
            this.panel1.Controls.Add(this.lbl18);
            this.panel1.Controls.Add(this.lbl19);
            this.panel1.Controls.Add(this.lblOrderEmployeeID);
            this.panel1.Controls.Add(this.lbl20);
            this.panel1.Controls.Add(this.lblTotalPrice);
            this.panel1.Controls.Add(this.lbl21);
            this.panel1.Controls.Add(this.lblProducts);
            this.panel1.Controls.Add(this.lbl22);
            this.panel1.Controls.Add(this.lblOrderPostalCode);
            this.panel1.Controls.Add(this.lblOrderCustID);
            this.panel1.Controls.Add(this.lblShippedCountry);
            this.panel1.Controls.Add(this.lblOrderDate);
            this.panel1.Controls.Add(this.lblShippedCity);
            this.panel1.Controls.Add(this.lblShippedDate);
            this.panel1.Controls.Add(this.lblShippedAddress);
            this.panel1.Location = new System.Drawing.Point(143, 59);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(456, 394);
            this.panel1.TabIndex = 40;
            // 
            // lblOrderID
            // 
            this.lblOrderID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderID.Location = new System.Drawing.Point(145, 12);
            this.lblOrderID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(296, 28);
            this.lblOrderID.TabIndex = 23;
            this.lblOrderID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl12
            // 
            this.lbl12.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.Location = new System.Drawing.Point(16, 12);
            this.lbl12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(121, 28);
            this.lbl12.TabIndex = 22;
            this.lbl12.Text = "Order ID:";
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl13
            // 
            this.lbl13.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.Location = new System.Drawing.Point(16, 41);
            this.lbl13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(121, 28);
            this.lbl13.TabIndex = 24;
            this.lbl13.Text = "Customer ID:";
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl14
            // 
            this.lbl14.Location = new System.Drawing.Point(16, 69);
            this.lbl14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(121, 28);
            this.lbl14.TabIndex = 26;
            this.lbl14.Text = "Order Date:";
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl15
            // 
            this.lbl15.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.Location = new System.Drawing.Point(16, 97);
            this.lbl15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(121, 28);
            this.lbl15.TabIndex = 28;
            this.lbl15.Text = "Shipped Date:";
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl16
            // 
            this.lbl16.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl16.Location = new System.Drawing.Point(16, 126);
            this.lbl16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(121, 28);
            this.lbl16.TabIndex = 30;
            this.lbl16.Text = "Shipped Address:";
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl17
            // 
            this.lbl17.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17.Location = new System.Drawing.Point(16, 154);
            this.lbl17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(121, 28);
            this.lbl17.TabIndex = 32;
            this.lbl17.Text = "Shipped City:";
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl18
            // 
            this.lbl18.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl18.Location = new System.Drawing.Point(16, 182);
            this.lbl18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(121, 28);
            this.lbl18.TabIndex = 34;
            this.lbl18.Text = "Shipped Country:";
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl19
            // 
            this.lbl19.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl19.Location = new System.Drawing.Point(16, 210);
            this.lbl19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(121, 28);
            this.lbl19.TabIndex = 36;
            this.lbl19.Text = "Postal Code:";
            this.lbl19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblOrderEmployeeID
            // 
            this.lblOrderEmployeeID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderEmployeeID.Location = new System.Drawing.Point(145, 353);
            this.lblOrderEmployeeID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderEmployeeID.Name = "lblOrderEmployeeID";
            this.lblOrderEmployeeID.Size = new System.Drawing.Size(296, 28);
            this.lblOrderEmployeeID.TabIndex = 43;
            this.lblOrderEmployeeID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl20
            // 
            this.lbl20.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl20.Location = new System.Drawing.Point(16, 239);
            this.lbl20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(121, 86);
            this.lbl20.TabIndex = 38;
            this.lbl20.Text = "Products:";
            this.lbl20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotalPrice
            // 
            this.lblTotalPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalPrice.Location = new System.Drawing.Point(145, 325);
            this.lblTotalPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalPrice.Name = "lblTotalPrice";
            this.lblTotalPrice.Size = new System.Drawing.Size(296, 28);
            this.lblTotalPrice.TabIndex = 41;
            this.lblTotalPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl21
            // 
            this.lbl21.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.Location = new System.Drawing.Point(16, 325);
            this.lbl21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(121, 28);
            this.lbl21.TabIndex = 40;
            this.lbl21.Text = "Total Price:";
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProducts
            // 
            this.lblProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblProducts.Location = new System.Drawing.Point(145, 239);
            this.lblProducts.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProducts.Name = "lblProducts";
            this.lblProducts.Size = new System.Drawing.Size(296, 86);
            this.lblProducts.TabIndex = 39;
            this.lblProducts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl22
            // 
            this.lbl22.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.Location = new System.Drawing.Point(16, 353);
            this.lbl22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(121, 28);
            this.lbl22.TabIndex = 42;
            this.lbl22.Text = "Employee ID:";
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblOrderPostalCode
            // 
            this.lblOrderPostalCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderPostalCode.Location = new System.Drawing.Point(145, 210);
            this.lblOrderPostalCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderPostalCode.Name = "lblOrderPostalCode";
            this.lblOrderPostalCode.Size = new System.Drawing.Size(296, 28);
            this.lblOrderPostalCode.TabIndex = 37;
            this.lblOrderPostalCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrderCustID
            // 
            this.lblOrderCustID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderCustID.Location = new System.Drawing.Point(145, 41);
            this.lblOrderCustID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderCustID.Name = "lblOrderCustID";
            this.lblOrderCustID.Size = new System.Drawing.Size(296, 28);
            this.lblOrderCustID.TabIndex = 25;
            this.lblOrderCustID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblShippedCountry
            // 
            this.lblShippedCountry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShippedCountry.Location = new System.Drawing.Point(145, 182);
            this.lblShippedCountry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShippedCountry.Name = "lblShippedCountry";
            this.lblShippedCountry.Size = new System.Drawing.Size(296, 28);
            this.lblShippedCountry.TabIndex = 35;
            this.lblShippedCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrderDate
            // 
            this.lblOrderDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderDate.Location = new System.Drawing.Point(145, 69);
            this.lblOrderDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderDate.Name = "lblOrderDate";
            this.lblOrderDate.Size = new System.Drawing.Size(296, 28);
            this.lblOrderDate.TabIndex = 27;
            this.lblOrderDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblShippedCity
            // 
            this.lblShippedCity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShippedCity.Location = new System.Drawing.Point(145, 154);
            this.lblShippedCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShippedCity.Name = "lblShippedCity";
            this.lblShippedCity.Size = new System.Drawing.Size(296, 28);
            this.lblShippedCity.TabIndex = 33;
            this.lblShippedCity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblShippedDate
            // 
            this.lblShippedDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShippedDate.Location = new System.Drawing.Point(145, 97);
            this.lblShippedDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShippedDate.Name = "lblShippedDate";
            this.lblShippedDate.Size = new System.Drawing.Size(296, 28);
            this.lblShippedDate.TabIndex = 29;
            this.lblShippedDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblShippedAddress
            // 
            this.lblShippedAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShippedAddress.Location = new System.Drawing.Point(145, 126);
            this.lblShippedAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShippedAddress.Name = "lblShippedAddress";
            this.lblShippedAddress.Size = new System.Drawing.Size(296, 28);
            this.lblShippedAddress.TabIndex = 31;
            this.lblShippedAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLogin2
            // 
            this.btnLogin2.BackColor = System.Drawing.Color.Beige;
            this.btnLogin2.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin2.Location = new System.Drawing.Point(291, 536);
            this.btnLogin2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogin2.Name = "btnLogin2";
            this.btnLogin2.Size = new System.Drawing.Size(161, 46);
            this.btnLogin2.TabIndex = 38;
            this.btnLogin2.Text = "Return to Login";
            this.btnLogin2.UseVisualStyleBackColor = false;
            // 
            // btnNextOrder
            // 
            this.btnNextOrder.BackColor = System.Drawing.Color.Beige;
            this.btnNextOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextOrder.Location = new System.Drawing.Point(291, 471);
            this.btnNextOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNextOrder.Name = "btnNextOrder";
            this.btnNextOrder.Size = new System.Drawing.Size(161, 46);
            this.btnNextOrder.TabIndex = 35;
            this.btnNextOrder.Text = "Next Page";
            this.btnNextOrder.UseVisualStyleBackColor = false;
            // 
            // btnPreviousOrder
            // 
            this.btnPreviousOrder.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousOrder.Location = new System.Drawing.Point(121, 471);
            this.btnPreviousOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPreviousOrder.Name = "btnPreviousOrder";
            this.btnPreviousOrder.Size = new System.Drawing.Size(161, 46);
            this.btnPreviousOrder.TabIndex = 34;
            this.btnPreviousOrder.Text = "Previous Page";
            this.btnPreviousOrder.UseVisualStyleBackColor = false;
            // 
            // btnDeleteOrder
            // 
            this.btnDeleteOrder.BackColor = System.Drawing.Color.Beige;
            this.btnDeleteOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteOrder.Location = new System.Drawing.Point(460, 471);
            this.btnDeleteOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDeleteOrder.Name = "btnDeleteOrder";
            this.btnDeleteOrder.Size = new System.Drawing.Size(161, 46);
            this.btnDeleteOrder.TabIndex = 33;
            this.btnDeleteOrder.Text = "Delete Order";
            this.btnDeleteOrder.UseVisualStyleBackColor = false;
            // 
            // frmCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(753, 625);
            this.Controls.Add(this.tbcOne);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmCustomer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Information";
            this.Load += new System.EventHandler(this.frmCustomer_Load);
            this.tbcOne.ResumeLayout(false);
            this.tabCustomerInformation.ResumeLayout(false);
            this.pnlOne.ResumeLayout(false);
            this.tabCustomerOrders.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcOne;
        private System.Windows.Forms.TabPage tabCustomerInformation;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlOne;
        private System.Windows.Forms.Button btnLogout1;
        private System.Windows.Forms.Button btnSaveCust;
        private System.Windows.Forms.Button btnEditCust;
        private System.Windows.Forms.TabPage tabCustomerOrders;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnLogin2;
        private System.Windows.Forms.Button btnNextOrder;
        private System.Windows.Forms.Button btnPreviousOrder;
        private System.Windows.Forms.Button btnDeleteOrder;
        private System.Windows.Forms.Button btnCancelCust;
        private System.Windows.Forms.Label lblCustID;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lblCustPostalCode;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lblCustUserID;
        private System.Windows.Forms.Label lblCustFax;
        private System.Windows.Forms.Label lblCustFName;
        private System.Windows.Forms.Label lblCustCountry;
        private System.Windows.Forms.Label lblCustLName;
        private System.Windows.Forms.Label lblCustCity;
        private System.Windows.Forms.Label lblCustPhone;
        private System.Windows.Forms.Label lblCustAddress;
        private System.Windows.Forms.Label lblOrderID;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lblOrderEmployeeID;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lblTotalPrice;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lblProducts;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lblOrderPostalCode;
        private System.Windows.Forms.Label lblOrderCustID;
        private System.Windows.Forms.Label lblShippedCountry;
        private System.Windows.Forms.Label lblOrderDate;
        private System.Windows.Forms.Label lblShippedCity;
        private System.Windows.Forms.Label lblShippedDate;
        private System.Windows.Forms.Label lblShippedAddress;
    }
}