﻿
namespace HomeFurniture
{
    partial class frmReset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblRestInstr = new System.Windows.Forms.Label();
            this.lblEmailRecover = new System.Windows.Forms.Label();
            this.tbxEmailReset = new System.Windows.Forms.TextBox();
            this.btnRecover = new System.Windows.Forms.Button();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.pnlOne = new System.Windows.Forms.Panel();
            this.tbxResetUsername = new System.Windows.Forms.TextBox();
            this.lblResetUN = new System.Windows.Forms.Label();
            this.btnResetUN = new System.Windows.Forms.Button();
            this.lblNote1 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.pnlOne.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Copperplate Gothic Light", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(116, 92);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(429, 43);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Account Recovery";
            // 
            // lblRestInstr
            // 
            this.lblRestInstr.AutoSize = true;
            this.lblRestInstr.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRestInstr.Location = new System.Drawing.Point(57, 44);
            this.lblRestInstr.Name = "lblRestInstr";
            this.lblRestInstr.Size = new System.Drawing.Size(507, 90);
            this.lblRestInstr.TabIndex = 0;
            this.lblRestInstr.Text = "Please enter your account email to reset your password. \r\nAn email will be sent t" +
    "o your account with instructions.";
            // 
            // lblEmailRecover
            // 
            this.lblEmailRecover.AutoSize = true;
            this.lblEmailRecover.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailRecover.Location = new System.Drawing.Point(140, 126);
            this.lblEmailRecover.Name = "lblEmailRecover";
            this.lblEmailRecover.Size = new System.Drawing.Size(65, 38);
            this.lblEmailRecover.TabIndex = 2;
            this.lblEmailRecover.Text = "Email:";
            // 
            // tbxEmailReset
            // 
            this.tbxEmailReset.Location = new System.Drawing.Point(204, 117);
            this.tbxEmailReset.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEmailReset.Multiline = true;
            this.tbxEmailReset.Name = "tbxEmailReset";
            this.tbxEmailReset.Size = new System.Drawing.Size(257, 43);
            this.tbxEmailReset.TabIndex = 3;
            // 
            // btnRecover
            // 
            this.btnRecover.BackColor = System.Drawing.Color.Beige;
            this.btnRecover.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecover.Location = new System.Drawing.Point(254, 434);
            this.btnRecover.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRecover.Name = "btnRecover";
            this.btnRecover.Size = new System.Drawing.Size(163, 47);
            this.btnRecover.TabIndex = 4;
            this.btnRecover.Text = "Start Recovery";
            this.btnRecover.UseVisualStyleBackColor = false;
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.BackColor = System.Drawing.Color.Beige;
            this.btnMainMenu.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainMenu.Location = new System.Drawing.Point(254, 507);
            this.btnMainMenu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(163, 46);
            this.btnMainMenu.TabIndex = 3;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.UseVisualStyleBackColor = false;
            // 
            // pnlOne
            // 
            this.pnlOne.BackColor = System.Drawing.Color.Beige;
            this.pnlOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOne.Controls.Add(this.tbxResetUsername);
            this.pnlOne.Controls.Add(this.lblResetUN);
            this.pnlOne.Controls.Add(this.lblRestInstr);
            this.pnlOne.Controls.Add(this.lblEmailRecover);
            this.pnlOne.Controls.Add(this.tbxEmailReset);
            this.pnlOne.Location = new System.Drawing.Point(29, 153);
            this.pnlOne.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlOne.Name = "pnlOne";
            this.pnlOne.Size = new System.Drawing.Size(613, 265);
            this.pnlOne.TabIndex = 1;
            // 
            // tbxResetUsername
            // 
            this.tbxResetUsername.Location = new System.Drawing.Point(204, 117);
            this.tbxResetUsername.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxResetUsername.Multiline = true;
            this.tbxResetUsername.Name = "tbxResetUsername";
            this.tbxResetUsername.Size = new System.Drawing.Size(257, 43);
            this.tbxResetUsername.TabIndex = 3;
            // 
            // lblResetUN
            // 
            this.lblResetUN.AutoSize = true;
            this.lblResetUN.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResetUN.Location = new System.Drawing.Point(116, 68);
            this.lblResetUN.Name = "lblResetUN";
            this.lblResetUN.Size = new System.Drawing.Size(380, 45);
            this.lblResetUN.TabIndex = 1;
            this.lblResetUN.Text = "Please enter your email to find username:";
            // 
            // btnResetUN
            // 
            this.btnResetUN.BackColor = System.Drawing.Color.Beige;
            this.btnResetUN.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetUN.Location = new System.Drawing.Point(254, 434);
            this.btnResetUN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnResetUN.Name = "btnResetUN";
            this.btnResetUN.Size = new System.Drawing.Size(163, 47);
            this.btnResetUN.TabIndex = 2;
            this.btnResetUN.Text = "Reset Username";
            this.btnResetUN.UseVisualStyleBackColor = false;
            // 
            // lblNote1
            // 
            this.lblNote1.AutoSize = true;
            this.lblNote1.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote1.Location = new System.Drawing.Point(347, 9);
            this.lblNote1.Name = "lblNote1";
            this.lblNote1.Size = new System.Drawing.Size(297, 64);
            this.lblNote1.TabIndex = 8;
            this.lblNote1.Text = "This page will be used for both the username \r\nand password section based on link" +
    " selection.";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Beige;
            this.btnCancel.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(15, 535);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(163, 45);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            // 
            // frmReset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(677, 593);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblNote1);
            this.Controls.Add(this.btnResetUN);
            this.Controls.Add(this.pnlOne);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnRecover);
            this.Controls.Add(this.lblTitle);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmReset";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reset Your Information";
            this.Load += new System.EventHandler(this.frmReset_Load);
            this.pnlOne.ResumeLayout(false);
            this.pnlOne.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblRestInstr;
        private System.Windows.Forms.Label lblEmailRecover;
        private System.Windows.Forms.TextBox tbxEmailReset;
        private System.Windows.Forms.Button btnRecover;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Panel pnlOne;
        private System.Windows.Forms.Label lblResetUN;
        private System.Windows.Forms.Button btnResetUN;
        private System.Windows.Forms.Label lblNote1;
        private System.Windows.Forms.TextBox tbxResetUsername;
        private System.Windows.Forms.Button btnCancel;
    }
}