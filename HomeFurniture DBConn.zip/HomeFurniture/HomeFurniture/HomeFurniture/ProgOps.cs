﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//added 
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace INEW2330_HomeFurniture
{
    class ProgOps
    {
        private const string CONNECT_STRING = @"Server=cstnt.tstc.edu;Database=inew2330sp21;User Id=group5sp212330;password=5926153";

        //variable for connection
        private static SqlConnection _connection; 
        //variable for command 
        private static SqlCommand sqlCommand;
        //variable for command builder updating records 

        public static void OpenConnection()
        {
            try
            {
                _connection = new SqlConnection(CONNECT_STRING);
                //opening database connection 
                _connection.Open();

                //message to show state of connection 
                MessageBox.Show(_connection.State.ToString());
                //close connection 
                _connection.Close();
                //message showing conenction is closed
                MessageBox.Show(_connection.State.ToString());
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
          
            

        
        }





    }
}
