﻿
namespace HomeFurniture
{
    partial class frmOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcOne = new System.Windows.Forms.TabControl();
            this.tabCustomerInformation = new System.Windows.Forms.TabPage();
            this.btnReassignEmployee = new System.Windows.Forms.Button();
            this.btnNewCust = new System.Windows.Forms.Button();
            this.btnRemoveCust = new System.Windows.Forms.Button();
            this.btnNextCust = new System.Windows.Forms.Button();
            this.btnPreviousCust = new System.Windows.Forms.Button();
            this.btnCancelCust = new System.Windows.Forms.Button();
            this.btnSaveCust = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlOne = new System.Windows.Forms.Panel();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lblPostalCode = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblFax = new System.Windows.Forms.Label();
            this.lblFName = new System.Windows.Forms.Label();
            this.lblCountry = new System.Windows.Forms.Label();
            this.lblLName = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnViewOrders = new System.Windows.Forms.Button();
            this.btnEditCust = new System.Windows.Forms.Button();
            this.tabCustomerOrders = new System.Windows.Forms.TabPage();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.btnSaveOrder = new System.Windows.Forms.Button();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lblOrderEmployeeID = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lblTotalPrice = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lblProducts = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lblOrderPostalCode = new System.Windows.Forms.Label();
            this.lblOrderCustID = new System.Windows.Forms.Label();
            this.lblShippedCountry = new System.Windows.Forms.Label();
            this.lblOrderDate = new System.Windows.Forms.Label();
            this.lblShippedCity = new System.Windows.Forms.Label();
            this.lblShippedDate = new System.Windows.Forms.Label();
            this.lblShippedAddress = new System.Windows.Forms.Label();
            this.btnChangeEmployee = new System.Windows.Forms.Button();
            this.btnCustInfo = new System.Windows.Forms.Button();
            this.btnLogin2 = new System.Windows.Forms.Button();
            this.btnNextOrder = new System.Windows.Forms.Button();
            this.btnPreviousOrder = new System.Windows.Forms.Button();
            this.btnDeleteOrder = new System.Windows.Forms.Button();
            this.btnEditOrder = new System.Windows.Forms.Button();
            this.tabEmployeeInformation = new System.Windows.Forms.TabPage();
            this.btnNewEmployee = new System.Windows.Forms.Button();
            this.btnNextEmp = new System.Windows.Forms.Button();
            this.btnPreviousEmp = new System.Windows.Forms.Button();
            this.btnEmpOrdersAssigned = new System.Windows.Forms.Button();
            this.btnEmpCustomersAssigned = new System.Windows.Forms.Button();
            this.btnCancelEmp = new System.Windows.Forms.Button();
            this.lblTitle3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblEmpID = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl26 = new System.Windows.Forms.Label();
            this.lbl27 = new System.Windows.Forms.Label();
            this.lbl28 = new System.Windows.Forms.Label();
            this.lbl29 = new System.Windows.Forms.Label();
            this.lbl30 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.lblEmpUserID = new System.Windows.Forms.Label();
            this.lblEmpFax = new System.Windows.Forms.Label();
            this.lblEmpFName = new System.Windows.Forms.Label();
            this.lblEmpCountry = new System.Windows.Forms.Label();
            this.lblEmpLName = new System.Windows.Forms.Label();
            this.lblEmpCity = new System.Windows.Forms.Label();
            this.lblEmpPhone = new System.Windows.Forms.Label();
            this.lblEmpAddress = new System.Windows.Forms.Label();
            this.btnLogin3 = new System.Windows.Forms.Button();
            this.btnSaveEmp = new System.Windows.Forms.Button();
            this.btnEditEmp = new System.Windows.Forms.Button();
            this.tabManagerInformation = new System.Windows.Forms.TabPage();
            this.btnManagerCancel = new System.Windows.Forms.Button();
            this.btnManagerSave = new System.Windows.Forms.Button();
            this.btnLogin4 = new System.Windows.Forms.Button();
            this.btnManagerEdit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblManagerID = new System.Windows.Forms.Label();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl36 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblManagerUserID = new System.Windows.Forms.Label();
            this.lblManagerFName = new System.Windows.Forms.Label();
            this.lblManagerCountry = new System.Windows.Forms.Label();
            this.lblManagerLName = new System.Windows.Forms.Label();
            this.lblManagerCity = new System.Windows.Forms.Label();
            this.lblManagerPhone = new System.Windows.Forms.Label();
            this.lblManagerAddress = new System.Windows.Forms.Label();
            this.tbcOne.SuspendLayout();
            this.tabCustomerInformation.SuspendLayout();
            this.pnlOne.SuspendLayout();
            this.tabCustomerOrders.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabEmployeeInformation.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabManagerInformation.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcOne
            // 
            this.tbcOne.Controls.Add(this.tabCustomerInformation);
            this.tbcOne.Controls.Add(this.tabCustomerOrders);
            this.tbcOne.Controls.Add(this.tabEmployeeInformation);
            this.tbcOne.Controls.Add(this.tabManagerInformation);
            this.tbcOne.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcOne.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcOne.Location = new System.Drawing.Point(0, 0);
            this.tbcOne.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbcOne.Multiline = true;
            this.tbcOne.Name = "tbcOne";
            this.tbcOne.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tbcOne.SelectedIndex = 0;
            this.tbcOne.Size = new System.Drawing.Size(753, 681);
            this.tbcOne.TabIndex = 0;
            // 
            // tabCustomerInformation
            // 
            this.tabCustomerInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerInformation.Controls.Add(this.btnReassignEmployee);
            this.tabCustomerInformation.Controls.Add(this.btnNewCust);
            this.tabCustomerInformation.Controls.Add(this.btnRemoveCust);
            this.tabCustomerInformation.Controls.Add(this.btnNextCust);
            this.tabCustomerInformation.Controls.Add(this.btnPreviousCust);
            this.tabCustomerInformation.Controls.Add(this.btnCancelCust);
            this.tabCustomerInformation.Controls.Add(this.btnSaveCust);
            this.tabCustomerInformation.Controls.Add(this.lblTitle);
            this.tabCustomerInformation.Controls.Add(this.pnlOne);
            this.tabCustomerInformation.Controls.Add(this.btnLogout);
            this.tabCustomerInformation.Controls.Add(this.btnViewOrders);
            this.tabCustomerInformation.Controls.Add(this.btnEditCust);
            this.tabCustomerInformation.Location = new System.Drawing.Point(4, 38);
            this.tabCustomerInformation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabCustomerInformation.Name = "tabCustomerInformation";
            this.tabCustomerInformation.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabCustomerInformation.Size = new System.Drawing.Size(745, 639);
            this.tabCustomerInformation.TabIndex = 0;
            this.tabCustomerInformation.Text = "Customer Information";
            // 
            // btnReassignEmployee
            // 
            this.btnReassignEmployee.BackColor = System.Drawing.Color.Beige;
            this.btnReassignEmployee.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReassignEmployee.Location = new System.Drawing.Point(309, 517);
            this.btnReassignEmployee.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnReassignEmployee.Name = "btnReassignEmployee";
            this.btnReassignEmployee.Size = new System.Drawing.Size(161, 45);
            this.btnReassignEmployee.TabIndex = 9;
            this.btnReassignEmployee.Text = "Reassign Employee";
            this.btnReassignEmployee.UseVisualStyleBackColor = false;
            // 
            // btnNewCust
            // 
            this.btnNewCust.BackColor = System.Drawing.Color.Beige;
            this.btnNewCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewCust.Location = new System.Drawing.Point(479, 517);
            this.btnNewCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNewCust.Name = "btnNewCust";
            this.btnNewCust.Size = new System.Drawing.Size(161, 45);
            this.btnNewCust.TabIndex = 10;
            this.btnNewCust.Text = "Add New Customer";
            this.btnNewCust.UseVisualStyleBackColor = false;
            // 
            // btnRemoveCust
            // 
            this.btnRemoveCust.BackColor = System.Drawing.Color.Beige;
            this.btnRemoveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveCust.Location = new System.Drawing.Point(479, 452);
            this.btnRemoveCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveCust.Name = "btnRemoveCust";
            this.btnRemoveCust.Size = new System.Drawing.Size(161, 45);
            this.btnRemoveCust.TabIndex = 7;
            this.btnRemoveCust.Text = "Remove Customer";
            this.btnRemoveCust.UseVisualStyleBackColor = false;
            // 
            // btnNextCust
            // 
            this.btnNextCust.BackColor = System.Drawing.Color.Beige;
            this.btnNextCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextCust.Location = new System.Drawing.Point(479, 386);
            this.btnNextCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNextCust.Name = "btnNextCust";
            this.btnNextCust.Size = new System.Drawing.Size(161, 45);
            this.btnNextCust.TabIndex = 4;
            this.btnNextCust.Text = "Next Customer";
            this.btnNextCust.UseVisualStyleBackColor = false;
            // 
            // btnPreviousCust
            // 
            this.btnPreviousCust.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousCust.Location = new System.Drawing.Point(309, 386);
            this.btnPreviousCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPreviousCust.Name = "btnPreviousCust";
            this.btnPreviousCust.Size = new System.Drawing.Size(161, 45);
            this.btnPreviousCust.TabIndex = 3;
            this.btnPreviousCust.Text = "Previous Customer";
            this.btnPreviousCust.UseVisualStyleBackColor = false;
            // 
            // btnCancelCust
            // 
            this.btnCancelCust.BackColor = System.Drawing.Color.Beige;
            this.btnCancelCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelCust.Location = new System.Drawing.Point(103, 517);
            this.btnCancelCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancelCust.Name = "btnCancelCust";
            this.btnCancelCust.Size = new System.Drawing.Size(161, 45);
            this.btnCancelCust.TabIndex = 8;
            this.btnCancelCust.Text = "Cancel";
            this.btnCancelCust.UseVisualStyleBackColor = false;
            // 
            // btnSaveCust
            // 
            this.btnSaveCust.BackColor = System.Drawing.Color.Beige;
            this.btnSaveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCust.Location = new System.Drawing.Point(103, 452);
            this.btnSaveCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSaveCust.Name = "btnSaveCust";
            this.btnSaveCust.Size = new System.Drawing.Size(161, 45);
            this.btnSaveCust.TabIndex = 5;
            this.btnSaveCust.Text = "Save";
            this.btnSaveCust.UseVisualStyleBackColor = false;
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Copperplate Gothic Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(103, 11);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(537, 44);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Customer Information";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlOne
            // 
            this.pnlOne.BackColor = System.Drawing.Color.Beige;
            this.pnlOne.Controls.Add(this.lblCustomerID);
            this.pnlOne.Controls.Add(this.lbl1);
            this.pnlOne.Controls.Add(this.lbl2);
            this.pnlOne.Controls.Add(this.lbl3);
            this.pnlOne.Controls.Add(this.lbl4);
            this.pnlOne.Controls.Add(this.lbl5);
            this.pnlOne.Controls.Add(this.lbl6);
            this.pnlOne.Controls.Add(this.lbl7);
            this.pnlOne.Controls.Add(this.lbl8);
            this.pnlOne.Controls.Add(this.lbl9);
            this.pnlOne.Controls.Add(this.lblPostalCode);
            this.pnlOne.Controls.Add(this.lbl10);
            this.pnlOne.Controls.Add(this.lblUserID);
            this.pnlOne.Controls.Add(this.lblFax);
            this.pnlOne.Controls.Add(this.lblFName);
            this.pnlOne.Controls.Add(this.lblCountry);
            this.pnlOne.Controls.Add(this.lblLName);
            this.pnlOne.Controls.Add(this.lblCity);
            this.pnlOne.Controls.Add(this.lblPhone);
            this.pnlOne.Controls.Add(this.lblAddress);
            this.pnlOne.Location = new System.Drawing.Point(103, 57);
            this.pnlOne.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlOne.Name = "pnlOne";
            this.pnlOne.Size = new System.Drawing.Size(537, 313);
            this.pnlOne.TabIndex = 1;
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCustomerID.Location = new System.Drawing.Point(149, 15);
            this.lblCustomerID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(367, 28);
            this.lblCustomerID.TabIndex = 1;
            this.lblCustomerID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl1
            // 
            this.lbl1.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(20, 15);
            this.lbl1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(121, 28);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Customer ID:";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl2
            // 
            this.lbl2.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(20, 43);
            this.lbl2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(121, 28);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "First Name:";
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl3
            // 
            this.lbl3.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(20, 71);
            this.lbl3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(121, 28);
            this.lbl3.TabIndex = 4;
            this.lbl3.Text = "Last Name:";
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl4
            // 
            this.lbl4.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.Location = new System.Drawing.Point(20, 100);
            this.lbl4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(121, 28);
            this.lbl4.TabIndex = 6;
            this.lbl4.Text = "Phone Number:";
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl5
            // 
            this.lbl5.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(20, 128);
            this.lbl5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(121, 28);
            this.lbl5.TabIndex = 8;
            this.lbl5.Text = "Address:";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl6
            // 
            this.lbl6.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.Location = new System.Drawing.Point(20, 156);
            this.lbl6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(121, 28);
            this.lbl6.TabIndex = 10;
            this.lbl6.Text = "City:";
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl7
            // 
            this.lbl7.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.Location = new System.Drawing.Point(20, 185);
            this.lbl7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(121, 28);
            this.lbl7.TabIndex = 12;
            this.lbl7.Text = "Country:";
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl8
            // 
            this.lbl8.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.Location = new System.Drawing.Point(20, 213);
            this.lbl8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(121, 28);
            this.lbl8.TabIndex = 14;
            this.lbl8.Text = "Fax:";
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl9
            // 
            this.lbl9.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.Location = new System.Drawing.Point(20, 241);
            this.lbl9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(121, 28);
            this.lbl9.TabIndex = 16;
            this.lbl9.Text = "User ID:";
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPostalCode
            // 
            this.lblPostalCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPostalCode.Location = new System.Drawing.Point(149, 270);
            this.lblPostalCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPostalCode.Name = "lblPostalCode";
            this.lblPostalCode.Size = new System.Drawing.Size(367, 28);
            this.lblPostalCode.TabIndex = 19;
            this.lblPostalCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl10
            // 
            this.lbl10.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10.Location = new System.Drawing.Point(20, 270);
            this.lbl10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(121, 28);
            this.lbl10.TabIndex = 18;
            this.lbl10.Text = "Postal Code:";
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUserID
            // 
            this.lblUserID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblUserID.Location = new System.Drawing.Point(149, 241);
            this.lblUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(367, 28);
            this.lblUserID.TabIndex = 17;
            this.lblUserID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFax
            // 
            this.lblFax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFax.Location = new System.Drawing.Point(149, 213);
            this.lblFax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFax.Name = "lblFax";
            this.lblFax.Size = new System.Drawing.Size(367, 28);
            this.lblFax.TabIndex = 15;
            this.lblFax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFName
            // 
            this.lblFName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFName.Location = new System.Drawing.Point(149, 43);
            this.lblFName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(367, 28);
            this.lblFName.TabIndex = 3;
            this.lblFName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCountry
            // 
            this.lblCountry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCountry.Location = new System.Drawing.Point(149, 185);
            this.lblCountry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(367, 28);
            this.lblCountry.TabIndex = 13;
            this.lblCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLName
            // 
            this.lblLName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblLName.Location = new System.Drawing.Point(149, 71);
            this.lblLName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLName.Name = "lblLName";
            this.lblLName.Size = new System.Drawing.Size(367, 28);
            this.lblLName.TabIndex = 5;
            this.lblLName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCity
            // 
            this.lblCity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCity.Location = new System.Drawing.Point(149, 156);
            this.lblCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(367, 28);
            this.lblCity.TabIndex = 11;
            this.lblCity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPhone
            // 
            this.lblPhone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPhone.Location = new System.Drawing.Point(149, 100);
            this.lblPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(367, 28);
            this.lblPhone.TabIndex = 7;
            this.lblPhone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAddress
            // 
            this.lblAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAddress.Location = new System.Drawing.Point(149, 128);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(367, 28);
            this.lblAddress.TabIndex = 9;
            this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Beige;
            this.btnLogout.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(11, 582);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(161, 45);
            this.btnLogout.TabIndex = 11;
            this.btnLogout.Text = "Return to Login";
            this.btnLogout.UseVisualStyleBackColor = false;
            // 
            // btnViewOrders
            // 
            this.btnViewOrders.BackColor = System.Drawing.Color.Beige;
            this.btnViewOrders.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewOrders.Location = new System.Drawing.Point(309, 452);
            this.btnViewOrders.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnViewOrders.Name = "btnViewOrders";
            this.btnViewOrders.Size = new System.Drawing.Size(161, 45);
            this.btnViewOrders.TabIndex = 6;
            this.btnViewOrders.Text = "View Orders";
            this.btnViewOrders.UseVisualStyleBackColor = false;
            // 
            // btnEditCust
            // 
            this.btnEditCust.BackColor = System.Drawing.Color.Beige;
            this.btnEditCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditCust.Location = new System.Drawing.Point(103, 386);
            this.btnEditCust.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEditCust.Name = "btnEditCust";
            this.btnEditCust.Size = new System.Drawing.Size(161, 45);
            this.btnEditCust.TabIndex = 2;
            this.btnEditCust.Text = "Change Information";
            this.btnEditCust.UseVisualStyleBackColor = false;
            // 
            // tabCustomerOrders
            // 
            this.tabCustomerOrders.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerOrders.Controls.Add(this.btnCancelOrder);
            this.tabCustomerOrders.Controls.Add(this.btnSaveOrder);
            this.tabCustomerOrders.Controls.Add(this.lblTitle2);
            this.tabCustomerOrders.Controls.Add(this.panel1);
            this.tabCustomerOrders.Controls.Add(this.btnChangeEmployee);
            this.tabCustomerOrders.Controls.Add(this.btnCustInfo);
            this.tabCustomerOrders.Controls.Add(this.btnLogin2);
            this.tabCustomerOrders.Controls.Add(this.btnNextOrder);
            this.tabCustomerOrders.Controls.Add(this.btnPreviousOrder);
            this.tabCustomerOrders.Controls.Add(this.btnDeleteOrder);
            this.tabCustomerOrders.Controls.Add(this.btnEditOrder);
            this.tabCustomerOrders.Location = new System.Drawing.Point(4, 38);
            this.tabCustomerOrders.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabCustomerOrders.Name = "tabCustomerOrders";
            this.tabCustomerOrders.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabCustomerOrders.Size = new System.Drawing.Size(745, 639);
            this.tabCustomerOrders.TabIndex = 1;
            this.tabCustomerOrders.Text = "Customer Orders";
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.BackColor = System.Drawing.Color.Beige;
            this.btnCancelOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelOrder.Location = new System.Drawing.Point(375, 452);
            this.btnCancelOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(161, 58);
            this.btnCancelOrder.TabIndex = 43;
            this.btnCancelOrder.Text = "Cancel";
            this.btnCancelOrder.UseVisualStyleBackColor = false;
            // 
            // btnSaveOrder
            // 
            this.btnSaveOrder.BackColor = System.Drawing.Color.Beige;
            this.btnSaveOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveOrder.Location = new System.Drawing.Point(205, 452);
            this.btnSaveOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSaveOrder.Name = "btnSaveOrder";
            this.btnSaveOrder.Size = new System.Drawing.Size(161, 58);
            this.btnSaveOrder.TabIndex = 42;
            this.btnSaveOrder.Text = "Save";
            this.btnSaveOrder.UseVisualStyleBackColor = false;
            // 
            // lblTitle2
            // 
            this.lblTitle2.Font = new System.Drawing.Font("Copperplate Gothic Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle2.Location = new System.Drawing.Point(121, 5);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(499, 44);
            this.lblTitle2.TabIndex = 41;
            this.lblTitle2.Text = "View Orders";
            this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Beige;
            this.panel1.Controls.Add(this.lblOrderID);
            this.panel1.Controls.Add(this.lbl12);
            this.panel1.Controls.Add(this.lbl13);
            this.panel1.Controls.Add(this.lbl14);
            this.panel1.Controls.Add(this.lbl15);
            this.panel1.Controls.Add(this.lbl16);
            this.panel1.Controls.Add(this.lbl17);
            this.panel1.Controls.Add(this.lbl18);
            this.panel1.Controls.Add(this.lbl19);
            this.panel1.Controls.Add(this.lblOrderEmployeeID);
            this.panel1.Controls.Add(this.lbl20);
            this.panel1.Controls.Add(this.lblTotalPrice);
            this.panel1.Controls.Add(this.lbl21);
            this.panel1.Controls.Add(this.lblProducts);
            this.panel1.Controls.Add(this.lbl22);
            this.panel1.Controls.Add(this.lblOrderPostalCode);
            this.panel1.Controls.Add(this.lblOrderCustID);
            this.panel1.Controls.Add(this.lblShippedCountry);
            this.panel1.Controls.Add(this.lblOrderDate);
            this.panel1.Controls.Add(this.lblShippedCity);
            this.panel1.Controls.Add(this.lblShippedDate);
            this.panel1.Controls.Add(this.lblShippedAddress);
            this.panel1.Location = new System.Drawing.Point(121, 52);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(499, 394);
            this.panel1.TabIndex = 40;
            // 
            // lblOrderID
            // 
            this.lblOrderID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderID.Location = new System.Drawing.Point(167, 12);
            this.lblOrderID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(296, 28);
            this.lblOrderID.TabIndex = 23;
            this.lblOrderID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl12
            // 
            this.lbl12.Location = new System.Drawing.Point(37, 12);
            this.lbl12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(121, 28);
            this.lbl12.TabIndex = 22;
            this.lbl12.Text = "Order ID:";
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl13
            // 
            this.lbl13.Location = new System.Drawing.Point(37, 41);
            this.lbl13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(121, 28);
            this.lbl13.TabIndex = 24;
            this.lbl13.Text = "Customer ID:";
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl14
            // 
            this.lbl14.Location = new System.Drawing.Point(37, 69);
            this.lbl14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(121, 28);
            this.lbl14.TabIndex = 26;
            this.lbl14.Text = "Order Date:";
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl15
            // 
            this.lbl15.Location = new System.Drawing.Point(37, 97);
            this.lbl15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(121, 28);
            this.lbl15.TabIndex = 28;
            this.lbl15.Text = "Shipped Date:";
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl16
            // 
            this.lbl16.Location = new System.Drawing.Point(37, 126);
            this.lbl16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(121, 28);
            this.lbl16.TabIndex = 30;
            this.lbl16.Text = "Shipped Address:";
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl17
            // 
            this.lbl17.Location = new System.Drawing.Point(37, 154);
            this.lbl17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(121, 28);
            this.lbl17.TabIndex = 32;
            this.lbl17.Text = "Shipped City:";
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl18
            // 
            this.lbl18.Location = new System.Drawing.Point(37, 182);
            this.lbl18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(121, 28);
            this.lbl18.TabIndex = 34;
            this.lbl18.Text = "Shipped Country:";
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl19
            // 
            this.lbl19.Location = new System.Drawing.Point(37, 210);
            this.lbl19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(121, 28);
            this.lbl19.TabIndex = 36;
            this.lbl19.Text = "Postal Code:";
            this.lbl19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblOrderEmployeeID
            // 
            this.lblOrderEmployeeID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderEmployeeID.Location = new System.Drawing.Point(167, 353);
            this.lblOrderEmployeeID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderEmployeeID.Name = "lblOrderEmployeeID";
            this.lblOrderEmployeeID.Size = new System.Drawing.Size(296, 28);
            this.lblOrderEmployeeID.TabIndex = 43;
            this.lblOrderEmployeeID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl20
            // 
            this.lbl20.Location = new System.Drawing.Point(37, 239);
            this.lbl20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(121, 86);
            this.lbl20.TabIndex = 38;
            this.lbl20.Text = "Products:";
            this.lbl20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotalPrice
            // 
            this.lblTotalPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalPrice.Location = new System.Drawing.Point(167, 325);
            this.lblTotalPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalPrice.Name = "lblTotalPrice";
            this.lblTotalPrice.Size = new System.Drawing.Size(296, 28);
            this.lblTotalPrice.TabIndex = 41;
            this.lblTotalPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl21
            // 
            this.lbl21.Location = new System.Drawing.Point(37, 325);
            this.lbl21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(121, 28);
            this.lbl21.TabIndex = 40;
            this.lbl21.Text = "Total Price:";
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProducts
            // 
            this.lblProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblProducts.Location = new System.Drawing.Point(167, 239);
            this.lblProducts.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProducts.Name = "lblProducts";
            this.lblProducts.Size = new System.Drawing.Size(296, 86);
            this.lblProducts.TabIndex = 39;
            this.lblProducts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl22
            // 
            this.lbl22.Location = new System.Drawing.Point(37, 353);
            this.lbl22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(121, 28);
            this.lbl22.TabIndex = 42;
            this.lbl22.Text = "Employee ID:";
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblOrderPostalCode
            // 
            this.lblOrderPostalCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderPostalCode.Location = new System.Drawing.Point(167, 210);
            this.lblOrderPostalCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderPostalCode.Name = "lblOrderPostalCode";
            this.lblOrderPostalCode.Size = new System.Drawing.Size(296, 28);
            this.lblOrderPostalCode.TabIndex = 37;
            this.lblOrderPostalCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrderCustID
            // 
            this.lblOrderCustID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderCustID.Location = new System.Drawing.Point(167, 41);
            this.lblOrderCustID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderCustID.Name = "lblOrderCustID";
            this.lblOrderCustID.Size = new System.Drawing.Size(296, 28);
            this.lblOrderCustID.TabIndex = 25;
            this.lblOrderCustID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblShippedCountry
            // 
            this.lblShippedCountry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShippedCountry.Location = new System.Drawing.Point(167, 182);
            this.lblShippedCountry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShippedCountry.Name = "lblShippedCountry";
            this.lblShippedCountry.Size = new System.Drawing.Size(296, 28);
            this.lblShippedCountry.TabIndex = 35;
            this.lblShippedCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrderDate
            // 
            this.lblOrderDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderDate.Location = new System.Drawing.Point(167, 69);
            this.lblOrderDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrderDate.Name = "lblOrderDate";
            this.lblOrderDate.Size = new System.Drawing.Size(296, 28);
            this.lblOrderDate.TabIndex = 27;
            this.lblOrderDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblShippedCity
            // 
            this.lblShippedCity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShippedCity.Location = new System.Drawing.Point(167, 154);
            this.lblShippedCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShippedCity.Name = "lblShippedCity";
            this.lblShippedCity.Size = new System.Drawing.Size(296, 28);
            this.lblShippedCity.TabIndex = 33;
            this.lblShippedCity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblShippedDate
            // 
            this.lblShippedDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShippedDate.Location = new System.Drawing.Point(167, 97);
            this.lblShippedDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShippedDate.Name = "lblShippedDate";
            this.lblShippedDate.Size = new System.Drawing.Size(296, 28);
            this.lblShippedDate.TabIndex = 29;
            this.lblShippedDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblShippedAddress
            // 
            this.lblShippedAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShippedAddress.Location = new System.Drawing.Point(167, 126);
            this.lblShippedAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShippedAddress.Name = "lblShippedAddress";
            this.lblShippedAddress.Size = new System.Drawing.Size(296, 28);
            this.lblShippedAddress.TabIndex = 31;
            this.lblShippedAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnChangeEmployee
            // 
            this.btnChangeEmployee.BackColor = System.Drawing.Color.Beige;
            this.btnChangeEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangeEmployee.Location = new System.Drawing.Point(544, 452);
            this.btnChangeEmployee.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnChangeEmployee.Name = "btnChangeEmployee";
            this.btnChangeEmployee.Size = new System.Drawing.Size(161, 58);
            this.btnChangeEmployee.TabIndex = 37;
            this.btnChangeEmployee.Text = "Change Employee";
            this.btnChangeEmployee.UseVisualStyleBackColor = false;
            // 
            // btnCustInfo
            // 
            this.btnCustInfo.BackColor = System.Drawing.Color.Beige;
            this.btnCustInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustInfo.Location = new System.Drawing.Point(544, 517);
            this.btnCustInfo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCustInfo.Name = "btnCustInfo";
            this.btnCustInfo.Size = new System.Drawing.Size(161, 58);
            this.btnCustInfo.TabIndex = 36;
            this.btnCustInfo.Text = "Customer Information";
            this.btnCustInfo.UseVisualStyleBackColor = false;
            // 
            // btnLogin2
            // 
            this.btnLogin2.BackColor = System.Drawing.Color.Beige;
            this.btnLogin2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin2.Location = new System.Drawing.Point(36, 582);
            this.btnLogin2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogin2.Name = "btnLogin2";
            this.btnLogin2.Size = new System.Drawing.Size(161, 58);
            this.btnLogin2.TabIndex = 38;
            this.btnLogin2.Text = "Return to Login";
            this.btnLogin2.UseVisualStyleBackColor = false;
            // 
            // btnNextOrder
            // 
            this.btnNextOrder.BackColor = System.Drawing.Color.GreenYellow;
            this.btnNextOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextOrder.Location = new System.Drawing.Point(205, 517);
            this.btnNextOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNextOrder.Name = "btnNextOrder";
            this.btnNextOrder.Size = new System.Drawing.Size(161, 58);
            this.btnNextOrder.TabIndex = 35;
            this.btnNextOrder.Text = "Next Page";
            this.btnNextOrder.UseVisualStyleBackColor = false;
            // 
            // btnPreviousOrder
            // 
            this.btnPreviousOrder.BackColor = System.Drawing.Color.GreenYellow;
            this.btnPreviousOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousOrder.Location = new System.Drawing.Point(375, 517);
            this.btnPreviousOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPreviousOrder.Name = "btnPreviousOrder";
            this.btnPreviousOrder.Size = new System.Drawing.Size(161, 58);
            this.btnPreviousOrder.TabIndex = 34;
            this.btnPreviousOrder.Text = "Previous Page";
            this.btnPreviousOrder.UseVisualStyleBackColor = false;
            // 
            // btnDeleteOrder
            // 
            this.btnDeleteOrder.BackColor = System.Drawing.Color.Beige;
            this.btnDeleteOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteOrder.Location = new System.Drawing.Point(36, 517);
            this.btnDeleteOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDeleteOrder.Name = "btnDeleteOrder";
            this.btnDeleteOrder.Size = new System.Drawing.Size(161, 58);
            this.btnDeleteOrder.TabIndex = 33;
            this.btnDeleteOrder.Text = "Delete Order";
            this.btnDeleteOrder.UseVisualStyleBackColor = false;
            // 
            // btnEditOrder
            // 
            this.btnEditOrder.BackColor = System.Drawing.Color.Beige;
            this.btnEditOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditOrder.Location = new System.Drawing.Point(36, 452);
            this.btnEditOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEditOrder.Name = "btnEditOrder";
            this.btnEditOrder.Size = new System.Drawing.Size(161, 58);
            this.btnEditOrder.TabIndex = 32;
            this.btnEditOrder.Text = "Edit Order";
            this.btnEditOrder.UseVisualStyleBackColor = false;
            // 
            // tabEmployeeInformation
            // 
            this.tabEmployeeInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabEmployeeInformation.Controls.Add(this.btnNewEmployee);
            this.tabEmployeeInformation.Controls.Add(this.btnNextEmp);
            this.tabEmployeeInformation.Controls.Add(this.btnPreviousEmp);
            this.tabEmployeeInformation.Controls.Add(this.btnEmpOrdersAssigned);
            this.tabEmployeeInformation.Controls.Add(this.btnEmpCustomersAssigned);
            this.tabEmployeeInformation.Controls.Add(this.btnCancelEmp);
            this.tabEmployeeInformation.Controls.Add(this.lblTitle3);
            this.tabEmployeeInformation.Controls.Add(this.panel2);
            this.tabEmployeeInformation.Controls.Add(this.btnLogin3);
            this.tabEmployeeInformation.Controls.Add(this.btnSaveEmp);
            this.tabEmployeeInformation.Controls.Add(this.btnEditEmp);
            this.tabEmployeeInformation.Location = new System.Drawing.Point(4, 38);
            this.tabEmployeeInformation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabEmployeeInformation.Name = "tabEmployeeInformation";
            this.tabEmployeeInformation.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabEmployeeInformation.Size = new System.Drawing.Size(745, 639);
            this.tabEmployeeInformation.TabIndex = 2;
            this.tabEmployeeInformation.Text = "Employee Information";
            // 
            // btnNewEmployee
            // 
            this.btnNewEmployee.BackColor = System.Drawing.Color.Beige;
            this.btnNewEmployee.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewEmployee.Location = new System.Drawing.Point(460, 520);
            this.btnNewEmployee.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNewEmployee.Name = "btnNewEmployee";
            this.btnNewEmployee.Size = new System.Drawing.Size(161, 45);
            this.btnNewEmployee.TabIndex = 29;
            this.btnNewEmployee.Text = "Add New Employee";
            this.btnNewEmployee.UseVisualStyleBackColor = false;
            // 
            // btnNextEmp
            // 
            this.btnNextEmp.BackColor = System.Drawing.Color.Beige;
            this.btnNextEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextEmp.Location = new System.Drawing.Point(457, 390);
            this.btnNextEmp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNextEmp.Name = "btnNextEmp";
            this.btnNextEmp.Size = new System.Drawing.Size(161, 45);
            this.btnNextEmp.TabIndex = 28;
            this.btnNextEmp.Text = "Next Employee";
            this.btnNextEmp.UseVisualStyleBackColor = false;
            // 
            // btnPreviousEmp
            // 
            this.btnPreviousEmp.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousEmp.Location = new System.Drawing.Point(121, 390);
            this.btnPreviousEmp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPreviousEmp.Name = "btnPreviousEmp";
            this.btnPreviousEmp.Size = new System.Drawing.Size(161, 45);
            this.btnPreviousEmp.TabIndex = 27;
            this.btnPreviousEmp.Text = "Previous Employee";
            this.btnPreviousEmp.UseVisualStyleBackColor = false;
            // 
            // btnEmpOrdersAssigned
            // 
            this.btnEmpOrdersAssigned.BackColor = System.Drawing.Color.Beige;
            this.btnEmpOrdersAssigned.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpOrdersAssigned.Location = new System.Drawing.Point(291, 520);
            this.btnEmpOrdersAssigned.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEmpOrdersAssigned.Name = "btnEmpOrdersAssigned";
            this.btnEmpOrdersAssigned.Size = new System.Drawing.Size(161, 45);
            this.btnEmpOrdersAssigned.TabIndex = 26;
            this.btnEmpOrdersAssigned.Text = "Orders Assigned";
            this.btnEmpOrdersAssigned.UseVisualStyleBackColor = false;
            // 
            // btnEmpCustomersAssigned
            // 
            this.btnEmpCustomersAssigned.BackColor = System.Drawing.Color.Beige;
            this.btnEmpCustomersAssigned.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpCustomersAssigned.Location = new System.Drawing.Point(121, 520);
            this.btnEmpCustomersAssigned.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEmpCustomersAssigned.Name = "btnEmpCustomersAssigned";
            this.btnEmpCustomersAssigned.Size = new System.Drawing.Size(161, 45);
            this.btnEmpCustomersAssigned.TabIndex = 25;
            this.btnEmpCustomersAssigned.Text = "Customers Assigned";
            this.btnEmpCustomersAssigned.UseVisualStyleBackColor = false;
            // 
            // btnCancelEmp
            // 
            this.btnCancelEmp.BackColor = System.Drawing.Color.Beige;
            this.btnCancelEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelEmp.Location = new System.Drawing.Point(460, 455);
            this.btnCancelEmp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancelEmp.Name = "btnCancelEmp";
            this.btnCancelEmp.Size = new System.Drawing.Size(161, 45);
            this.btnCancelEmp.TabIndex = 24;
            this.btnCancelEmp.Text = "Cancel";
            this.btnCancelEmp.UseVisualStyleBackColor = false;
            // 
            // lblTitle3
            // 
            this.lblTitle3.Font = new System.Drawing.Font("Copperplate Gothic Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle3.Location = new System.Drawing.Point(103, 39);
            this.lblTitle3.Name = "lblTitle3";
            this.lblTitle3.Size = new System.Drawing.Size(537, 44);
            this.lblTitle3.TabIndex = 19;
            this.lblTitle3.Text = "Employee Information";
            this.lblTitle3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Beige;
            this.panel2.Controls.Add(this.lblEmpID);
            this.panel2.Controls.Add(this.lbl23);
            this.panel2.Controls.Add(this.lbl24);
            this.panel2.Controls.Add(this.lbl25);
            this.panel2.Controls.Add(this.lbl26);
            this.panel2.Controls.Add(this.lbl27);
            this.panel2.Controls.Add(this.lbl28);
            this.panel2.Controls.Add(this.lbl29);
            this.panel2.Controls.Add(this.lbl30);
            this.panel2.Controls.Add(this.lbl31);
            this.panel2.Controls.Add(this.lblEmpUserID);
            this.panel2.Controls.Add(this.lblEmpFax);
            this.panel2.Controls.Add(this.lblEmpFName);
            this.panel2.Controls.Add(this.lblEmpCountry);
            this.panel2.Controls.Add(this.lblEmpLName);
            this.panel2.Controls.Add(this.lblEmpCity);
            this.panel2.Controls.Add(this.lblEmpPhone);
            this.panel2.Controls.Add(this.lblEmpAddress);
            this.panel2.Location = new System.Drawing.Point(103, 86);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(537, 284);
            this.panel2.TabIndex = 20;
            // 
            // lblEmpID
            // 
            this.lblEmpID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpID.Location = new System.Drawing.Point(149, 15);
            this.lblEmpID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpID.Name = "lblEmpID";
            this.lblEmpID.Size = new System.Drawing.Size(367, 28);
            this.lblEmpID.TabIndex = 1;
            this.lblEmpID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl23
            // 
            this.lbl23.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.Location = new System.Drawing.Point(20, 15);
            this.lbl23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(121, 28);
            this.lbl23.TabIndex = 0;
            this.lbl23.Text = "Employee ID:";
            this.lbl23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl24
            // 
            this.lbl24.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.Location = new System.Drawing.Point(20, 43);
            this.lbl24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(121, 28);
            this.lbl24.TabIndex = 2;
            this.lbl24.Text = "First Name:";
            this.lbl24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl25
            // 
            this.lbl25.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.Location = new System.Drawing.Point(20, 71);
            this.lbl25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(121, 28);
            this.lbl25.TabIndex = 4;
            this.lbl25.Text = "Last Name:";
            this.lbl25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl26
            // 
            this.lbl26.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26.Location = new System.Drawing.Point(20, 100);
            this.lbl26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(121, 28);
            this.lbl26.TabIndex = 6;
            this.lbl26.Text = "Phone Number:";
            this.lbl26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl27
            // 
            this.lbl27.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27.Location = new System.Drawing.Point(20, 128);
            this.lbl27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(121, 28);
            this.lbl27.TabIndex = 8;
            this.lbl27.Text = "Address:";
            this.lbl27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl28
            // 
            this.lbl28.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl28.Location = new System.Drawing.Point(20, 156);
            this.lbl28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(121, 28);
            this.lbl28.TabIndex = 10;
            this.lbl28.Text = "City:";
            this.lbl28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl29
            // 
            this.lbl29.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl29.Location = new System.Drawing.Point(20, 185);
            this.lbl29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(121, 28);
            this.lbl29.TabIndex = 12;
            this.lbl29.Text = "Country:";
            this.lbl29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl30
            // 
            this.lbl30.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl30.Location = new System.Drawing.Point(20, 213);
            this.lbl30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(121, 28);
            this.lbl30.TabIndex = 14;
            this.lbl30.Text = "Fax:";
            this.lbl30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl31
            // 
            this.lbl31.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.Location = new System.Drawing.Point(20, 241);
            this.lbl31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(121, 28);
            this.lbl31.TabIndex = 16;
            this.lbl31.Text = "User ID:";
            this.lbl31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblEmpUserID
            // 
            this.lblEmpUserID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpUserID.Location = new System.Drawing.Point(149, 241);
            this.lblEmpUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpUserID.Name = "lblEmpUserID";
            this.lblEmpUserID.Size = new System.Drawing.Size(367, 28);
            this.lblEmpUserID.TabIndex = 17;
            this.lblEmpUserID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEmpFax
            // 
            this.lblEmpFax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpFax.Location = new System.Drawing.Point(149, 213);
            this.lblEmpFax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpFax.Name = "lblEmpFax";
            this.lblEmpFax.Size = new System.Drawing.Size(367, 28);
            this.lblEmpFax.TabIndex = 15;
            this.lblEmpFax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEmpFName
            // 
            this.lblEmpFName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpFName.Location = new System.Drawing.Point(149, 43);
            this.lblEmpFName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpFName.Name = "lblEmpFName";
            this.lblEmpFName.Size = new System.Drawing.Size(367, 28);
            this.lblEmpFName.TabIndex = 3;
            this.lblEmpFName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEmpCountry
            // 
            this.lblEmpCountry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpCountry.Location = new System.Drawing.Point(149, 185);
            this.lblEmpCountry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpCountry.Name = "lblEmpCountry";
            this.lblEmpCountry.Size = new System.Drawing.Size(367, 28);
            this.lblEmpCountry.TabIndex = 13;
            this.lblEmpCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEmpLName
            // 
            this.lblEmpLName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpLName.Location = new System.Drawing.Point(149, 71);
            this.lblEmpLName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpLName.Name = "lblEmpLName";
            this.lblEmpLName.Size = new System.Drawing.Size(367, 28);
            this.lblEmpLName.TabIndex = 5;
            this.lblEmpLName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEmpCity
            // 
            this.lblEmpCity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpCity.Location = new System.Drawing.Point(149, 156);
            this.lblEmpCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpCity.Name = "lblEmpCity";
            this.lblEmpCity.Size = new System.Drawing.Size(367, 28);
            this.lblEmpCity.TabIndex = 11;
            this.lblEmpCity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEmpPhone
            // 
            this.lblEmpPhone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpPhone.Location = new System.Drawing.Point(149, 100);
            this.lblEmpPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpPhone.Name = "lblEmpPhone";
            this.lblEmpPhone.Size = new System.Drawing.Size(367, 28);
            this.lblEmpPhone.TabIndex = 7;
            this.lblEmpPhone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEmpAddress
            // 
            this.lblEmpAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpAddress.Location = new System.Drawing.Point(149, 128);
            this.lblEmpAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpAddress.Name = "lblEmpAddress";
            this.lblEmpAddress.Size = new System.Drawing.Size(367, 28);
            this.lblEmpAddress.TabIndex = 9;
            this.lblEmpAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLogin3
            // 
            this.btnLogin3.BackColor = System.Drawing.Color.Beige;
            this.btnLogin3.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin3.Location = new System.Drawing.Point(11, 594);
            this.btnLogin3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogin3.Name = "btnLogin3";
            this.btnLogin3.Size = new System.Drawing.Size(161, 45);
            this.btnLogin3.TabIndex = 23;
            this.btnLogin3.Text = "Return to Login";
            this.btnLogin3.UseVisualStyleBackColor = false;
            // 
            // btnSaveEmp
            // 
            this.btnSaveEmp.BackColor = System.Drawing.Color.Beige;
            this.btnSaveEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveEmp.Location = new System.Drawing.Point(291, 455);
            this.btnSaveEmp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSaveEmp.Name = "btnSaveEmp";
            this.btnSaveEmp.Size = new System.Drawing.Size(161, 45);
            this.btnSaveEmp.TabIndex = 22;
            this.btnSaveEmp.Text = "Save";
            this.btnSaveEmp.UseVisualStyleBackColor = false;
            // 
            // btnEditEmp
            // 
            this.btnEditEmp.BackColor = System.Drawing.Color.Beige;
            this.btnEditEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditEmp.Location = new System.Drawing.Point(121, 455);
            this.btnEditEmp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEditEmp.Name = "btnEditEmp";
            this.btnEditEmp.Size = new System.Drawing.Size(161, 45);
            this.btnEditEmp.TabIndex = 21;
            this.btnEditEmp.Text = "Change Information";
            this.btnEditEmp.UseVisualStyleBackColor = false;
            // 
            // tabManagerInformation
            // 
            this.tabManagerInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabManagerInformation.Controls.Add(this.btnManagerCancel);
            this.tabManagerInformation.Controls.Add(this.btnManagerSave);
            this.tabManagerInformation.Controls.Add(this.btnLogin4);
            this.tabManagerInformation.Controls.Add(this.btnManagerEdit);
            this.tabManagerInformation.Controls.Add(this.label1);
            this.tabManagerInformation.Controls.Add(this.panel3);
            this.tabManagerInformation.Location = new System.Drawing.Point(4, 38);
            this.tabManagerInformation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabManagerInformation.Name = "tabManagerInformation";
            this.tabManagerInformation.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabManagerInformation.Size = new System.Drawing.Size(745, 639);
            this.tabManagerInformation.TabIndex = 3;
            this.tabManagerInformation.Text = "Manager Information";
            // 
            // btnManagerCancel
            // 
            this.btnManagerCancel.BackColor = System.Drawing.Color.Beige;
            this.btnManagerCancel.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagerCancel.Location = new System.Drawing.Point(465, 443);
            this.btnManagerCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnManagerCancel.Name = "btnManagerCancel";
            this.btnManagerCancel.Size = new System.Drawing.Size(161, 45);
            this.btnManagerCancel.TabIndex = 16;
            this.btnManagerCancel.Text = "Cancel";
            this.btnManagerCancel.UseVisualStyleBackColor = false;
            // 
            // btnManagerSave
            // 
            this.btnManagerSave.BackColor = System.Drawing.Color.Beige;
            this.btnManagerSave.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagerSave.Location = new System.Drawing.Point(296, 443);
            this.btnManagerSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnManagerSave.Name = "btnManagerSave";
            this.btnManagerSave.Size = new System.Drawing.Size(161, 45);
            this.btnManagerSave.TabIndex = 15;
            this.btnManagerSave.Text = "Save";
            this.btnManagerSave.UseVisualStyleBackColor = false;
            // 
            // btnLogin4
            // 
            this.btnLogin4.BackColor = System.Drawing.Color.Beige;
            this.btnLogin4.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin4.Location = new System.Drawing.Point(11, 581);
            this.btnLogin4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogin4.Name = "btnLogin4";
            this.btnLogin4.Size = new System.Drawing.Size(161, 47);
            this.btnLogin4.TabIndex = 14;
            this.btnLogin4.Text = "Return to Login";
            this.btnLogin4.UseVisualStyleBackColor = false;
            // 
            // btnManagerEdit
            // 
            this.btnManagerEdit.BackColor = System.Drawing.Color.Beige;
            this.btnManagerEdit.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagerEdit.Location = new System.Drawing.Point(126, 443);
            this.btnManagerEdit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnManagerEdit.Name = "btnManagerEdit";
            this.btnManagerEdit.Size = new System.Drawing.Size(161, 45);
            this.btnManagerEdit.TabIndex = 13;
            this.btnManagerEdit.Text = "Change Information";
            this.btnManagerEdit.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Copperplate Gothic Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(103, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(537, 44);
            this.label1.TabIndex = 7;
            this.label1.Text = "Customer Information";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Beige;
            this.panel3.Controls.Add(this.lblManagerID);
            this.panel3.Controls.Add(this.lbl32);
            this.panel3.Controls.Add(this.lbl33);
            this.panel3.Controls.Add(this.lbl34);
            this.panel3.Controls.Add(this.lbl35);
            this.panel3.Controls.Add(this.lbl36);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.lblManagerUserID);
            this.panel3.Controls.Add(this.lblManagerFName);
            this.panel3.Controls.Add(this.lblManagerCountry);
            this.panel3.Controls.Add(this.lblManagerLName);
            this.panel3.Controls.Add(this.lblManagerCity);
            this.panel3.Controls.Add(this.lblManagerPhone);
            this.panel3.Controls.Add(this.lblManagerAddress);
            this.panel3.Location = new System.Drawing.Point(103, 156);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(537, 255);
            this.panel3.TabIndex = 8;
            // 
            // lblManagerID
            // 
            this.lblManagerID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblManagerID.Location = new System.Drawing.Point(149, 15);
            this.lblManagerID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblManagerID.Name = "lblManagerID";
            this.lblManagerID.Size = new System.Drawing.Size(367, 28);
            this.lblManagerID.TabIndex = 18;
            this.lblManagerID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl32
            // 
            this.lbl32.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.Location = new System.Drawing.Point(20, 15);
            this.lbl32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(121, 28);
            this.lbl32.TabIndex = 0;
            this.lbl32.Text = "Manager ID:";
            this.lbl32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl33
            // 
            this.lbl33.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.Location = new System.Drawing.Point(20, 43);
            this.lbl33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(121, 28);
            this.lbl33.TabIndex = 2;
            this.lbl33.Text = "First Name:";
            this.lbl33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl34
            // 
            this.lbl34.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl34.Location = new System.Drawing.Point(20, 71);
            this.lbl34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(121, 28);
            this.lbl34.TabIndex = 4;
            this.lbl34.Text = "Last Name:";
            this.lbl34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl35
            // 
            this.lbl35.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl35.Location = new System.Drawing.Point(20, 100);
            this.lbl35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(121, 28);
            this.lbl35.TabIndex = 6;
            this.lbl35.Text = "Phone Number:";
            this.lbl35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl36
            // 
            this.lbl36.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl36.Location = new System.Drawing.Point(20, 128);
            this.lbl36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(121, 28);
            this.lbl36.TabIndex = 8;
            this.lbl36.Text = "Address:";
            this.lbl36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 156);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 28);
            this.label8.TabIndex = 10;
            this.label8.Text = "City:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 185);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 28);
            this.label9.TabIndex = 12;
            this.label9.Text = "Country:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(20, 213);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 28);
            this.label11.TabIndex = 16;
            this.label11.Text = "User ID:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblManagerUserID
            // 
            this.lblManagerUserID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblManagerUserID.Location = new System.Drawing.Point(149, 213);
            this.lblManagerUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblManagerUserID.Name = "lblManagerUserID";
            this.lblManagerUserID.Size = new System.Drawing.Size(367, 28);
            this.lblManagerUserID.TabIndex = 17;
            this.lblManagerUserID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblManagerFName
            // 
            this.lblManagerFName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblManagerFName.Location = new System.Drawing.Point(149, 43);
            this.lblManagerFName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblManagerFName.Name = "lblManagerFName";
            this.lblManagerFName.Size = new System.Drawing.Size(367, 28);
            this.lblManagerFName.TabIndex = 3;
            this.lblManagerFName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblManagerCountry
            // 
            this.lblManagerCountry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblManagerCountry.Location = new System.Drawing.Point(149, 185);
            this.lblManagerCountry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblManagerCountry.Name = "lblManagerCountry";
            this.lblManagerCountry.Size = new System.Drawing.Size(367, 28);
            this.lblManagerCountry.TabIndex = 13;
            this.lblManagerCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblManagerLName
            // 
            this.lblManagerLName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblManagerLName.Location = new System.Drawing.Point(149, 71);
            this.lblManagerLName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblManagerLName.Name = "lblManagerLName";
            this.lblManagerLName.Size = new System.Drawing.Size(367, 28);
            this.lblManagerLName.TabIndex = 5;
            this.lblManagerLName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblManagerCity
            // 
            this.lblManagerCity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblManagerCity.Location = new System.Drawing.Point(149, 156);
            this.lblManagerCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblManagerCity.Name = "lblManagerCity";
            this.lblManagerCity.Size = new System.Drawing.Size(367, 28);
            this.lblManagerCity.TabIndex = 11;
            this.lblManagerCity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblManagerPhone
            // 
            this.lblManagerPhone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblManagerPhone.Location = new System.Drawing.Point(149, 100);
            this.lblManagerPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblManagerPhone.Name = "lblManagerPhone";
            this.lblManagerPhone.Size = new System.Drawing.Size(367, 28);
            this.lblManagerPhone.TabIndex = 7;
            this.lblManagerPhone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblManagerAddress
            // 
            this.lblManagerAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblManagerAddress.Location = new System.Drawing.Point(149, 128);
            this.lblManagerAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblManagerAddress.Name = "lblManagerAddress";
            this.lblManagerAddress.Size = new System.Drawing.Size(367, 28);
            this.lblManagerAddress.TabIndex = 9;
            this.lblManagerAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(753, 681);
            this.Controls.Add(this.tbcOne);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmOrders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manger Information";
            this.Load += new System.EventHandler(this.frmOrders_Load);
            this.tbcOne.ResumeLayout(false);
            this.tabCustomerInformation.ResumeLayout(false);
            this.pnlOne.ResumeLayout(false);
            this.tabCustomerOrders.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tabEmployeeInformation.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tabManagerInformation.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcOne;
        private System.Windows.Forms.TabPage tabCustomerInformation;
        private System.Windows.Forms.Button btnNewCust;
        private System.Windows.Forms.Button btnRemoveCust;
        private System.Windows.Forms.Button btnNextCust;
        private System.Windows.Forms.Button btnPreviousCust;
        private System.Windows.Forms.Button btnCancelCust;
        private System.Windows.Forms.Button btnSaveCust;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlOne;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lblPostalCode;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label lblFax;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.Label lblLName;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnViewOrders;
        private System.Windows.Forms.Button btnEditCust;
        private System.Windows.Forms.TabPage tabCustomerOrders;
        private System.Windows.Forms.Button btnCancelOrder;
        private System.Windows.Forms.Button btnSaveOrder;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnChangeEmployee;
        private System.Windows.Forms.Button btnCustInfo;
        private System.Windows.Forms.Button btnLogin2;
        private System.Windows.Forms.Button btnNextOrder;
        private System.Windows.Forms.Button btnPreviousOrder;
        private System.Windows.Forms.Button btnDeleteOrder;
        private System.Windows.Forms.Button btnEditOrder;
        private System.Windows.Forms.Button btnReassignEmployee;
        private System.Windows.Forms.TabPage tabEmployeeInformation;
        private System.Windows.Forms.TabPage tabManagerInformation;
        private System.Windows.Forms.Button btnEmpOrdersAssigned;
        private System.Windows.Forms.Button btnEmpCustomersAssigned;
        private System.Windows.Forms.Button btnCancelEmp;
        private System.Windows.Forms.Label lblTitle3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblEmpID;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Label lblEmpUserID;
        private System.Windows.Forms.Label lblEmpFax;
        private System.Windows.Forms.Label lblEmpFName;
        private System.Windows.Forms.Label lblEmpCountry;
        private System.Windows.Forms.Label lblEmpLName;
        private System.Windows.Forms.Label lblEmpCity;
        private System.Windows.Forms.Label lblEmpPhone;
        private System.Windows.Forms.Label lblEmpAddress;
        private System.Windows.Forms.Button btnLogin3;
        private System.Windows.Forms.Button btnSaveEmp;
        private System.Windows.Forms.Button btnEditEmp;
        private System.Windows.Forms.Label lblOrderID;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lblOrderEmployeeID;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lblTotalPrice;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lblProducts;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lblOrderPostalCode;
        private System.Windows.Forms.Label lblOrderCustID;
        private System.Windows.Forms.Label lblShippedCountry;
        private System.Windows.Forms.Label lblOrderDate;
        private System.Windows.Forms.Label lblShippedCity;
        private System.Windows.Forms.Label lblShippedDate;
        private System.Windows.Forms.Label lblShippedAddress;
        private System.Windows.Forms.Button btnNextEmp;
        private System.Windows.Forms.Button btnPreviousEmp;
        private System.Windows.Forms.Button btnNewEmployee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl36;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblManagerUserID;
        private System.Windows.Forms.Label lblManagerFName;
        private System.Windows.Forms.Label lblManagerCountry;
        private System.Windows.Forms.Label lblManagerLName;
        private System.Windows.Forms.Label lblManagerCity;
        private System.Windows.Forms.Label lblManagerPhone;
        private System.Windows.Forms.Label lblManagerAddress;
        private System.Windows.Forms.Label lblManagerID;
        private System.Windows.Forms.Button btnManagerCancel;
        private System.Windows.Forms.Button btnManagerSave;
        private System.Windows.Forms.Button btnLogin4;
        private System.Windows.Forms.Button btnManagerEdit;
    }
}