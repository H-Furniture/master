﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeFurniture
{
    public partial class frmResetPassword : Form
    {
        public frmResetPassword()
        {
            InitializeComponent();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            // Close this form (go back to Main Menu)
            this.Close();
        }

        private void btnRecover_Click(object sender, EventArgs e)
        {
            // Show that email has been sent
            lblMessage.Text = "An email has been sent successfully.";

            // Verify that email exists within the database

        }
    }
}
