﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//added
using INEW2330_HomeFurniture;
namespace HomeFurniture
{
    public partial class frmEmployee : Form
    {
        public frmEmployee()
        {
            InitializeComponent();
        }

        private void frmEmployee_Load(object sender, EventArgs e)
        {
            //set to textboxes
            ProgOps.TbxEID = tbxEID;
             ProgOps.TbxEFName = tbxEFName;
            ProgOps.TbxELName = tbxELName;
            ProgOps.TbxEPhone = tbxEPhone;
            ProgOps.TbxEAddress = tbxEAddress;
            ProgOps.TbxECity = tbxECity;
            ProgOps.TbxEFAX = tbxEFax;
            ProgOps.TbxEUser = tbxEUID;
            
        }

        private void btnLogin3_Click(object sender, EventArgs e)
        {
            //set main menu to open
            frmLogin login = new frmLogin();
            //show login main menue
            login.Show();
        }
    }
}
