﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//added 
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace INEW2330_HomeFurniture
{
    class ProgOps
    {
        private const string CONNECT_STRING = @"Server=cstnt.tstc.edu;Database=inew2330sp21;User Id=group5sp212330;password=5926153";

        //variable for connection
        private static SqlConnection _connection = new SqlConnection(CONNECT_STRING);

        //variable for boolean is valid
        private static Boolean isValid;
        //public enum Person 
        public Boolean Valid
        {
            get { return isValid; }
            set { isValid = true; }

        }
        //check is valid
       
        //SQL COMMAND  ****************************************************************

        //variable for customer table command 
        private static SqlCommand sqlCustomerCommand;
        //variable for manager table command
        private static SqlCommand sqlManagerCommand;
        //variable for employee table command
        private static SqlCommand sqlEmployeeCommand;
        //variable for order table command 
        private static SqlCommand sqlOrderCommand;
        //variable for product table command
        private static SqlCommand sqlProductCommand;
        //variable for supply table command
        private static SqlCommand sqlSupplyCommand;
        //variable for user table command
        private static SqlCommand sqlUserCommand;

       
        //variable for COMMAND BUILDER updating records 
        private SqlCommandBuilder sqlCBuilder;

        //END SQL COMMAND ****************************************************************



        //DATA ADAPTER ****************************************************************

        //adds data adapter for data to be showm
        private static SqlDataAdapter daCustomer = new SqlDataAdapter();
        private static SqlDataAdapter daManager = new SqlDataAdapter();
        private static SqlDataAdapter daEmployee = new SqlDataAdapter();
        private static SqlDataAdapter daProduct = new SqlDataAdapter();
        private static SqlDataAdapter daUser = new SqlDataAdapter();
        private static SqlDataAdapter daOrder = new SqlDataAdapter();
        private static SqlDataAdapter daSupply = new SqlDataAdapter();

        //END ADAPTER ****************************************************************



        //DATA TABLES ****************************************************************

        //add data tables 
        private static DataTable dtCustomer = new DataTable();
        private static DataTable dtManager = new DataTable();
        private static DataTable dtEmployee = new DataTable();
        private static DataTable dtProduct = new DataTable();
        private static DataTable dtUser = new DataTable();
        private static DataTable dtOrder = new DataTable();
        private static DataTable dtSupply = new DataTable();
        //END DATA TABLES ****************************************************************



        //DATA SETS ****************************************************************

        //add data set 
        private static DataSet customerDS = new DataSet();
        private static DataSet managerDS = new DataSet();
        private static DataSet employeeDS = new DataSet();
        private static DataSet productDS = new DataSet();
        private static DataSet userDS = new DataSet();
        private static DataSet orderDS = new DataSet();
        private static DataSet supplyDS = new DataSet();


        //END DATA SETS ****************************************************************





        //LOGIN TEXTBOXES ****************************************************************

        private static TextBox _tbxUserName;
        private static TextBox _tbxPassword;

        public static TextBox TbxUser
        {
            get { return _tbxUserName; }
            set { _tbxUserName = value; }
        }
        public static TextBox TbxPass
        {
            get { return _tbxPassword; }
            set { _tbxPassword = value; }
        }


        //END LOGIN TEXT BOXES  ****************************************************************

        ///CUSTOMER TEXT BOXES  ****************************************************************
        //private variables
        private static TextBox customerID;
        private static TextBox cfName;
        private static TextBox clName;
        private static TextBox cphone;
        private static TextBox caddress;
        private static TextBox ccity;
        private static TextBox cstate;
        private static TextBox cfax;
        private static TextBox cuser;

        //public
        public static TextBox TbxCID
        {
            get { return customerID; }
            set { customerID = value; }
        }
        public static TextBox TbxCFName
        {
            get { return cfName; }
            set {cfName = value; }
        }

        public static TextBox TbxCLName
        {
            get { return clName; }
            set { clName = value; }
        }
        public static TextBox TbxCFAX
        {
            get { return cfax; }
            set { cfax = value; }
        }

        public static TextBox TbxCPhone
        {
            get { return cphone; }
            set { cphone = value; }
        }
        public static TextBox TbxCAddress
        {
            get { return caddress; }
            set { caddress = value; }
        }

        public static TextBox TbxCCity
        {
            get { return ccity; }
            set { ccity = value; }
        }
        public static TextBox TbxCState
        {
            get { return cstate; }
            set { cstate = value; }
        }

        public static TextBox TbxCUser
        {
            get { return cuser; }
            set { cuser = value; }
        }

        //END CUSTOMER TEXT BOXES  ****************************************************************

        ///EMPLOYEE TEXT BOXES  ****************************************************************
        //private variables
        private static TextBox employeeID;
        private static TextBox efName;
        private static TextBox elName;
        private static TextBox ephone;
        private static TextBox eaddress;
        private static TextBox ecity;
        private static TextBox estate;
        private static TextBox efax;
        private static TextBox euser;

        //public
        public static TextBox TbxEID
        {
            get { return employeeID; }
            set { employeeID = value; }
        }
        public static TextBox TbxEFName
        {
            get { return efName; }
            set { efName = value; }
        }

        public static TextBox TbxELName
        {
            get { return elName; }
            set { elName = value; }
        }
        public static TextBox TbxEFAX
        {
            get { return efax; }
            set { efax = value; }
        }

        public static TextBox TbxEPhone
        {
            get { return ephone; }
            set { ephone = value; }
        }
        public static TextBox TbxEAddress
        {
            get { return eaddress; }
            set { eaddress = value; }
        }

        public static TextBox TbxECity
        {
            get { return ecity; }
            set { ecity = value; }
        }
        public static TextBox TbxEState
        {
            get { return estate; }
            set { estate = value; }
        }

        public static TextBox TbxEUser
        {
            get { return euser; }
            set { euser = value; }
        }

        //END EMPLOYEE TEXT BOXES  ****************************************************************

        ///MANAGER TEXT BOXES  ****************************************************************
        //private variables
        private static TextBox managerID;
        private static TextBox mfName;
        private static TextBox mlName;
        private static TextBox mphone;
        private static TextBox maddress;
        private static TextBox mcity;
        private static TextBox mstate;
        private static TextBox mfax;
        private static TextBox muser;

        //public
        public static TextBox TbxMID
        {
            get { return managerID; }
            set { managerID = value; }
        }
        public static TextBox TbxMFName
        {
            get { return mfName; }
            set { mfName = value; }
        }

        public static TextBox TbxMLName
        {
            get { return mlName; }
            set { mlName = value; }
        }
        public static TextBox TbxMFAX
        {
            get { return mfax; }
            set { mfax = value; }
        }

        public static TextBox TbxMPhone
        {
            get { return mphone; }
            set { mphone = value; }
        }
        public static TextBox TbxMAddress
        {
            get { return maddress; }
            set { maddress = value; }
        }

        public static TextBox TbxMCity
        {
            get { return mcity; }
            set { mcity = value; }
        }
        public static TextBox TbxMState
        {
            get { return mstate; }
            set { mstate = value; }
        }

        public static TextBox TbxMUser
        {
            get { return muser; }
            set { muser = value; }
        }

        //END MANAGER TEXT BOXES  ****************************************************************



        //get set for connection 
        //CUSTOMER 
        public static DataTable DTCustomer
        {
            get { return dtCustomer; }
            set { dtCustomer = value; }
        }

        public static DataSet CustomerDS
        {
            get { return customerDS;}
            set { customerDS = value; }
        }

        //MANAGER
        public static DataTable DTManager
        {
            get { return dtManager; }
            set { dtManager = value; }
        }

        public static DataSet ManagerDS
        {
            get { return managerDS; }
            set { managerDS = value; }
        }

        //EMPLOYEE
        public static DataTable DTEmployee
        {
            get { return dtEmployee; }
            set { dtEmployee = value; }
        }

        public static DataSet EmployeeDS
        {
            get { return employeeDS; }
            set { employeeDS = value; }
        }
        //ORDERS
        public static DataTable DTOrder
        {
            get { return dtOrder; }
            set { dtOrder = value; }
        }

        public static DataSet OrderDS
        {
            get { return orderDS; }
            set { orderDS = value; }
        }



        //PRODUCTS 
        public static DataTable DTProduct
        {
            get { return dtProduct; }
            set { dtProduct = value; }
        }

        public static DataSet ProductDS
        {
            get { return productDS; }
            set { productDS = value; }
        }

        //USERS 
        public static DataTable DTUser
        {
            get { return dtUser; }
            set { dtUser = value; }
        }

        public static DataSet UserDS
        {
            get { return userDS; }
            set { userDS = value; }
        }
        //SUPPLY
        public static DataTable DTSupply
        {
            get { return dtSupply; }
            set { dtSupply = value; }
        }

        public static DataSet SupplyDS
        {
            get { return supplyDS; }
            set { supplyDS = value; }
        }

      //create method to open connection 
        public static void OpenConnection()
        {
            try
            {
                string query = "SELECT Email, Password, UserType FROM group5sp212330.Users";
                _connection = new SqlConnection(CONNECT_STRING);
                //opening database connection 
                _connection.Open();

                //message to show state of connection 
                MessageBox.Show(_connection.State.ToString());

                //when open connection is run, establish a connectton to the user table for logining in 
                sqlUserCommand = new SqlCommand(query, _connection);
                daUser.SelectCommand = sqlUserCommand;
                daUser.Fill(dtUser);
              
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
          
        }
        public static void CloseConnection()
        {
            try
            {
                //close connection 
                _connection.Close();
                //message showing conenction is closed
                MessageBox.Show(_connection.State.ToString());
                //dispose connection 
                _connection.Dispose();
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public static void OpenLogin(string UserName)
        {
            //string query = "SELECT Email FROM group5sp212330";
            //sqlUserCommand = new SqlCommand(query, _connection);
            //open connection 
            //OpenConnection(); Ben Edit: (Don't know why this is here)

            //check for username in database


   
        }
        public static void OpenCustomerLogin(string command)
            { 
            //set command 
            sqlCustomerCommand = new SqlCommand(command, _connection);
            //establish data adapter 
            daCustomer.SelectCommand = sqlCustomerCommand;
            //establish data table 
            daCustomer.Fill(dtCustomer);
            //bindtext boxes
            TbxCFName.DataBindings.Add(" ", dtCustomer, " ");
            TbxCLName.DataBindings.Add(" ", dtCustomer, " ");
            TbxCPhone.DataBindings.Add(" ", dtCustomer, " ");
            TbxCAddress.DataBindings.Add(" ", dtCustomer, " ");
            TbxCCity.DataBindings.Add(" ", dtCustomer, " ");
            TbxCState.DataBindings.Add(" ", dtCustomer, " ");
            TbxCFAX.DataBindings.Add(" ", dtCustomer, " ");
            TbxCUser.DataBindings.Add(" ", dtCustomer, " ");
            TbxCID.DataBindings.Add("", dtCustomer, " ");

        }
        public static void OpenEmployeeLogin(string command)
        {
           
            //set command 
            sqlEmployeeCommand = new SqlCommand(command, _connection);
            //establish data adapter 
            daEmployee.SelectCommand = sqlEmployeeCommand;

            //establish data table 
            daEmployee.Fill(dtEmployee);
            //bindtext boxes
            TbxEFName.DataBindings.Add(" ", dtEmployee, " ");
            TbxELName.DataBindings.Add(" ", dtEmployee, " ");
            TbxEPhone.DataBindings.Add(" ", dtEmployee, " ");
           TbxEAddress.DataBindings.Add(" ", dtEmployee, " ");
            TbxECity.DataBindings.Add(" ", dtEmployee, " ");
            TbxEState.DataBindings.Add(" ", dtEmployee, " ");
            TbxEFAX.DataBindings.Add(" ",  dtEmployee, " ");
            TbxEUser.DataBindings.Add(" ", dtEmployee, " ");
            TbxEID.DataBindings.Add("", dtEmployee, " ");

        }

        public static void OpenManagerLogin(string command)
        {
         
            //set command 
            sqlManagerCommand = new SqlCommand(command, _connection);
            //establish data adapter 
            daManager.SelectCommand = sqlManagerCommand;

            //establish data table 
            daManager.Fill(dtManager);
            //bindtext boxes
            TbxMFName.DataBindings.Add(" ", dtManager, " ");
            TbxMLName.DataBindings.Add(" ", dtManager, " ");
            TbxMPhone.DataBindings.Add(" ", dtManager, " ");
            TbxMAddress.DataBindings.Add(" ", dtManager, " ");
            TbxMCity.DataBindings.Add(" ", dtManager, " ");
            TbxMState.DataBindings.Add(" ", dtManager, " ");
            TbxMFAX.DataBindings.Add(" ", dtManager, " ");
            TbxMUser.DataBindings.Add(" ", dtManager, " ");
            TbxMID.DataBindings.Add("", dtManager, " ");

        }

        public static void OpenManagerData(string command, TextBox textBox)
        {
            //open connection 
            OpenConnection();
            //set command 
            sqlManagerCommand = new SqlCommand(command, _connection);
            //establish data adapter 
            daCustomer.SelectCommand = sqlCustomerCommand;
            //establish data table 
            daCustomer.Fill(dtCustomer);
            //Set to datagrid
          

            //bind text boxes 
           
        }
     
        //check for command 
        public static void CheckCommand(Form form  ,string command1, string command2, TextBox text)
        {
            Boolean commandTrue = false;
            if ( form.Text == command1)
            {
                commandTrue = true;

                while(true)
                {
                  
                
                }
            }

        }


    }//close class progOps
}//close namespace 
