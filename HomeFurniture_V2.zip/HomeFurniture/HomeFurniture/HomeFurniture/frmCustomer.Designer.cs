﻿
namespace HomeFurniture
{
    partial class frmCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcOne = new System.Windows.Forms.TabControl();
            this.tabCustomerInformation = new System.Windows.Forms.TabPage();
            this.btnCancelCust = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlOne = new System.Windows.Forms.Panel();
            this.tbxCPC = new System.Windows.Forms.TextBox();
            this.tbxCFax = new System.Windows.Forms.TextBox();
            this.tbxCUser = new System.Windows.Forms.TextBox();
            this.tbxCCountry = new System.Windows.Forms.TextBox();
            this.tbxCCity = new System.Windows.Forms.TextBox();
            this.tbxCAddress = new System.Windows.Forms.TextBox();
            this.tbxCLName = new System.Windows.Forms.TextBox();
            this.tbxCPhone = new System.Windows.Forms.TextBox();
            this.tbxCFName = new System.Windows.Forms.TextBox();
            this.tbxCID = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.btnLogout1 = new System.Windows.Forms.Button();
            this.btnSaveCust = new System.Windows.Forms.Button();
            this.btnEditCust = new System.Windows.Forms.Button();
            this.tabCustomerOrders = new System.Windows.Forms.TabPage();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbxCEmpID = new System.Windows.Forms.TextBox();
            this.tbxCPrice = new System.Windows.Forms.TextBox();
            this.tbxCPOCode = new System.Windows.Forms.TextBox();
            this.tbxCProduct = new System.Windows.Forms.TextBox();
            this.tbxCShipCountry = new System.Windows.Forms.TextBox();
            this.tbxCShipCity = new System.Windows.Forms.TextBox();
            this.tbxCShipAdd = new System.Windows.Forms.TextBox();
            this.tbxCOD = new System.Windows.Forms.TextBox();
            this.tbxCShipDate = new System.Windows.Forms.TextBox();
            this.tbxCOCID = new System.Windows.Forms.TextBox();
            this.tbxCOID = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.btnLogin2 = new System.Windows.Forms.Button();
            this.btnNextOrder = new System.Windows.Forms.Button();
            this.btnPreviousOrder = new System.Windows.Forms.Button();
            this.btnDeleteOrder = new System.Windows.Forms.Button();
            this.tbcOne.SuspendLayout();
            this.tabCustomerInformation.SuspendLayout();
            this.pnlOne.SuspendLayout();
            this.tabCustomerOrders.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcOne
            // 
            this.tbcOne.Controls.Add(this.tabCustomerInformation);
            this.tbcOne.Controls.Add(this.tabCustomerOrders);
            this.tbcOne.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcOne.Font = new System.Drawing.Font("Javanese Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcOne.Location = new System.Drawing.Point(0, 0);
            this.tbcOne.Multiline = true;
            this.tbcOne.Name = "tbcOne";
            this.tbcOne.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tbcOne.SelectedIndex = 0;
            this.tbcOne.Size = new System.Drawing.Size(565, 519);
            this.tbcOne.TabIndex = 0;
            // 
            // tabCustomerInformation
            // 
            this.tabCustomerInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabCustomerInformation.Controls.Add(this.btnCancelCust);
            this.tabCustomerInformation.Controls.Add(this.lblTitle);
            this.tabCustomerInformation.Controls.Add(this.pnlOne);
            this.tabCustomerInformation.Controls.Add(this.btnLogout1);
            this.tabCustomerInformation.Controls.Add(this.btnSaveCust);
            this.tabCustomerInformation.Controls.Add(this.btnEditCust);
            this.tabCustomerInformation.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCustomerInformation.Location = new System.Drawing.Point(4, 34);
            this.tabCustomerInformation.Name = "tabCustomerInformation";
            this.tabCustomerInformation.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabCustomerInformation.Size = new System.Drawing.Size(557, 481);
            this.tabCustomerInformation.TabIndex = 0;
            this.tabCustomerInformation.Text = "Customer Information";
            // 
            // btnCancelCust
            // 
            this.btnCancelCust.BackColor = System.Drawing.Color.Beige;
            this.btnCancelCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelCust.Location = new System.Drawing.Point(278, 369);
            this.btnCancelCust.Name = "btnCancelCust";
            this.btnCancelCust.Size = new System.Drawing.Size(121, 37);
            this.btnCancelCust.TabIndex = 4;
            this.btnCancelCust.Text = "Cancel";
            this.btnCancelCust.UseVisualStyleBackColor = false;
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(74, 20);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(403, 36);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Customer Information";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlOne
            // 
            this.pnlOne.BackColor = System.Drawing.Color.Beige;
            this.pnlOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOne.Controls.Add(this.tbxCPC);
            this.pnlOne.Controls.Add(this.tbxCFax);
            this.pnlOne.Controls.Add(this.tbxCUser);
            this.pnlOne.Controls.Add(this.tbxCCountry);
            this.pnlOne.Controls.Add(this.tbxCCity);
            this.pnlOne.Controls.Add(this.tbxCAddress);
            this.pnlOne.Controls.Add(this.tbxCLName);
            this.pnlOne.Controls.Add(this.tbxCPhone);
            this.pnlOne.Controls.Add(this.tbxCFName);
            this.pnlOne.Controls.Add(this.tbxCID);
            this.pnlOne.Controls.Add(this.lbl1);
            this.pnlOne.Controls.Add(this.lbl2);
            this.pnlOne.Controls.Add(this.lbl3);
            this.pnlOne.Controls.Add(this.lbl4);
            this.pnlOne.Controls.Add(this.lbl5);
            this.pnlOne.Controls.Add(this.lbl6);
            this.pnlOne.Controls.Add(this.lbl7);
            this.pnlOne.Controls.Add(this.lbl8);
            this.pnlOne.Controls.Add(this.lbl9);
            this.pnlOne.Controls.Add(this.lbl10);
            this.pnlOne.Location = new System.Drawing.Point(74, 57);
            this.pnlOne.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlOne.Name = "pnlOne";
            this.pnlOne.Size = new System.Drawing.Size(404, 255);
            this.pnlOne.TabIndex = 1;
            // 
            // tbxCPC
            // 
            this.tbxCPC.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCPC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCPC.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCPC.Location = new System.Drawing.Point(104, 223);
            this.tbxCPC.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCPC.Name = "tbxCPC";
            this.tbxCPC.Size = new System.Drawing.Size(275, 15);
            this.tbxCPC.TabIndex = 44;
            // 
            // tbxCFax
            // 
            this.tbxCFax.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCFax.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCFax.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCFax.Location = new System.Drawing.Point(104, 177);
            this.tbxCFax.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCFax.Name = "tbxCFax";
            this.tbxCFax.Size = new System.Drawing.Size(275, 15);
            this.tbxCFax.TabIndex = 43;
            // 
            // tbxCUser
            // 
            this.tbxCUser.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCUser.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCUser.Location = new System.Drawing.Point(104, 201);
            this.tbxCUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCUser.Name = "tbxCUser";
            this.tbxCUser.Size = new System.Drawing.Size(275, 15);
            this.tbxCUser.TabIndex = 42;
            // 
            // tbxCCountry
            // 
            this.tbxCCountry.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCCountry.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCCountry.Location = new System.Drawing.Point(104, 154);
            this.tbxCCountry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCCountry.Name = "tbxCCountry";
            this.tbxCCountry.Size = new System.Drawing.Size(275, 15);
            this.tbxCCountry.TabIndex = 41;
            // 
            // tbxCCity
            // 
            this.tbxCCity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCCity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCCity.Location = new System.Drawing.Point(104, 132);
            this.tbxCCity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCCity.Name = "tbxCCity";
            this.tbxCCity.Size = new System.Drawing.Size(275, 15);
            this.tbxCCity.TabIndex = 40;
            // 
            // tbxCAddress
            // 
            this.tbxCAddress.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCAddress.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCAddress.Location = new System.Drawing.Point(104, 109);
            this.tbxCAddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCAddress.Name = "tbxCAddress";
            this.tbxCAddress.Size = new System.Drawing.Size(275, 15);
            this.tbxCAddress.TabIndex = 39;
            // 
            // tbxCLName
            // 
            this.tbxCLName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCLName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCLName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCLName.Location = new System.Drawing.Point(104, 63);
            this.tbxCLName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCLName.Name = "tbxCLName";
            this.tbxCLName.Size = new System.Drawing.Size(275, 15);
            this.tbxCLName.TabIndex = 38;
            // 
            // tbxCPhone
            // 
            this.tbxCPhone.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCPhone.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCPhone.Location = new System.Drawing.Point(104, 86);
            this.tbxCPhone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCPhone.Name = "tbxCPhone";
            this.tbxCPhone.Size = new System.Drawing.Size(275, 15);
            this.tbxCPhone.TabIndex = 37;
            // 
            // tbxCFName
            // 
            this.tbxCFName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCFName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCFName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCFName.Location = new System.Drawing.Point(104, 40);
            this.tbxCFName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCFName.Name = "tbxCFName";
            this.tbxCFName.Size = new System.Drawing.Size(275, 15);
            this.tbxCFName.TabIndex = 36;
            // 
            // tbxCID
            // 
            this.tbxCID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCID.Location = new System.Drawing.Point(104, 17);
            this.tbxCID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCID.Name = "tbxCID";
            this.tbxCID.Size = new System.Drawing.Size(275, 15);
            this.tbxCID.TabIndex = 35;
            // 
            // lbl1
            // 
            this.lbl1.Location = new System.Drawing.Point(15, 12);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(91, 23);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Customer ID:";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl2
            // 
            this.lbl2.Location = new System.Drawing.Point(15, 35);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(91, 23);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "First Name:";
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl3
            // 
            this.lbl3.Location = new System.Drawing.Point(15, 58);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(91, 23);
            this.lbl3.TabIndex = 4;
            this.lbl3.Text = "Last Name:";
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl4
            // 
            this.lbl4.Location = new System.Drawing.Point(15, 81);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(91, 23);
            this.lbl4.TabIndex = 6;
            this.lbl4.Text = "Phone Number:";
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl5
            // 
            this.lbl5.Location = new System.Drawing.Point(15, 104);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(91, 23);
            this.lbl5.TabIndex = 8;
            this.lbl5.Text = "Address:";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl6
            // 
            this.lbl6.Location = new System.Drawing.Point(15, 127);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(91, 23);
            this.lbl6.TabIndex = 10;
            this.lbl6.Text = "City:";
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl7
            // 
            this.lbl7.Location = new System.Drawing.Point(15, 150);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(91, 23);
            this.lbl7.TabIndex = 12;
            this.lbl7.Text = "State:";
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl8
            // 
            this.lbl8.Location = new System.Drawing.Point(15, 173);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(91, 23);
            this.lbl8.TabIndex = 14;
            this.lbl8.Text = "Fax:";
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl9
            // 
            this.lbl9.Location = new System.Drawing.Point(15, 196);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(91, 23);
            this.lbl9.TabIndex = 16;
            this.lbl9.Text = "User ID:";
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl10
            // 
            this.lbl10.Location = new System.Drawing.Point(15, 219);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(91, 23);
            this.lbl10.TabIndex = 18;
            this.lbl10.Text = "Postal Code:";
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLogout1
            // 
            this.btnLogout1.BackColor = System.Drawing.Color.Beige;
            this.btnLogout1.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout1.Location = new System.Drawing.Point(6, 434);
            this.btnLogout1.Name = "btnLogout1";
            this.btnLogout1.Size = new System.Drawing.Size(121, 37);
            this.btnLogout1.TabIndex = 5;
            this.btnLogout1.Text = "Main Menu";
            this.btnLogout1.UseVisualStyleBackColor = false;
            // 
            // btnSaveCust
            // 
            this.btnSaveCust.BackColor = System.Drawing.Color.Beige;
            this.btnSaveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCust.Location = new System.Drawing.Point(151, 369);
            this.btnSaveCust.Name = "btnSaveCust";
            this.btnSaveCust.Size = new System.Drawing.Size(121, 37);
            this.btnSaveCust.TabIndex = 3;
            this.btnSaveCust.Text = "Save";
            this.btnSaveCust.UseVisualStyleBackColor = false;
            // 
            // btnEditCust
            // 
            this.btnEditCust.BackColor = System.Drawing.Color.Beige;
            this.btnEditCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditCust.Location = new System.Drawing.Point(215, 316);
            this.btnEditCust.Name = "btnEditCust";
            this.btnEditCust.Size = new System.Drawing.Size(121, 37);
            this.btnEditCust.TabIndex = 2;
            this.btnEditCust.Text = "Change Information";
            this.btnEditCust.UseVisualStyleBackColor = false;
            // 
            // tabCustomerOrders
            // 
            this.tabCustomerOrders.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerOrders.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabCustomerOrders.Controls.Add(this.lblTitle2);
            this.tabCustomerOrders.Controls.Add(this.panel1);
            this.tabCustomerOrders.Controls.Add(this.btnLogin2);
            this.tabCustomerOrders.Controls.Add(this.btnNextOrder);
            this.tabCustomerOrders.Controls.Add(this.btnPreviousOrder);
            this.tabCustomerOrders.Controls.Add(this.btnDeleteOrder);
            this.tabCustomerOrders.Location = new System.Drawing.Point(4, 34);
            this.tabCustomerOrders.Name = "tabCustomerOrders";
            this.tabCustomerOrders.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabCustomerOrders.Size = new System.Drawing.Size(557, 481);
            this.tabCustomerOrders.TabIndex = 1;
            this.tabCustomerOrders.Text = "Customer Orders";
            // 
            // lblTitle2
            // 
            this.lblTitle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle2.Location = new System.Drawing.Point(105, 10);
            this.lblTitle2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(342, 36);
            this.lblTitle2.TabIndex = 3;
            this.lblTitle2.Text = "View Orders";
            this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Beige;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tbxCEmpID);
            this.panel1.Controls.Add(this.tbxCPrice);
            this.panel1.Controls.Add(this.tbxCPOCode);
            this.panel1.Controls.Add(this.tbxCProduct);
            this.panel1.Controls.Add(this.tbxCShipCountry);
            this.panel1.Controls.Add(this.tbxCShipCity);
            this.panel1.Controls.Add(this.tbxCShipAdd);
            this.panel1.Controls.Add(this.tbxCOD);
            this.panel1.Controls.Add(this.tbxCShipDate);
            this.panel1.Controls.Add(this.tbxCOCID);
            this.panel1.Controls.Add(this.tbxCOID);
            this.panel1.Controls.Add(this.lbl12);
            this.panel1.Controls.Add(this.lbl13);
            this.panel1.Controls.Add(this.lbl14);
            this.panel1.Controls.Add(this.lbl15);
            this.panel1.Controls.Add(this.lbl16);
            this.panel1.Controls.Add(this.lbl17);
            this.panel1.Controls.Add(this.lbl18);
            this.panel1.Controls.Add(this.lbl19);
            this.panel1.Controls.Add(this.lbl20);
            this.panel1.Controls.Add(this.lbl21);
            this.panel1.Controls.Add(this.lbl22);
            this.panel1.Location = new System.Drawing.Point(105, 48);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(343, 321);
            this.panel1.TabIndex = 40;
            // 
            // tbxCEmpID
            // 
            this.tbxCEmpID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCEmpID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCEmpID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCEmpID.Location = new System.Drawing.Point(96, 292);
            this.tbxCEmpID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCEmpID.Name = "tbxCEmpID";
            this.tbxCEmpID.Size = new System.Drawing.Size(234, 15);
            this.tbxCEmpID.TabIndex = 56;
            // 
            // tbxCPrice
            // 
            this.tbxCPrice.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCPrice.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCPrice.Location = new System.Drawing.Point(96, 266);
            this.tbxCPrice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCPrice.Name = "tbxCPrice";
            this.tbxCPrice.Size = new System.Drawing.Size(234, 15);
            this.tbxCPrice.TabIndex = 55;
            // 
            // tbxCPOCode
            // 
            this.tbxCPOCode.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCPOCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCPOCode.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCPOCode.Location = new System.Drawing.Point(96, 174);
            this.tbxCPOCode.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCPOCode.Name = "tbxCPOCode";
            this.tbxCPOCode.Size = new System.Drawing.Size(234, 15);
            this.tbxCPOCode.TabIndex = 54;
            // 
            // tbxCProduct
            // 
            this.tbxCProduct.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCProduct.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCProduct.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCProduct.Location = new System.Drawing.Point(96, 196);
            this.tbxCProduct.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCProduct.Multiline = true;
            this.tbxCProduct.Name = "tbxCProduct";
            this.tbxCProduct.Size = new System.Drawing.Size(234, 60);
            this.tbxCProduct.TabIndex = 53;
            // 
            // tbxCShipCountry
            // 
            this.tbxCShipCountry.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCShipCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCShipCountry.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCShipCountry.Location = new System.Drawing.Point(96, 150);
            this.tbxCShipCountry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCShipCountry.Name = "tbxCShipCountry";
            this.tbxCShipCountry.Size = new System.Drawing.Size(234, 15);
            this.tbxCShipCountry.TabIndex = 52;
            // 
            // tbxCShipCity
            // 
            this.tbxCShipCity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCShipCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCShipCity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCShipCity.Location = new System.Drawing.Point(96, 127);
            this.tbxCShipCity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCShipCity.Name = "tbxCShipCity";
            this.tbxCShipCity.Size = new System.Drawing.Size(234, 15);
            this.tbxCShipCity.TabIndex = 51;
            // 
            // tbxCShipAdd
            // 
            this.tbxCShipAdd.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCShipAdd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCShipAdd.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCShipAdd.Location = new System.Drawing.Point(96, 104);
            this.tbxCShipAdd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCShipAdd.Name = "tbxCShipAdd";
            this.tbxCShipAdd.Size = new System.Drawing.Size(234, 15);
            this.tbxCShipAdd.TabIndex = 50;
            // 
            // tbxCOD
            // 
            this.tbxCOD.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCOD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCOD.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCOD.Location = new System.Drawing.Point(96, 59);
            this.tbxCOD.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCOD.Name = "tbxCOD";
            this.tbxCOD.Size = new System.Drawing.Size(234, 15);
            this.tbxCOD.TabIndex = 49;
            // 
            // tbxCShipDate
            // 
            this.tbxCShipDate.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCShipDate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCShipDate.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCShipDate.Location = new System.Drawing.Point(96, 82);
            this.tbxCShipDate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCShipDate.Name = "tbxCShipDate";
            this.tbxCShipDate.Size = new System.Drawing.Size(234, 15);
            this.tbxCShipDate.TabIndex = 48;
            // 
            // tbxCOCID
            // 
            this.tbxCOCID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCOCID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCOCID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCOCID.Location = new System.Drawing.Point(96, 37);
            this.tbxCOCID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCOCID.Name = "tbxCOCID";
            this.tbxCOCID.Size = new System.Drawing.Size(234, 15);
            this.tbxCOCID.TabIndex = 47;
            // 
            // tbxCOID
            // 
            this.tbxCOID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCOID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCOID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCOID.Location = new System.Drawing.Point(96, 13);
            this.tbxCOID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCOID.Name = "tbxCOID";
            this.tbxCOID.Size = new System.Drawing.Size(234, 15);
            this.tbxCOID.TabIndex = 46;
            // 
            // lbl12
            // 
            this.lbl12.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.Location = new System.Drawing.Point(5, 8);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(91, 23);
            this.lbl12.TabIndex = 22;
            this.lbl12.Text = "Order ID:";
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl13
            // 
            this.lbl13.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.Location = new System.Drawing.Point(5, 32);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(91, 23);
            this.lbl13.TabIndex = 24;
            this.lbl13.Text = "Customer ID:";
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl14
            // 
            this.lbl14.Location = new System.Drawing.Point(5, 54);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(91, 23);
            this.lbl14.TabIndex = 26;
            this.lbl14.Text = "Order Date:";
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl15
            // 
            this.lbl15.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.Location = new System.Drawing.Point(5, 77);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(91, 23);
            this.lbl15.TabIndex = 28;
            this.lbl15.Text = "Shipped Date:";
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl16
            // 
            this.lbl16.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl16.Location = new System.Drawing.Point(3, 99);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(93, 23);
            this.lbl16.TabIndex = 30;
            this.lbl16.Text = "Shipped Address:";
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl17
            // 
            this.lbl17.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17.Location = new System.Drawing.Point(5, 124);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(91, 23);
            this.lbl17.TabIndex = 32;
            this.lbl17.Text = "Shipped City:";
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl18
            // 
            this.lbl18.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl18.Location = new System.Drawing.Point(3, 146);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(93, 23);
            this.lbl18.TabIndex = 34;
            this.lbl18.Text = "Shipped Country:";
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl19
            // 
            this.lbl19.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl19.Location = new System.Drawing.Point(5, 169);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(91, 23);
            this.lbl19.TabIndex = 36;
            this.lbl19.Text = "Postal Code:";
            this.lbl19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl20
            // 
            this.lbl20.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl20.Location = new System.Drawing.Point(5, 193);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(91, 70);
            this.lbl20.TabIndex = 38;
            this.lbl20.Text = "Products:";
            this.lbl20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl21
            // 
            this.lbl21.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.Location = new System.Drawing.Point(5, 264);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(91, 23);
            this.lbl21.TabIndex = 40;
            this.lbl21.Text = "Total Price:";
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl22
            // 
            this.lbl22.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.Location = new System.Drawing.Point(5, 287);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(91, 23);
            this.lbl22.TabIndex = 42;
            this.lbl22.Text = "Employee ID:";
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLogin2
            // 
            this.btnLogin2.BackColor = System.Drawing.Color.Beige;
            this.btnLogin2.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin2.Location = new System.Drawing.Point(6, 434);
            this.btnLogin2.Name = "btnLogin2";
            this.btnLogin2.Size = new System.Drawing.Size(121, 37);
            this.btnLogin2.TabIndex = 38;
            this.btnLogin2.Text = "Main Menu";
            this.btnLogin2.UseVisualStyleBackColor = false;
            this.btnLogin2.Click += new System.EventHandler(this.btnLogin2_Click);
            // 
            // btnNextOrder
            // 
            this.btnNextOrder.BackColor = System.Drawing.Color.Beige;
            this.btnNextOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextOrder.Location = new System.Drawing.Point(216, 383);
            this.btnNextOrder.Name = "btnNextOrder";
            this.btnNextOrder.Size = new System.Drawing.Size(121, 37);
            this.btnNextOrder.TabIndex = 35;
            this.btnNextOrder.Text = "Next Page";
            this.btnNextOrder.UseVisualStyleBackColor = false;
            // 
            // btnPreviousOrder
            // 
            this.btnPreviousOrder.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousOrder.Location = new System.Drawing.Point(89, 383);
            this.btnPreviousOrder.Name = "btnPreviousOrder";
            this.btnPreviousOrder.Size = new System.Drawing.Size(121, 37);
            this.btnPreviousOrder.TabIndex = 34;
            this.btnPreviousOrder.Text = "Previous Page";
            this.btnPreviousOrder.UseVisualStyleBackColor = false;
            // 
            // btnDeleteOrder
            // 
            this.btnDeleteOrder.BackColor = System.Drawing.Color.Beige;
            this.btnDeleteOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteOrder.Location = new System.Drawing.Point(343, 383);
            this.btnDeleteOrder.Name = "btnDeleteOrder";
            this.btnDeleteOrder.Size = new System.Drawing.Size(121, 37);
            this.btnDeleteOrder.TabIndex = 33;
            this.btnDeleteOrder.Text = "Delete Order";
            this.btnDeleteOrder.UseVisualStyleBackColor = false;
            // 
            // frmCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(565, 519);
            this.Controls.Add(this.tbcOne);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmCustomer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Data";
            this.Load += new System.EventHandler(this.frmCustomer_Load);
            this.tbcOne.ResumeLayout(false);
            this.tabCustomerInformation.ResumeLayout(false);
            this.pnlOne.ResumeLayout(false);
            this.pnlOne.PerformLayout();
            this.tabCustomerOrders.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcOne;
        private System.Windows.Forms.TabPage tabCustomerInformation;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlOne;
        private System.Windows.Forms.Button btnLogout1;
        private System.Windows.Forms.Button btnSaveCust;
        private System.Windows.Forms.Button btnEditCust;
        private System.Windows.Forms.TabPage tabCustomerOrders;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnLogin2;
        private System.Windows.Forms.Button btnNextOrder;
        private System.Windows.Forms.Button btnPreviousOrder;
        private System.Windows.Forms.Button btnDeleteOrder;
        private System.Windows.Forms.Button btnCancelCust;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.TextBox tbxCPC;
        private System.Windows.Forms.TextBox tbxCFax;
        private System.Windows.Forms.TextBox tbxCUser;
        private System.Windows.Forms.TextBox tbxCCountry;
        private System.Windows.Forms.TextBox tbxCCity;
        private System.Windows.Forms.TextBox tbxCAddress;
        private System.Windows.Forms.TextBox tbxCLName;
        private System.Windows.Forms.TextBox tbxCPhone;
        private System.Windows.Forms.TextBox tbxCFName;
        private System.Windows.Forms.TextBox tbxCID;
        private System.Windows.Forms.TextBox tbxCEmpID;
        private System.Windows.Forms.TextBox tbxCPrice;
        private System.Windows.Forms.TextBox tbxCPOCode;
        private System.Windows.Forms.TextBox tbxCProduct;
        private System.Windows.Forms.TextBox tbxCShipCountry;
        private System.Windows.Forms.TextBox tbxCShipCity;
        private System.Windows.Forms.TextBox tbxCShipAdd;
        private System.Windows.Forms.TextBox tbxCOD;
        private System.Windows.Forms.TextBox tbxCShipDate;
        private System.Windows.Forms.TextBox tbxCOCID;
        private System.Windows.Forms.TextBox tbxCOID;
    }
}