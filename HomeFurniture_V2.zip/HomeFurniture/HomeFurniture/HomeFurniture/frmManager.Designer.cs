﻿
namespace HomeFurniture
{
    partial class frmOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcOne = new System.Windows.Forms.TabControl();
            this.tabCustomerInformation = new System.Windows.Forms.TabPage();
            this.btnReassignEmployee = new System.Windows.Forms.Button();
            this.btnNewCust = new System.Windows.Forms.Button();
            this.btnRemoveCust = new System.Windows.Forms.Button();
            this.btnNextCust = new System.Windows.Forms.Button();
            this.btnPreviousCust = new System.Windows.Forms.Button();
            this.btnCancelCust = new System.Windows.Forms.Button();
            this.btnSaveCust = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlOne = new System.Windows.Forms.Panel();
            this.tbxECPC = new System.Windows.Forms.TextBox();
            this.tbxECFax = new System.Windows.Forms.TextBox();
            this.tbxECUser = new System.Windows.Forms.TextBox();
            this.tbxECCountry = new System.Windows.Forms.TextBox();
            this.tbxECCity = new System.Windows.Forms.TextBox();
            this.tbxECAddress = new System.Windows.Forms.TextBox();
            this.tbxECLName = new System.Windows.Forms.TextBox();
            this.tbxECPhone = new System.Windows.Forms.TextBox();
            this.tbxECFName = new System.Windows.Forms.TextBox();
            this.tbxECID = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnViewOrders = new System.Windows.Forms.Button();
            this.btnEditCust = new System.Windows.Forms.Button();
            this.tabCustomerOrders = new System.Windows.Forms.TabPage();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.btnSaveOrder = new System.Windows.Forms.Button();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.tbxCOCID = new System.Windows.Forms.TextBox();
            this.tbxECOID = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.btnChangeEmployee = new System.Windows.Forms.Button();
            this.btnCustInfo = new System.Windows.Forms.Button();
            this.btnLogin2 = new System.Windows.Forms.Button();
            this.btnNextOrder = new System.Windows.Forms.Button();
            this.btnPreviousOrder = new System.Windows.Forms.Button();
            this.btnDeleteOrder = new System.Windows.Forms.Button();
            this.btnEditOrder = new System.Windows.Forms.Button();
            this.tabEmployeeInformation = new System.Windows.Forms.TabPage();
            this.btnNewEmployee = new System.Windows.Forms.Button();
            this.btnNextEmp = new System.Windows.Forms.Button();
            this.btnPreviousEmp = new System.Windows.Forms.Button();
            this.btnEmpOrdersAssigned = new System.Windows.Forms.Button();
            this.btnEmpCustomersAssigned = new System.Windows.Forms.Button();
            this.btnCancelEmp = new System.Windows.Forms.Button();
            this.lblTitle3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl26 = new System.Windows.Forms.Label();
            this.lbl27 = new System.Windows.Forms.Label();
            this.lbl28 = new System.Windows.Forms.Label();
            this.lbl29 = new System.Windows.Forms.Label();
            this.lbl30 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.btnLogin3 = new System.Windows.Forms.Button();
            this.btnSaveEmp = new System.Windows.Forms.Button();
            this.btnEditEmp = new System.Windows.Forms.Button();
            this.tabManagerInformation = new System.Windows.Forms.TabPage();
            this.btnManagerCancel = new System.Windows.Forms.Button();
            this.btnManagerSave = new System.Windows.Forms.Button();
            this.btnLogin4 = new System.Windows.Forms.Button();
            this.btnManagerEdit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.tbxMCounty = new System.Windows.Forms.TextBox();
            this.tbxMCity = new System.Windows.Forms.TextBox();
            this.tbxMAddress = new System.Windows.Forms.TextBox();
            this.tbxMLName = new System.Windows.Forms.TextBox();
            this.tbxMPhone = new System.Windows.Forms.TextBox();
            this.tbxMFName = new System.Windows.Forms.TextBox();
            this.tbxMID = new System.Windows.Forms.TextBox();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl36 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tbcOne.SuspendLayout();
            this.tabCustomerInformation.SuspendLayout();
            this.pnlOne.SuspendLayout();
            this.tabCustomerOrders.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabEmployeeInformation.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabManagerInformation.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcOne
            // 
            this.tbcOne.Controls.Add(this.tabCustomerInformation);
            this.tbcOne.Controls.Add(this.tabCustomerOrders);
            this.tbcOne.Controls.Add(this.tabEmployeeInformation);
            this.tbcOne.Controls.Add(this.tabManagerInformation);
            this.tbcOne.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcOne.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcOne.Location = new System.Drawing.Point(0, 0);
            this.tbcOne.Multiline = true;
            this.tbcOne.Name = "tbcOne";
            this.tbcOne.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tbcOne.SelectedIndex = 0;
            this.tbcOne.Size = new System.Drawing.Size(565, 557);
            this.tbcOne.TabIndex = 0;
            // 
            // tabCustomerInformation
            // 
            this.tabCustomerInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabCustomerInformation.Controls.Add(this.btnReassignEmployee);
            this.tabCustomerInformation.Controls.Add(this.btnNewCust);
            this.tabCustomerInformation.Controls.Add(this.btnRemoveCust);
            this.tabCustomerInformation.Controls.Add(this.btnNextCust);
            this.tabCustomerInformation.Controls.Add(this.btnPreviousCust);
            this.tabCustomerInformation.Controls.Add(this.btnCancelCust);
            this.tabCustomerInformation.Controls.Add(this.btnSaveCust);
            this.tabCustomerInformation.Controls.Add(this.lblTitle);
            this.tabCustomerInformation.Controls.Add(this.pnlOne);
            this.tabCustomerInformation.Controls.Add(this.btnLogout);
            this.tabCustomerInformation.Controls.Add(this.btnViewOrders);
            this.tabCustomerInformation.Controls.Add(this.btnEditCust);
            this.tabCustomerInformation.Location = new System.Drawing.Point(4, 32);
            this.tabCustomerInformation.Name = "tabCustomerInformation";
            this.tabCustomerInformation.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabCustomerInformation.Size = new System.Drawing.Size(557, 521);
            this.tabCustomerInformation.TabIndex = 0;
            this.tabCustomerInformation.Text = "Customer Information";
            // 
            // btnReassignEmployee
            // 
            this.btnReassignEmployee.BackColor = System.Drawing.Color.Beige;
            this.btnReassignEmployee.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReassignEmployee.Location = new System.Drawing.Point(213, 420);
            this.btnReassignEmployee.Name = "btnReassignEmployee";
            this.btnReassignEmployee.Size = new System.Drawing.Size(121, 37);
            this.btnReassignEmployee.TabIndex = 9;
            this.btnReassignEmployee.Text = "Reassign Employee";
            this.btnReassignEmployee.UseVisualStyleBackColor = false;
            // 
            // btnNewCust
            // 
            this.btnNewCust.BackColor = System.Drawing.Color.Beige;
            this.btnNewCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewCust.Location = new System.Drawing.Point(357, 420);
            this.btnNewCust.Name = "btnNewCust";
            this.btnNewCust.Size = new System.Drawing.Size(121, 37);
            this.btnNewCust.TabIndex = 10;
            this.btnNewCust.Text = "Add New Customer";
            this.btnNewCust.UseVisualStyleBackColor = false;
            // 
            // btnRemoveCust
            // 
            this.btnRemoveCust.BackColor = System.Drawing.Color.Beige;
            this.btnRemoveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveCust.Location = new System.Drawing.Point(357, 367);
            this.btnRemoveCust.Name = "btnRemoveCust";
            this.btnRemoveCust.Size = new System.Drawing.Size(121, 37);
            this.btnRemoveCust.TabIndex = 7;
            this.btnRemoveCust.Text = "Remove Customer";
            this.btnRemoveCust.UseVisualStyleBackColor = false;
            // 
            // btnNextCust
            // 
            this.btnNextCust.BackColor = System.Drawing.Color.Beige;
            this.btnNextCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextCust.Location = new System.Drawing.Point(357, 314);
            this.btnNextCust.Name = "btnNextCust";
            this.btnNextCust.Size = new System.Drawing.Size(121, 37);
            this.btnNextCust.TabIndex = 4;
            this.btnNextCust.Text = "Next Customer";
            this.btnNextCust.UseVisualStyleBackColor = false;
            // 
            // btnPreviousCust
            // 
            this.btnPreviousCust.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousCust.Location = new System.Drawing.Point(213, 314);
            this.btnPreviousCust.Name = "btnPreviousCust";
            this.btnPreviousCust.Size = new System.Drawing.Size(121, 37);
            this.btnPreviousCust.TabIndex = 3;
            this.btnPreviousCust.Text = "Previous Customer";
            this.btnPreviousCust.UseVisualStyleBackColor = false;
            // 
            // btnCancelCust
            // 
            this.btnCancelCust.BackColor = System.Drawing.Color.Beige;
            this.btnCancelCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelCust.Location = new System.Drawing.Point(74, 420);
            this.btnCancelCust.Name = "btnCancelCust";
            this.btnCancelCust.Size = new System.Drawing.Size(121, 37);
            this.btnCancelCust.TabIndex = 8;
            this.btnCancelCust.Text = "Cancel";
            this.btnCancelCust.UseVisualStyleBackColor = false;
            // 
            // btnSaveCust
            // 
            this.btnSaveCust.BackColor = System.Drawing.Color.Beige;
            this.btnSaveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCust.Location = new System.Drawing.Point(74, 367);
            this.btnSaveCust.Name = "btnSaveCust";
            this.btnSaveCust.Size = new System.Drawing.Size(121, 37);
            this.btnSaveCust.TabIndex = 5;
            this.btnSaveCust.Text = "Save";
            this.btnSaveCust.UseVisualStyleBackColor = false;
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(74, 9);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(403, 36);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Customer Information";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlOne
            // 
            this.pnlOne.BackColor = System.Drawing.Color.Beige;
            this.pnlOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOne.Controls.Add(this.tbxECPC);
            this.pnlOne.Controls.Add(this.tbxECFax);
            this.pnlOne.Controls.Add(this.tbxECUser);
            this.pnlOne.Controls.Add(this.tbxECCountry);
            this.pnlOne.Controls.Add(this.tbxECCity);
            this.pnlOne.Controls.Add(this.tbxECAddress);
            this.pnlOne.Controls.Add(this.tbxECLName);
            this.pnlOne.Controls.Add(this.tbxECPhone);
            this.pnlOne.Controls.Add(this.tbxECFName);
            this.pnlOne.Controls.Add(this.tbxECID);
            this.pnlOne.Controls.Add(this.lbl1);
            this.pnlOne.Controls.Add(this.lbl2);
            this.pnlOne.Controls.Add(this.lbl3);
            this.pnlOne.Controls.Add(this.lbl4);
            this.pnlOne.Controls.Add(this.lbl5);
            this.pnlOne.Controls.Add(this.lbl6);
            this.pnlOne.Controls.Add(this.lbl7);
            this.pnlOne.Controls.Add(this.lbl8);
            this.pnlOne.Controls.Add(this.lbl9);
            this.pnlOne.Controls.Add(this.lbl10);
            this.pnlOne.Location = new System.Drawing.Point(74, 46);
            this.pnlOne.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlOne.Name = "pnlOne";
            this.pnlOne.Size = new System.Drawing.Size(404, 255);
            this.pnlOne.TabIndex = 1;
            // 
            // tbxECPC
            // 
            this.tbxECPC.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECPC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECPC.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECPC.Location = new System.Drawing.Point(110, 223);
            this.tbxECPC.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECPC.Name = "tbxECPC";
            this.tbxECPC.Size = new System.Drawing.Size(275, 15);
            this.tbxECPC.TabIndex = 44;
            // 
            // tbxECFax
            // 
            this.tbxECFax.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECFax.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECFax.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECFax.Location = new System.Drawing.Point(110, 176);
            this.tbxECFax.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECFax.Name = "tbxECFax";
            this.tbxECFax.Size = new System.Drawing.Size(275, 15);
            this.tbxECFax.TabIndex = 43;
            // 
            // tbxECUser
            // 
            this.tbxECUser.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECUser.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECUser.Location = new System.Drawing.Point(110, 200);
            this.tbxECUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECUser.Name = "tbxECUser";
            this.tbxECUser.Size = new System.Drawing.Size(275, 15);
            this.tbxECUser.TabIndex = 42;
            // 
            // tbxECCountry
            // 
            this.tbxECCountry.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECCountry.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECCountry.Location = new System.Drawing.Point(110, 154);
            this.tbxECCountry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECCountry.Name = "tbxECCountry";
            this.tbxECCountry.Size = new System.Drawing.Size(275, 15);
            this.tbxECCountry.TabIndex = 41;
            // 
            // tbxECCity
            // 
            this.tbxECCity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECCity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECCity.Location = new System.Drawing.Point(110, 131);
            this.tbxECCity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECCity.Name = "tbxECCity";
            this.tbxECCity.Size = new System.Drawing.Size(275, 15);
            this.tbxECCity.TabIndex = 40;
            // 
            // tbxECAddress
            // 
            this.tbxECAddress.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECAddress.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECAddress.Location = new System.Drawing.Point(110, 108);
            this.tbxECAddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECAddress.Name = "tbxECAddress";
            this.tbxECAddress.Size = new System.Drawing.Size(275, 15);
            this.tbxECAddress.TabIndex = 39;
            // 
            // tbxECLName
            // 
            this.tbxECLName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECLName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECLName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECLName.Location = new System.Drawing.Point(110, 62);
            this.tbxECLName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECLName.Name = "tbxECLName";
            this.tbxECLName.Size = new System.Drawing.Size(275, 15);
            this.tbxECLName.TabIndex = 38;
            // 
            // tbxECPhone
            // 
            this.tbxECPhone.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECPhone.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECPhone.Location = new System.Drawing.Point(110, 85);
            this.tbxECPhone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECPhone.Name = "tbxECPhone";
            this.tbxECPhone.Size = new System.Drawing.Size(275, 15);
            this.tbxECPhone.TabIndex = 37;
            // 
            // tbxECFName
            // 
            this.tbxECFName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECFName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECFName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECFName.Location = new System.Drawing.Point(110, 39);
            this.tbxECFName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECFName.Name = "tbxECFName";
            this.tbxECFName.Size = new System.Drawing.Size(275, 15);
            this.tbxECFName.TabIndex = 36;
            // 
            // tbxECID
            // 
            this.tbxECID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECID.Location = new System.Drawing.Point(110, 16);
            this.tbxECID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECID.Name = "tbxECID";
            this.tbxECID.Size = new System.Drawing.Size(275, 15);
            this.tbxECID.TabIndex = 35;
            // 
            // lbl1
            // 
            this.lbl1.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(14, 11);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(91, 23);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Customer ID:";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl2
            // 
            this.lbl2.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(14, 34);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(91, 23);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "First Name:";
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl3
            // 
            this.lbl3.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(14, 57);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(91, 23);
            this.lbl3.TabIndex = 4;
            this.lbl3.Text = "Last Name:";
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl4
            // 
            this.lbl4.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.Location = new System.Drawing.Point(14, 80);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(91, 23);
            this.lbl4.TabIndex = 6;
            this.lbl4.Text = "Phone Number:";
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl5
            // 
            this.lbl5.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(14, 103);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(91, 23);
            this.lbl5.TabIndex = 8;
            this.lbl5.Text = "Address:";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl6
            // 
            this.lbl6.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.Location = new System.Drawing.Point(14, 126);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(91, 23);
            this.lbl6.TabIndex = 10;
            this.lbl6.Text = "City:";
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl7
            // 
            this.lbl7.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.Location = new System.Drawing.Point(14, 150);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(91, 23);
            this.lbl7.TabIndex = 12;
            this.lbl7.Text = "Country:";
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl8
            // 
            this.lbl8.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.Location = new System.Drawing.Point(14, 172);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(91, 23);
            this.lbl8.TabIndex = 14;
            this.lbl8.Text = "Fax:";
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl9
            // 
            this.lbl9.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.Location = new System.Drawing.Point(14, 195);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(91, 23);
            this.lbl9.TabIndex = 16;
            this.lbl9.Text = "User ID:";
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl10
            // 
            this.lbl10.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10.Location = new System.Drawing.Point(14, 219);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(91, 23);
            this.lbl10.TabIndex = 18;
            this.lbl10.Text = "Postal Code:";
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Beige;
            this.btnLogout.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(6, 474);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(121, 37);
            this.btnLogout.TabIndex = 11;
            this.btnLogout.Text = "Main Menu";
            this.btnLogout.UseVisualStyleBackColor = false;
            // 
            // btnViewOrders
            // 
            this.btnViewOrders.BackColor = System.Drawing.Color.Beige;
            this.btnViewOrders.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewOrders.Location = new System.Drawing.Point(213, 367);
            this.btnViewOrders.Name = "btnViewOrders";
            this.btnViewOrders.Size = new System.Drawing.Size(121, 37);
            this.btnViewOrders.TabIndex = 6;
            this.btnViewOrders.Text = "View Orders";
            this.btnViewOrders.UseVisualStyleBackColor = false;
            // 
            // btnEditCust
            // 
            this.btnEditCust.BackColor = System.Drawing.Color.Beige;
            this.btnEditCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditCust.Location = new System.Drawing.Point(74, 314);
            this.btnEditCust.Name = "btnEditCust";
            this.btnEditCust.Size = new System.Drawing.Size(121, 37);
            this.btnEditCust.TabIndex = 2;
            this.btnEditCust.Text = "Change Information";
            this.btnEditCust.UseVisualStyleBackColor = false;
            // 
            // tabCustomerOrders
            // 
            this.tabCustomerOrders.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerOrders.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabCustomerOrders.Controls.Add(this.btnCancelOrder);
            this.tabCustomerOrders.Controls.Add(this.btnSaveOrder);
            this.tabCustomerOrders.Controls.Add(this.lblTitle2);
            this.tabCustomerOrders.Controls.Add(this.panel1);
            this.tabCustomerOrders.Controls.Add(this.btnChangeEmployee);
            this.tabCustomerOrders.Controls.Add(this.btnCustInfo);
            this.tabCustomerOrders.Controls.Add(this.btnLogin2);
            this.tabCustomerOrders.Controls.Add(this.btnNextOrder);
            this.tabCustomerOrders.Controls.Add(this.btnPreviousOrder);
            this.tabCustomerOrders.Controls.Add(this.btnDeleteOrder);
            this.tabCustomerOrders.Controls.Add(this.btnEditOrder);
            this.tabCustomerOrders.Location = new System.Drawing.Point(4, 32);
            this.tabCustomerOrders.Name = "tabCustomerOrders";
            this.tabCustomerOrders.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabCustomerOrders.Size = new System.Drawing.Size(557, 521);
            this.tabCustomerOrders.TabIndex = 1;
            this.tabCustomerOrders.Text = "Customer Orders";
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnCancelOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelOrder.Location = new System.Drawing.Point(281, 377);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(121, 37);
            this.btnCancelOrder.TabIndex = 43;
            this.btnCancelOrder.Text = "Cancel";
            this.btnCancelOrder.UseVisualStyleBackColor = false;
            // 
            // btnSaveOrder
            // 
            this.btnSaveOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnSaveOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveOrder.Location = new System.Drawing.Point(154, 377);
            this.btnSaveOrder.Name = "btnSaveOrder";
            this.btnSaveOrder.Size = new System.Drawing.Size(121, 37);
            this.btnSaveOrder.TabIndex = 42;
            this.btnSaveOrder.Text = "Save";
            this.btnSaveOrder.UseVisualStyleBackColor = false;
            // 
            // lblTitle2
            // 
            this.lblTitle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle2.Location = new System.Drawing.Point(91, 4);
            this.lblTitle2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(374, 36);
            this.lblTitle2.TabIndex = 41;
            this.lblTitle2.Text = "View Orders";
            this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Beige;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.textBox11);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox8);
            this.panel1.Controls.Add(this.tbxCOCID);
            this.panel1.Controls.Add(this.tbxECOID);
            this.panel1.Controls.Add(this.lbl12);
            this.panel1.Controls.Add(this.lbl13);
            this.panel1.Controls.Add(this.lbl14);
            this.panel1.Controls.Add(this.lbl15);
            this.panel1.Controls.Add(this.lbl16);
            this.panel1.Controls.Add(this.lbl17);
            this.panel1.Controls.Add(this.lbl18);
            this.panel1.Controls.Add(this.lbl19);
            this.panel1.Controls.Add(this.lbl20);
            this.panel1.Controls.Add(this.lbl21);
            this.panel1.Controls.Add(this.lbl22);
            this.panel1.Location = new System.Drawing.Point(91, 42);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(375, 321);
            this.panel1.TabIndex = 40;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.LightCyan;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(115, 289);
            this.textBox11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(234, 15);
            this.textBox11.TabIndex = 56;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.LightCyan;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(115, 264);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(234, 15);
            this.textBox1.TabIndex = 55;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.LightCyan;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(115, 171);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(234, 15);
            this.textBox2.TabIndex = 54;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.LightCyan;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(115, 193);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(234, 60);
            this.textBox3.TabIndex = 53;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.LightCyan;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(115, 147);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(234, 15);
            this.textBox4.TabIndex = 52;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.LightCyan;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(115, 124);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(234, 15);
            this.textBox5.TabIndex = 51;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.LightCyan;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(115, 102);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(234, 15);
            this.textBox6.TabIndex = 50;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.LightCyan;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(115, 57);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(234, 15);
            this.textBox7.TabIndex = 49;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.LightCyan;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(115, 80);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(234, 15);
            this.textBox8.TabIndex = 48;
            // 
            // tbxCOCID
            // 
            this.tbxCOCID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCOCID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCOCID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCOCID.Location = new System.Drawing.Point(115, 34);
            this.tbxCOCID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxCOCID.Name = "tbxCOCID";
            this.tbxCOCID.Size = new System.Drawing.Size(234, 15);
            this.tbxCOCID.TabIndex = 47;
            // 
            // tbxECOID
            // 
            this.tbxECOID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECOID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECOID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECOID.Location = new System.Drawing.Point(115, 11);
            this.tbxECOID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxECOID.Name = "tbxECOID";
            this.tbxECOID.Size = new System.Drawing.Size(234, 15);
            this.tbxECOID.TabIndex = 46;
            // 
            // lbl12
            // 
            this.lbl12.Location = new System.Drawing.Point(19, 11);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(91, 23);
            this.lbl12.TabIndex = 22;
            this.lbl12.Text = "Order ID:";
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl13
            // 
            this.lbl13.Location = new System.Drawing.Point(19, 34);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(91, 23);
            this.lbl13.TabIndex = 24;
            this.lbl13.Text = "Customer ID:";
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl14
            // 
            this.lbl14.Location = new System.Drawing.Point(19, 57);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(91, 23);
            this.lbl14.TabIndex = 26;
            this.lbl14.Text = "Order Date:";
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl15
            // 
            this.lbl15.Location = new System.Drawing.Point(19, 80);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(91, 23);
            this.lbl15.TabIndex = 28;
            this.lbl15.Text = "Shipped Date:";
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl16
            // 
            this.lbl16.Location = new System.Drawing.Point(19, 103);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(91, 23);
            this.lbl16.TabIndex = 30;
            this.lbl16.Text = "Shipped Address:";
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl17
            // 
            this.lbl17.Location = new System.Drawing.Point(19, 126);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(91, 23);
            this.lbl17.TabIndex = 32;
            this.lbl17.Text = "Shipped City:";
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl18
            // 
            this.lbl18.Location = new System.Drawing.Point(19, 149);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(91, 23);
            this.lbl18.TabIndex = 34;
            this.lbl18.Text = "Shipped Country:";
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl19
            // 
            this.lbl19.Location = new System.Drawing.Point(19, 171);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(91, 23);
            this.lbl19.TabIndex = 36;
            this.lbl19.Text = "Postal Code:";
            this.lbl19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl20
            // 
            this.lbl20.Location = new System.Drawing.Point(19, 195);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(91, 70);
            this.lbl20.TabIndex = 38;
            this.lbl20.Text = "Products:";
            this.lbl20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl21
            // 
            this.lbl21.Location = new System.Drawing.Point(19, 265);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(91, 23);
            this.lbl21.TabIndex = 40;
            this.lbl21.Text = "Total Price:";
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl22
            // 
            this.lbl22.Location = new System.Drawing.Point(19, 288);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(91, 23);
            this.lbl22.TabIndex = 42;
            this.lbl22.Text = "Employee ID:";
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnChangeEmployee
            // 
            this.btnChangeEmployee.BackColor = System.Drawing.SystemColors.Info;
            this.btnChangeEmployee.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangeEmployee.Location = new System.Drawing.Point(408, 377);
            this.btnChangeEmployee.Name = "btnChangeEmployee";
            this.btnChangeEmployee.Size = new System.Drawing.Size(121, 37);
            this.btnChangeEmployee.TabIndex = 37;
            this.btnChangeEmployee.Text = "Change Employee";
            this.btnChangeEmployee.UseVisualStyleBackColor = false;
            // 
            // btnCustInfo
            // 
            this.btnCustInfo.BackColor = System.Drawing.SystemColors.Info;
            this.btnCustInfo.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustInfo.Location = new System.Drawing.Point(408, 420);
            this.btnCustInfo.Name = "btnCustInfo";
            this.btnCustInfo.Size = new System.Drawing.Size(121, 37);
            this.btnCustInfo.TabIndex = 36;
            this.btnCustInfo.Text = "Customer Information";
            this.btnCustInfo.UseVisualStyleBackColor = false;
            // 
            // btnLogin2
            // 
            this.btnLogin2.BackColor = System.Drawing.SystemColors.Info;
            this.btnLogin2.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin2.Location = new System.Drawing.Point(27, 463);
            this.btnLogin2.Name = "btnLogin2";
            this.btnLogin2.Size = new System.Drawing.Size(121, 37);
            this.btnLogin2.TabIndex = 38;
            this.btnLogin2.Text = "Main Menu";
            this.btnLogin2.UseVisualStyleBackColor = false;
            this.btnLogin2.Click += new System.EventHandler(this.btnLogin2_Click);
            // 
            // btnNextOrder
            // 
            this.btnNextOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnNextOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextOrder.Location = new System.Drawing.Point(154, 420);
            this.btnNextOrder.Name = "btnNextOrder";
            this.btnNextOrder.Size = new System.Drawing.Size(121, 37);
            this.btnNextOrder.TabIndex = 35;
            this.btnNextOrder.Text = "Next Page";
            this.btnNextOrder.UseVisualStyleBackColor = false;
            // 
            // btnPreviousOrder
            // 
            this.btnPreviousOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnPreviousOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousOrder.Location = new System.Drawing.Point(281, 420);
            this.btnPreviousOrder.Name = "btnPreviousOrder";
            this.btnPreviousOrder.Size = new System.Drawing.Size(121, 37);
            this.btnPreviousOrder.TabIndex = 34;
            this.btnPreviousOrder.Text = "Previous Page";
            this.btnPreviousOrder.UseVisualStyleBackColor = false;
            // 
            // btnDeleteOrder
            // 
            this.btnDeleteOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnDeleteOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteOrder.Location = new System.Drawing.Point(27, 420);
            this.btnDeleteOrder.Name = "btnDeleteOrder";
            this.btnDeleteOrder.Size = new System.Drawing.Size(121, 37);
            this.btnDeleteOrder.TabIndex = 33;
            this.btnDeleteOrder.Text = "Delete Order";
            this.btnDeleteOrder.UseVisualStyleBackColor = false;
            // 
            // btnEditOrder
            // 
            this.btnEditOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnEditOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditOrder.Location = new System.Drawing.Point(27, 377);
            this.btnEditOrder.Name = "btnEditOrder";
            this.btnEditOrder.Size = new System.Drawing.Size(121, 37);
            this.btnEditOrder.TabIndex = 32;
            this.btnEditOrder.Text = "Edit Order";
            this.btnEditOrder.UseVisualStyleBackColor = false;
            // 
            // tabEmployeeInformation
            // 
            this.tabEmployeeInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabEmployeeInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabEmployeeInformation.Controls.Add(this.btnNewEmployee);
            this.tabEmployeeInformation.Controls.Add(this.btnNextEmp);
            this.tabEmployeeInformation.Controls.Add(this.btnPreviousEmp);
            this.tabEmployeeInformation.Controls.Add(this.btnEmpOrdersAssigned);
            this.tabEmployeeInformation.Controls.Add(this.btnEmpCustomersAssigned);
            this.tabEmployeeInformation.Controls.Add(this.btnCancelEmp);
            this.tabEmployeeInformation.Controls.Add(this.lblTitle3);
            this.tabEmployeeInformation.Controls.Add(this.panel2);
            this.tabEmployeeInformation.Controls.Add(this.btnLogin3);
            this.tabEmployeeInformation.Controls.Add(this.btnSaveEmp);
            this.tabEmployeeInformation.Controls.Add(this.btnEditEmp);
            this.tabEmployeeInformation.Location = new System.Drawing.Point(4, 32);
            this.tabEmployeeInformation.Name = "tabEmployeeInformation";
            this.tabEmployeeInformation.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabEmployeeInformation.Size = new System.Drawing.Size(557, 521);
            this.tabEmployeeInformation.TabIndex = 2;
            this.tabEmployeeInformation.Text = "Employee Information";
            // 
            // btnNewEmployee
            // 
            this.btnNewEmployee.BackColor = System.Drawing.Color.Beige;
            this.btnNewEmployee.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewEmployee.Location = new System.Drawing.Point(345, 422);
            this.btnNewEmployee.Name = "btnNewEmployee";
            this.btnNewEmployee.Size = new System.Drawing.Size(121, 37);
            this.btnNewEmployee.TabIndex = 29;
            this.btnNewEmployee.Text = "Add New Employee";
            this.btnNewEmployee.UseVisualStyleBackColor = false;
            // 
            // btnNextEmp
            // 
            this.btnNextEmp.BackColor = System.Drawing.Color.Beige;
            this.btnNextEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextEmp.Location = new System.Drawing.Point(343, 317);
            this.btnNextEmp.Name = "btnNextEmp";
            this.btnNextEmp.Size = new System.Drawing.Size(121, 37);
            this.btnNextEmp.TabIndex = 28;
            this.btnNextEmp.Text = "Next Employee";
            this.btnNextEmp.UseVisualStyleBackColor = false;
            // 
            // btnPreviousEmp
            // 
            this.btnPreviousEmp.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousEmp.Location = new System.Drawing.Point(91, 317);
            this.btnPreviousEmp.Name = "btnPreviousEmp";
            this.btnPreviousEmp.Size = new System.Drawing.Size(121, 37);
            this.btnPreviousEmp.TabIndex = 27;
            this.btnPreviousEmp.Text = "Previous Employee";
            this.btnPreviousEmp.UseVisualStyleBackColor = false;
            // 
            // btnEmpOrdersAssigned
            // 
            this.btnEmpOrdersAssigned.BackColor = System.Drawing.Color.Beige;
            this.btnEmpOrdersAssigned.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpOrdersAssigned.Location = new System.Drawing.Point(218, 422);
            this.btnEmpOrdersAssigned.Name = "btnEmpOrdersAssigned";
            this.btnEmpOrdersAssigned.Size = new System.Drawing.Size(121, 37);
            this.btnEmpOrdersAssigned.TabIndex = 26;
            this.btnEmpOrdersAssigned.Text = "Orders Assigned";
            this.btnEmpOrdersAssigned.UseVisualStyleBackColor = false;
            // 
            // btnEmpCustomersAssigned
            // 
            this.btnEmpCustomersAssigned.BackColor = System.Drawing.Color.Beige;
            this.btnEmpCustomersAssigned.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpCustomersAssigned.Location = new System.Drawing.Point(91, 422);
            this.btnEmpCustomersAssigned.Name = "btnEmpCustomersAssigned";
            this.btnEmpCustomersAssigned.Size = new System.Drawing.Size(121, 37);
            this.btnEmpCustomersAssigned.TabIndex = 25;
            this.btnEmpCustomersAssigned.Text = "Customers Assigned";
            this.btnEmpCustomersAssigned.UseVisualStyleBackColor = false;
            // 
            // btnCancelEmp
            // 
            this.btnCancelEmp.BackColor = System.Drawing.Color.Beige;
            this.btnCancelEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelEmp.Location = new System.Drawing.Point(345, 370);
            this.btnCancelEmp.Name = "btnCancelEmp";
            this.btnCancelEmp.Size = new System.Drawing.Size(121, 37);
            this.btnCancelEmp.TabIndex = 24;
            this.btnCancelEmp.Text = "Cancel";
            this.btnCancelEmp.UseVisualStyleBackColor = false;
            // 
            // lblTitle3
            // 
            this.lblTitle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle3.Location = new System.Drawing.Point(77, 32);
            this.lblTitle3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle3.Name = "lblTitle3";
            this.lblTitle3.Size = new System.Drawing.Size(403, 36);
            this.lblTitle3.TabIndex = 19;
            this.lblTitle3.Text = "Employee Information";
            this.lblTitle3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Beige;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.textBox10);
            this.panel2.Controls.Add(this.textBox12);
            this.panel2.Controls.Add(this.textBox13);
            this.panel2.Controls.Add(this.textBox14);
            this.panel2.Controls.Add(this.textBox15);
            this.panel2.Controls.Add(this.textBox16);
            this.panel2.Controls.Add(this.textBox17);
            this.panel2.Controls.Add(this.textBox18);
            this.panel2.Controls.Add(this.textBox19);
            this.panel2.Controls.Add(this.lbl23);
            this.panel2.Controls.Add(this.lbl24);
            this.panel2.Controls.Add(this.lbl25);
            this.panel2.Controls.Add(this.lbl26);
            this.panel2.Controls.Add(this.lbl27);
            this.panel2.Controls.Add(this.lbl28);
            this.panel2.Controls.Add(this.lbl29);
            this.panel2.Controls.Add(this.lbl30);
            this.panel2.Controls.Add(this.lbl31);
            this.panel2.Location = new System.Drawing.Point(77, 70);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(404, 232);
            this.panel2.TabIndex = 20;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.LightCyan;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(104, 177);
            this.textBox10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(275, 15);
            this.textBox10.TabIndex = 43;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.LightCyan;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox12.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(104, 201);
            this.textBox12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(275, 15);
            this.textBox12.TabIndex = 42;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.LightCyan;
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox13.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(104, 154);
            this.textBox13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(275, 15);
            this.textBox13.TabIndex = 41;
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.Color.LightCyan;
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox14.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(104, 132);
            this.textBox14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(275, 15);
            this.textBox14.TabIndex = 40;
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.LightCyan;
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox15.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(104, 109);
            this.textBox15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(275, 15);
            this.textBox15.TabIndex = 39;
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.LightCyan;
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox16.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(104, 63);
            this.textBox16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(275, 15);
            this.textBox16.TabIndex = 38;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.Color.LightCyan;
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox17.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(104, 86);
            this.textBox17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(275, 15);
            this.textBox17.TabIndex = 37;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.Color.LightCyan;
            this.textBox18.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox18.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(104, 40);
            this.textBox18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(275, 15);
            this.textBox18.TabIndex = 36;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.Color.LightCyan;
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox19.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(104, 17);
            this.textBox19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(275, 15);
            this.textBox19.TabIndex = 35;
            // 
            // lbl23
            // 
            this.lbl23.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.Location = new System.Drawing.Point(15, 12);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(91, 23);
            this.lbl23.TabIndex = 0;
            this.lbl23.Text = "Employee ID:";
            this.lbl23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl24
            // 
            this.lbl24.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.Location = new System.Drawing.Point(15, 35);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(91, 23);
            this.lbl24.TabIndex = 2;
            this.lbl24.Text = "First Name:";
            this.lbl24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl25
            // 
            this.lbl25.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.Location = new System.Drawing.Point(15, 58);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(91, 23);
            this.lbl25.TabIndex = 4;
            this.lbl25.Text = "Last Name:";
            this.lbl25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl26
            // 
            this.lbl26.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26.Location = new System.Drawing.Point(15, 81);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(91, 23);
            this.lbl26.TabIndex = 6;
            this.lbl26.Text = "Phone Number:";
            this.lbl26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl27
            // 
            this.lbl27.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27.Location = new System.Drawing.Point(15, 104);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(91, 23);
            this.lbl27.TabIndex = 8;
            this.lbl27.Text = "Address:";
            this.lbl27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl28
            // 
            this.lbl28.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl28.Location = new System.Drawing.Point(15, 127);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(91, 23);
            this.lbl28.TabIndex = 10;
            this.lbl28.Text = "City:";
            this.lbl28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl29
            // 
            this.lbl29.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl29.Location = new System.Drawing.Point(15, 150);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(91, 23);
            this.lbl29.TabIndex = 12;
            this.lbl29.Text = "Country:";
            this.lbl29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl30
            // 
            this.lbl30.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl30.Location = new System.Drawing.Point(15, 173);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(91, 23);
            this.lbl30.TabIndex = 14;
            this.lbl30.Text = "Fax:";
            this.lbl30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl31
            // 
            this.lbl31.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.Location = new System.Drawing.Point(15, 196);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(91, 23);
            this.lbl31.TabIndex = 16;
            this.lbl31.Text = "User ID:";
            this.lbl31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLogin3
            // 
            this.btnLogin3.BackColor = System.Drawing.Color.Beige;
            this.btnLogin3.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin3.Location = new System.Drawing.Point(6, 474);
            this.btnLogin3.Name = "btnLogin3";
            this.btnLogin3.Size = new System.Drawing.Size(121, 37);
            this.btnLogin3.TabIndex = 23;
            this.btnLogin3.Text = "Main Menu";
            this.btnLogin3.UseVisualStyleBackColor = false;
            // 
            // btnSaveEmp
            // 
            this.btnSaveEmp.BackColor = System.Drawing.Color.Beige;
            this.btnSaveEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveEmp.Location = new System.Drawing.Point(218, 370);
            this.btnSaveEmp.Name = "btnSaveEmp";
            this.btnSaveEmp.Size = new System.Drawing.Size(121, 37);
            this.btnSaveEmp.TabIndex = 22;
            this.btnSaveEmp.Text = "Save";
            this.btnSaveEmp.UseVisualStyleBackColor = false;
            // 
            // btnEditEmp
            // 
            this.btnEditEmp.BackColor = System.Drawing.Color.Beige;
            this.btnEditEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditEmp.Location = new System.Drawing.Point(91, 370);
            this.btnEditEmp.Name = "btnEditEmp";
            this.btnEditEmp.Size = new System.Drawing.Size(121, 37);
            this.btnEditEmp.TabIndex = 21;
            this.btnEditEmp.Text = "Change Information";
            this.btnEditEmp.UseVisualStyleBackColor = false;
            // 
            // tabManagerInformation
            // 
            this.tabManagerInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabManagerInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabManagerInformation.Controls.Add(this.btnManagerCancel);
            this.tabManagerInformation.Controls.Add(this.btnManagerSave);
            this.tabManagerInformation.Controls.Add(this.btnLogin4);
            this.tabManagerInformation.Controls.Add(this.btnManagerEdit);
            this.tabManagerInformation.Controls.Add(this.label1);
            this.tabManagerInformation.Controls.Add(this.panel3);
            this.tabManagerInformation.Location = new System.Drawing.Point(4, 32);
            this.tabManagerInformation.Name = "tabManagerInformation";
            this.tabManagerInformation.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabManagerInformation.Size = new System.Drawing.Size(557, 521);
            this.tabManagerInformation.TabIndex = 3;
            this.tabManagerInformation.Text = "Manager Information";
            // 
            // btnManagerCancel
            // 
            this.btnManagerCancel.BackColor = System.Drawing.Color.Beige;
            this.btnManagerCancel.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagerCancel.Location = new System.Drawing.Point(349, 360);
            this.btnManagerCancel.Name = "btnManagerCancel";
            this.btnManagerCancel.Size = new System.Drawing.Size(121, 37);
            this.btnManagerCancel.TabIndex = 16;
            this.btnManagerCancel.Text = "Cancel";
            this.btnManagerCancel.UseVisualStyleBackColor = false;
            // 
            // btnManagerSave
            // 
            this.btnManagerSave.BackColor = System.Drawing.Color.Beige;
            this.btnManagerSave.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagerSave.Location = new System.Drawing.Point(222, 360);
            this.btnManagerSave.Name = "btnManagerSave";
            this.btnManagerSave.Size = new System.Drawing.Size(121, 37);
            this.btnManagerSave.TabIndex = 15;
            this.btnManagerSave.Text = "Save";
            this.btnManagerSave.UseVisualStyleBackColor = false;
            // 
            // btnLogin4
            // 
            this.btnLogin4.BackColor = System.Drawing.Color.Beige;
            this.btnLogin4.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin4.Location = new System.Drawing.Point(8, 472);
            this.btnLogin4.Name = "btnLogin4";
            this.btnLogin4.Size = new System.Drawing.Size(121, 38);
            this.btnLogin4.TabIndex = 14;
            this.btnLogin4.Text = "Main Menu";
            this.btnLogin4.UseVisualStyleBackColor = false;
            // 
            // btnManagerEdit
            // 
            this.btnManagerEdit.BackColor = System.Drawing.Color.Beige;
            this.btnManagerEdit.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagerEdit.Location = new System.Drawing.Point(94, 360);
            this.btnManagerEdit.Name = "btnManagerEdit";
            this.btnManagerEdit.Size = new System.Drawing.Size(121, 37);
            this.btnManagerEdit.TabIndex = 13;
            this.btnManagerEdit.Text = "Change Information";
            this.btnManagerEdit.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(77, 89);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(403, 36);
            this.label1.TabIndex = 7;
            this.label1.Text = "Manager Information";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Beige;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.textBox9);
            this.panel3.Controls.Add(this.tbxMCounty);
            this.panel3.Controls.Add(this.tbxMCity);
            this.panel3.Controls.Add(this.tbxMAddress);
            this.panel3.Controls.Add(this.tbxMLName);
            this.panel3.Controls.Add(this.tbxMPhone);
            this.panel3.Controls.Add(this.tbxMFName);
            this.panel3.Controls.Add(this.tbxMID);
            this.panel3.Controls.Add(this.lbl32);
            this.panel3.Controls.Add(this.lbl33);
            this.panel3.Controls.Add(this.lbl34);
            this.panel3.Controls.Add(this.lbl35);
            this.panel3.Controls.Add(this.lbl36);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Location = new System.Drawing.Point(77, 127);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(404, 208);
            this.panel3.TabIndex = 8;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.LightCyan;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(103, 177);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(275, 15);
            this.textBox9.TabIndex = 52;
            // 
            // tbxMCounty
            // 
            this.tbxMCounty.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMCounty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMCounty.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMCounty.Location = new System.Drawing.Point(103, 154);
            this.tbxMCounty.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxMCounty.Name = "tbxMCounty";
            this.tbxMCounty.Size = new System.Drawing.Size(275, 15);
            this.tbxMCounty.TabIndex = 50;
            // 
            // tbxMCity
            // 
            this.tbxMCity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMCity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMCity.Location = new System.Drawing.Point(103, 132);
            this.tbxMCity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxMCity.Name = "tbxMCity";
            this.tbxMCity.Size = new System.Drawing.Size(275, 15);
            this.tbxMCity.TabIndex = 49;
            // 
            // tbxMAddress
            // 
            this.tbxMAddress.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMAddress.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMAddress.Location = new System.Drawing.Point(103, 109);
            this.tbxMAddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxMAddress.Name = "tbxMAddress";
            this.tbxMAddress.Size = new System.Drawing.Size(275, 15);
            this.tbxMAddress.TabIndex = 48;
            // 
            // tbxMLName
            // 
            this.tbxMLName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMLName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMLName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMLName.Location = new System.Drawing.Point(103, 63);
            this.tbxMLName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxMLName.Name = "tbxMLName";
            this.tbxMLName.Size = new System.Drawing.Size(275, 15);
            this.tbxMLName.TabIndex = 47;
            // 
            // tbxMPhone
            // 
            this.tbxMPhone.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMPhone.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMPhone.Location = new System.Drawing.Point(103, 86);
            this.tbxMPhone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxMPhone.Name = "tbxMPhone";
            this.tbxMPhone.Size = new System.Drawing.Size(275, 15);
            this.tbxMPhone.TabIndex = 46;
            // 
            // tbxMFName
            // 
            this.tbxMFName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMFName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMFName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMFName.Location = new System.Drawing.Point(103, 40);
            this.tbxMFName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxMFName.Name = "tbxMFName";
            this.tbxMFName.Size = new System.Drawing.Size(275, 15);
            this.tbxMFName.TabIndex = 45;
            // 
            // tbxMID
            // 
            this.tbxMID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMID.Location = new System.Drawing.Point(103, 17);
            this.tbxMID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxMID.Name = "tbxMID";
            this.tbxMID.Size = new System.Drawing.Size(275, 15);
            this.tbxMID.TabIndex = 44;
            // 
            // lbl32
            // 
            this.lbl32.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.Location = new System.Drawing.Point(14, 12);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(91, 23);
            this.lbl32.TabIndex = 0;
            this.lbl32.Text = "Manager ID:";
            this.lbl32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl33
            // 
            this.lbl33.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.Location = new System.Drawing.Point(14, 35);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(91, 23);
            this.lbl33.TabIndex = 2;
            this.lbl33.Text = "First Name:";
            this.lbl33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl34
            // 
            this.lbl34.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl34.Location = new System.Drawing.Point(14, 58);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(91, 23);
            this.lbl34.TabIndex = 4;
            this.lbl34.Text = "Last Name:";
            this.lbl34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl35
            // 
            this.lbl35.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl35.Location = new System.Drawing.Point(14, 81);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(91, 23);
            this.lbl35.TabIndex = 6;
            this.lbl35.Text = "Phone Number:";
            this.lbl35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl36
            // 
            this.lbl36.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl36.Location = new System.Drawing.Point(14, 104);
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(91, 23);
            this.lbl36.TabIndex = 8;
            this.lbl36.Text = "Address:";
            this.lbl36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 127);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 23);
            this.label8.TabIndex = 10;
            this.label8.Text = "City:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 150);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 23);
            this.label9.TabIndex = 12;
            this.label9.Text = "Country:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(14, 173);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 23);
            this.label11.TabIndex = 16;
            this.label11.Text = "User ID:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(565, 557);
            this.Controls.Add(this.tbcOne);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmOrders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manger Information";
            this.Load += new System.EventHandler(this.frmOrders_Load);
            this.tbcOne.ResumeLayout(false);
            this.tabCustomerInformation.ResumeLayout(false);
            this.pnlOne.ResumeLayout(false);
            this.pnlOne.PerformLayout();
            this.tabCustomerOrders.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabEmployeeInformation.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabManagerInformation.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcOne;
        private System.Windows.Forms.TabPage tabCustomerInformation;
        private System.Windows.Forms.Button btnNewCust;
        private System.Windows.Forms.Button btnRemoveCust;
        private System.Windows.Forms.Button btnNextCust;
        private System.Windows.Forms.Button btnPreviousCust;
        private System.Windows.Forms.Button btnCancelCust;
        private System.Windows.Forms.Button btnSaveCust;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlOne;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnViewOrders;
        private System.Windows.Forms.Button btnEditCust;
        private System.Windows.Forms.TabPage tabCustomerOrders;
        private System.Windows.Forms.Button btnCancelOrder;
        private System.Windows.Forms.Button btnSaveOrder;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnChangeEmployee;
        private System.Windows.Forms.Button btnCustInfo;
        private System.Windows.Forms.Button btnLogin2;
        private System.Windows.Forms.Button btnNextOrder;
        private System.Windows.Forms.Button btnPreviousOrder;
        private System.Windows.Forms.Button btnDeleteOrder;
        private System.Windows.Forms.Button btnEditOrder;
        private System.Windows.Forms.Button btnReassignEmployee;
        private System.Windows.Forms.TabPage tabEmployeeInformation;
        private System.Windows.Forms.TabPage tabManagerInformation;
        private System.Windows.Forms.Button btnEmpOrdersAssigned;
        private System.Windows.Forms.Button btnEmpCustomersAssigned;
        private System.Windows.Forms.Button btnCancelEmp;
        private System.Windows.Forms.Label lblTitle3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Button btnLogin3;
        private System.Windows.Forms.Button btnSaveEmp;
        private System.Windows.Forms.Button btnEditEmp;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Button btnNextEmp;
        private System.Windows.Forms.Button btnPreviousEmp;
        private System.Windows.Forms.Button btnNewEmployee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl36;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnManagerCancel;
        private System.Windows.Forms.Button btnManagerSave;
        private System.Windows.Forms.Button btnLogin4;
        private System.Windows.Forms.Button btnManagerEdit;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox tbxCOCID;
        private System.Windows.Forms.TextBox tbxECOID;
        private System.Windows.Forms.TextBox tbxECPC;
        private System.Windows.Forms.TextBox tbxECFax;
        private System.Windows.Forms.TextBox tbxECUser;
        private System.Windows.Forms.TextBox tbxECCountry;
        private System.Windows.Forms.TextBox tbxECCity;
        private System.Windows.Forms.TextBox tbxECAddress;
        private System.Windows.Forms.TextBox tbxECLName;
        private System.Windows.Forms.TextBox tbxECPhone;
        private System.Windows.Forms.TextBox tbxECFName;
        private System.Windows.Forms.TextBox tbxECID;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox tbxMCounty;
        private System.Windows.Forms.TextBox tbxMCity;
        private System.Windows.Forms.TextBox tbxMAddress;
        private System.Windows.Forms.TextBox tbxMLName;
        private System.Windows.Forms.TextBox tbxMPhone;
        private System.Windows.Forms.TextBox tbxMFName;
        private System.Windows.Forms.TextBox tbxMID;
    }
}