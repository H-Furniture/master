﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//added
using INEW2330_HomeFurniture;

namespace HomeFurniture
{
    public partial class frmOrders : Form
    {
        public frmOrders()
        {
            InitializeComponent();
        }

        private void frmOrders_Load(object sender, EventArgs e)
        {
            //set text data
            ProgOps.TbxMID = tbxMID;
            ProgOps.TbxMFName = tbxMFName;
            ProgOps.TbxMLName = tbxMLName;
            ProgOps.TbxMPhone = tbxMPhone;
            ProgOps.TbxMAddress = tbxMAddress;
            ProgOps.TbxMCity = tbxMCity;
            ProgOps.TbxMUser = tbxMID;
        }

        private void btnLogin2_Click(object sender, EventArgs e)
        {
            //set main menu to open
            frmLogin login = new frmLogin();
            //show login main menue
            login.Show();
        }
    }
}
