﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using INEW2330_HomeFurniture; //added

namespace HomeFurniture
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }


        public void btnLogin_Click(object sender, EventArgs e)
        {
            // Format/validate Username and Password textboxes (delete spaces, etc.)
            
            
            // Check to see if the user put iny information in
            if(tbxUserName.Text != "" && tbxPassword.Text != "")
            {
                //load database connection when login clicked

                //ProgOps.OpenConnection(); Ben Edit: This is done on form load now

                //add textboxes to ProgOps for use in the Create Data method                
                //(These may not be needed because we can already see what the username is)
                //ProgOps.TbxUser.Text = tbxUserName.Text;
                //ProgOps.TbxPass.Text = tbxPassword.Text;

                //variables for login
                string userName = "", password = "", Type = "";
                Boolean loginSuccess = false;
                DataRow[] foundUsername, foundPassword, userType;

                //set's the user login information to variables
                userName = tbxUserName.Text;
                password = tbxPassword.Text;

                //runs a select statement to see how many (if any) user names in the database are the same as the user enetered
                foundUsername = ProgOps.DTUser.Select("Email LIKE '" + userName + "'");

                //if any of the usernames in the database match the one entered
                if (foundUsername.Length != 0)
                {
                    //if any of the passowrds in the database match the ones entered by the user WHILE the username continues to match
                    foundPassword = ProgOps.DTUser.Select("Email LIKE '" + userName + "' AND Password LIKE'" + password + "'");
                    //if the above statement is true, the it will log in (currently working on displaying the data below
                    if (foundPassword.Length != 0)
                    {
                        //just to display that login was success for testing
                        loginSuccess = true;
                        MessageBox.Show("This Works!!!!!");
                    }
                    else
                    {
                        //if the passowrd doesn't match while username is matching
                        MessageBox.Show("Your Username and/or Passowrd is incorrect, please enter the correct\n information and try again");
                    }
                }
                else
                {
                    //if the username doesn't match
                    MessageBox.Show("Your Username and/or Passowrd is incorrect, please enter the correct\n information and try again");
                }

                //if login was successful 
                if (loginSuccess == true)
                {
                    //checks if the user is a customer
                    userType = ProgOps.DTUser.Select("Email LIKE '" + userName + "' AND Password LIKE'" + password + "' AND UserType LIKE 'Customer'");
                    if (userType.Length != 0)
                    {

                    }

                    //checks if the user is a employee
                    userType = ProgOps.DTUser.Select("Email LIKE '" + userName + "' AND Password LIKE'" + password + "' AND UserType LIKE 'Employee'");
                    if (userType.Length != 0)
                    {

                    }

                    //checks if the user is a manager
                    userType = ProgOps.DTUser.Select("Email LIKE '" + userName + "' AND Password LIKE'" + password + "' AND UserType LIKE 'Manager'");
                    if (userType.Length != 0)
                    {

                    }
                }

                /* 1 Program needs to run a scan for the username in the customers table, employees table, and managers table.
                 * Depending on which table the username is found in, it will open one of the respective forms.
                */



                //create program code for log in screen
                //ProgOps.OpenLogin("SELECT * FROM group5sp212330.Users WHERE Email = " + tbxUserName.Text + ";");
            }
        }

        public void lblLinkPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Create new frmResetPassword and open
            frmResetPassword resetPassword = new frmResetPassword();
            resetPassword.ShowDialog();
        }

        private void lblLinkNewUser_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // 1 Depending on the table that the user belongs to, that respective form will need to be created and opened.

            // Create new frmNewUser and open
            frmNewUser newUserForm = new frmNewUser();
            newUserForm.ShowDialog();
        }

        public void lblLinkUsername_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Create new frmResetUser and open
            frmResetUser resetUser = new frmResetUser();
            resetUser.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close applciation
            Application.Exit();

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            //connect to books database and open connection
            ProgOps.OpenConnection();
        }
    }
}
