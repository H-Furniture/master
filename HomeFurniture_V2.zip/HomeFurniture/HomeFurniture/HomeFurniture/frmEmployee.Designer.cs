﻿
namespace HomeFurniture
{
    partial class frmEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcOne = new System.Windows.Forms.TabControl();
            this.tabCustomerInformation = new System.Windows.Forms.TabPage();
            this.btnNewCust = new System.Windows.Forms.Button();
            this.btnRemoveCust = new System.Windows.Forms.Button();
            this.btnNextCust = new System.Windows.Forms.Button();
            this.btnPreviousCust = new System.Windows.Forms.Button();
            this.btnCancelCust = new System.Windows.Forms.Button();
            this.btnSaveCust = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlOne = new System.Windows.Forms.Panel();
            this.tbxECPC = new System.Windows.Forms.TextBox();
            this.tbxECFax = new System.Windows.Forms.TextBox();
            this.tbxECUser = new System.Windows.Forms.TextBox();
            this.tbxECCountry = new System.Windows.Forms.TextBox();
            this.tbxECCity = new System.Windows.Forms.TextBox();
            this.tbxECAddress = new System.Windows.Forms.TextBox();
            this.tbxECLName = new System.Windows.Forms.TextBox();
            this.tbxECPhone = new System.Windows.Forms.TextBox();
            this.tbxECFName = new System.Windows.Forms.TextBox();
            this.tbxECID = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.btnLogout1 = new System.Windows.Forms.Button();
            this.btnViewOrders = new System.Windows.Forms.Button();
            this.btnEditCust = new System.Windows.Forms.Button();
            this.tabCustomerOrders = new System.Windows.Forms.TabPage();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.btnSaveOrder = new System.Windows.Forms.Button();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbxEmployeeID = new System.Windows.Forms.TextBox();
            this.tbxETotalPricing = new System.Windows.Forms.TextBox();
            this.tbxEPC = new System.Windows.Forms.TextBox();
            this.tbxEProducts = new System.Windows.Forms.TextBox();
            this.tbxEShipCountry = new System.Windows.Forms.TextBox();
            this.tbxEShipCity = new System.Windows.Forms.TextBox();
            this.tbxEShipAdd = new System.Windows.Forms.TextBox();
            this.tbxEOrderDate = new System.Windows.Forms.TextBox();
            this.tbxEShipping = new System.Windows.Forms.TextBox();
            this.tbxCOCID = new System.Windows.Forms.TextBox();
            this.tbxECOID = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.btnCustInfo = new System.Windows.Forms.Button();
            this.btnLogin2 = new System.Windows.Forms.Button();
            this.btnNextOrder = new System.Windows.Forms.Button();
            this.btnPreviousOrder = new System.Windows.Forms.Button();
            this.btnDeleteOrder = new System.Windows.Forms.Button();
            this.btnEditOrder = new System.Windows.Forms.Button();
            this.tabEmplyeeInformation = new System.Windows.Forms.TabPage();
            this.btnEmpOrdersAssigned = new System.Windows.Forms.Button();
            this.btnEmpCustomersAssigned = new System.Windows.Forms.Button();
            this.btnCancelEmp = new System.Windows.Forms.Button();
            this.lblTitle3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbxEFax = new System.Windows.Forms.TextBox();
            this.tbxEUID = new System.Windows.Forms.TextBox();
            this.tbxECountry = new System.Windows.Forms.TextBox();
            this.tbxECity = new System.Windows.Forms.TextBox();
            this.tbxEAddress = new System.Windows.Forms.TextBox();
            this.tbxELName = new System.Windows.Forms.TextBox();
            this.tbxEPhone = new System.Windows.Forms.TextBox();
            this.tbxEFName = new System.Windows.Forms.TextBox();
            this.tbxEID = new System.Windows.Forms.TextBox();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl26 = new System.Windows.Forms.Label();
            this.lbl27 = new System.Windows.Forms.Label();
            this.lbl28 = new System.Windows.Forms.Label();
            this.lbl29 = new System.Windows.Forms.Label();
            this.lbl30 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.btnLogin3 = new System.Windows.Forms.Button();
            this.btnSaveEmp = new System.Windows.Forms.Button();
            this.btnEditEmp = new System.Windows.Forms.Button();
            this.tbcOne.SuspendLayout();
            this.tabCustomerInformation.SuspendLayout();
            this.pnlOne.SuspendLayout();
            this.tabCustomerOrders.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabEmplyeeInformation.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcOne
            // 
            this.tbcOne.Controls.Add(this.tabCustomerInformation);
            this.tbcOne.Controls.Add(this.tabCustomerOrders);
            this.tbcOne.Controls.Add(this.tabEmplyeeInformation);
            this.tbcOne.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcOne.Font = new System.Drawing.Font("Javanese Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcOne.Location = new System.Drawing.Point(0, 0);
            this.tbcOne.Multiline = true;
            this.tbcOne.Name = "tbcOne";
            this.tbcOne.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tbcOne.SelectedIndex = 0;
            this.tbcOne.Size = new System.Drawing.Size(565, 561);
            this.tbcOne.TabIndex = 0;
            // 
            // tabCustomerInformation
            // 
            this.tabCustomerInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabCustomerInformation.Controls.Add(this.btnNewCust);
            this.tabCustomerInformation.Controls.Add(this.btnRemoveCust);
            this.tabCustomerInformation.Controls.Add(this.btnNextCust);
            this.tabCustomerInformation.Controls.Add(this.btnPreviousCust);
            this.tabCustomerInformation.Controls.Add(this.btnCancelCust);
            this.tabCustomerInformation.Controls.Add(this.btnSaveCust);
            this.tabCustomerInformation.Controls.Add(this.lblTitle);
            this.tabCustomerInformation.Controls.Add(this.pnlOne);
            this.tabCustomerInformation.Controls.Add(this.btnLogout1);
            this.tabCustomerInformation.Controls.Add(this.btnViewOrders);
            this.tabCustomerInformation.Controls.Add(this.btnEditCust);
            this.tabCustomerInformation.Location = new System.Drawing.Point(4, 34);
            this.tabCustomerInformation.Name = "tabCustomerInformation";
            this.tabCustomerInformation.Padding = new System.Windows.Forms.Padding(3);
            this.tabCustomerInformation.Size = new System.Drawing.Size(557, 523);
            this.tabCustomerInformation.TabIndex = 0;
            this.tabCustomerInformation.Text = "Customer Information";
            // 
            // btnNewCust
            // 
            this.btnNewCust.BackColor = System.Drawing.Color.Beige;
            this.btnNewCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewCust.Location = new System.Drawing.Point(357, 422);
            this.btnNewCust.Name = "btnNewCust";
            this.btnNewCust.Size = new System.Drawing.Size(121, 38);
            this.btnNewCust.TabIndex = 9;
            this.btnNewCust.Text = "Add New Customer";
            this.btnNewCust.UseVisualStyleBackColor = false;
            // 
            // btnRemoveCust
            // 
            this.btnRemoveCust.BackColor = System.Drawing.Color.Beige;
            this.btnRemoveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveCust.Location = new System.Drawing.Point(357, 369);
            this.btnRemoveCust.Name = "btnRemoveCust";
            this.btnRemoveCust.Size = new System.Drawing.Size(121, 38);
            this.btnRemoveCust.TabIndex = 7;
            this.btnRemoveCust.Text = "Remove Customer";
            this.btnRemoveCust.UseVisualStyleBackColor = false;
            // 
            // btnNextCust
            // 
            this.btnNextCust.BackColor = System.Drawing.Color.Beige;
            this.btnNextCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextCust.Location = new System.Drawing.Point(357, 315);
            this.btnNextCust.Name = "btnNextCust";
            this.btnNextCust.Size = new System.Drawing.Size(121, 38);
            this.btnNextCust.TabIndex = 4;
            this.btnNextCust.Text = "Next Customer";
            this.btnNextCust.UseVisualStyleBackColor = false;
            // 
            // btnPreviousCust
            // 
            this.btnPreviousCust.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousCust.Location = new System.Drawing.Point(213, 315);
            this.btnPreviousCust.Name = "btnPreviousCust";
            this.btnPreviousCust.Size = new System.Drawing.Size(121, 38);
            this.btnPreviousCust.TabIndex = 3;
            this.btnPreviousCust.Text = "Previous Customer";
            this.btnPreviousCust.UseVisualStyleBackColor = false;
            // 
            // btnCancelCust
            // 
            this.btnCancelCust.BackColor = System.Drawing.Color.Beige;
            this.btnCancelCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelCust.Location = new System.Drawing.Point(74, 422);
            this.btnCancelCust.Name = "btnCancelCust";
            this.btnCancelCust.Size = new System.Drawing.Size(121, 38);
            this.btnCancelCust.TabIndex = 8;
            this.btnCancelCust.Text = "Cancel";
            this.btnCancelCust.UseVisualStyleBackColor = false;
            // 
            // btnSaveCust
            // 
            this.btnSaveCust.BackColor = System.Drawing.Color.Beige;
            this.btnSaveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCust.Location = new System.Drawing.Point(74, 369);
            this.btnSaveCust.Name = "btnSaveCust";
            this.btnSaveCust.Size = new System.Drawing.Size(121, 38);
            this.btnSaveCust.TabIndex = 5;
            this.btnSaveCust.Text = "Save";
            this.btnSaveCust.UseVisualStyleBackColor = false;
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(74, 8);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(403, 36);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Customer Information";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlOne
            // 
            this.pnlOne.BackColor = System.Drawing.Color.Beige;
            this.pnlOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOne.Controls.Add(this.tbxECPC);
            this.pnlOne.Controls.Add(this.tbxECFax);
            this.pnlOne.Controls.Add(this.tbxECUser);
            this.pnlOne.Controls.Add(this.tbxECCountry);
            this.pnlOne.Controls.Add(this.tbxECCity);
            this.pnlOne.Controls.Add(this.tbxECAddress);
            this.pnlOne.Controls.Add(this.tbxECLName);
            this.pnlOne.Controls.Add(this.tbxECPhone);
            this.pnlOne.Controls.Add(this.tbxECFName);
            this.pnlOne.Controls.Add(this.tbxECID);
            this.pnlOne.Controls.Add(this.lbl1);
            this.pnlOne.Controls.Add(this.lbl2);
            this.pnlOne.Controls.Add(this.lbl3);
            this.pnlOne.Controls.Add(this.lbl4);
            this.pnlOne.Controls.Add(this.lbl5);
            this.pnlOne.Controls.Add(this.lbl6);
            this.pnlOne.Controls.Add(this.lbl7);
            this.pnlOne.Controls.Add(this.lbl8);
            this.pnlOne.Controls.Add(this.lbl9);
            this.pnlOne.Controls.Add(this.lbl10);
            this.pnlOne.Location = new System.Drawing.Point(74, 46);
            this.pnlOne.Margin = new System.Windows.Forms.Padding(2);
            this.pnlOne.Name = "pnlOne";
            this.pnlOne.Size = new System.Drawing.Size(404, 255);
            this.pnlOne.TabIndex = 1;
            // 
            // tbxECPC
            // 
            this.tbxECPC.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECPC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECPC.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECPC.Location = new System.Drawing.Point(106, 224);
            this.tbxECPC.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECPC.Name = "tbxECPC";
            this.tbxECPC.Size = new System.Drawing.Size(275, 15);
            this.tbxECPC.TabIndex = 34;
            // 
            // tbxECFax
            // 
            this.tbxECFax.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECFax.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECFax.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECFax.Location = new System.Drawing.Point(106, 178);
            this.tbxECFax.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECFax.Name = "tbxECFax";
            this.tbxECFax.Size = new System.Drawing.Size(275, 15);
            this.tbxECFax.TabIndex = 33;
            // 
            // tbxECUser
            // 
            this.tbxECUser.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECUser.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECUser.Location = new System.Drawing.Point(106, 202);
            this.tbxECUser.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECUser.Name = "tbxECUser";
            this.tbxECUser.Size = new System.Drawing.Size(275, 15);
            this.tbxECUser.TabIndex = 32;
            // 
            // tbxECCountry
            // 
            this.tbxECCountry.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECCountry.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECCountry.Location = new System.Drawing.Point(106, 155);
            this.tbxECCountry.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECCountry.Name = "tbxECCountry";
            this.tbxECCountry.Size = new System.Drawing.Size(275, 15);
            this.tbxECCountry.TabIndex = 31;
            // 
            // tbxECCity
            // 
            this.tbxECCity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECCity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECCity.Location = new System.Drawing.Point(106, 132);
            this.tbxECCity.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECCity.Name = "tbxECCity";
            this.tbxECCity.Size = new System.Drawing.Size(275, 15);
            this.tbxECCity.TabIndex = 30;
            // 
            // tbxECAddress
            // 
            this.tbxECAddress.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECAddress.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECAddress.Location = new System.Drawing.Point(106, 110);
            this.tbxECAddress.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECAddress.Name = "tbxECAddress";
            this.tbxECAddress.Size = new System.Drawing.Size(275, 15);
            this.tbxECAddress.TabIndex = 29;
            // 
            // tbxECLName
            // 
            this.tbxECLName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECLName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECLName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECLName.Location = new System.Drawing.Point(106, 63);
            this.tbxECLName.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECLName.Name = "tbxECLName";
            this.tbxECLName.Size = new System.Drawing.Size(275, 15);
            this.tbxECLName.TabIndex = 28;
            // 
            // tbxECPhone
            // 
            this.tbxECPhone.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECPhone.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECPhone.Location = new System.Drawing.Point(106, 87);
            this.tbxECPhone.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECPhone.Name = "tbxECPhone";
            this.tbxECPhone.Size = new System.Drawing.Size(275, 15);
            this.tbxECPhone.TabIndex = 27;
            // 
            // tbxECFName
            // 
            this.tbxECFName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECFName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECFName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECFName.Location = new System.Drawing.Point(106, 41);
            this.tbxECFName.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECFName.Name = "tbxECFName";
            this.tbxECFName.Size = new System.Drawing.Size(275, 15);
            this.tbxECFName.TabIndex = 21;
            // 
            // tbxECID
            // 
            this.tbxECID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECID.Location = new System.Drawing.Point(106, 18);
            this.tbxECID.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECID.Name = "tbxECID";
            this.tbxECID.Size = new System.Drawing.Size(275, 15);
            this.tbxECID.TabIndex = 20;
            // 
            // lbl1
            // 
            this.lbl1.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(16, 15);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(91, 23);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Customer ID:";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl2
            // 
            this.lbl2.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(16, 33);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(91, 23);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "First Name:";
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl3
            // 
            this.lbl3.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(16, 56);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(91, 23);
            this.lbl3.TabIndex = 4;
            this.lbl3.Text = "Last Name:";
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl4
            // 
            this.lbl4.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.Location = new System.Drawing.Point(16, 80);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(91, 23);
            this.lbl4.TabIndex = 6;
            this.lbl4.Text = "Phone Number:";
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl5
            // 
            this.lbl5.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(16, 102);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(91, 23);
            this.lbl5.TabIndex = 8;
            this.lbl5.Text = "Address:";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl6
            // 
            this.lbl6.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.Location = new System.Drawing.Point(16, 125);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(91, 23);
            this.lbl6.TabIndex = 10;
            this.lbl6.Text = "City:";
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl7
            // 
            this.lbl7.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.Location = new System.Drawing.Point(16, 148);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(91, 23);
            this.lbl7.TabIndex = 12;
            this.lbl7.Text = "Country:";
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl8
            // 
            this.lbl8.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.Location = new System.Drawing.Point(16, 171);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(91, 23);
            this.lbl8.TabIndex = 14;
            this.lbl8.Text = "Fax:";
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl9
            // 
            this.lbl9.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.Location = new System.Drawing.Point(16, 194);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(91, 23);
            this.lbl9.TabIndex = 16;
            this.lbl9.Text = "User ID:";
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl10
            // 
            this.lbl10.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10.Location = new System.Drawing.Point(16, 217);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(91, 23);
            this.lbl10.TabIndex = 18;
            this.lbl10.Text = "Postal Code:";
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLogout1
            // 
            this.btnLogout1.BackColor = System.Drawing.Color.Beige;
            this.btnLogout1.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout1.Location = new System.Drawing.Point(6, 475);
            this.btnLogout1.Name = "btnLogout1";
            this.btnLogout1.Size = new System.Drawing.Size(121, 38);
            this.btnLogout1.TabIndex = 10;
            this.btnLogout1.Text = "Main Menu";
            this.btnLogout1.UseVisualStyleBackColor = false;
            // 
            // btnViewOrders
            // 
            this.btnViewOrders.BackColor = System.Drawing.Color.Beige;
            this.btnViewOrders.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewOrders.Location = new System.Drawing.Point(213, 369);
            this.btnViewOrders.Name = "btnViewOrders";
            this.btnViewOrders.Size = new System.Drawing.Size(121, 38);
            this.btnViewOrders.TabIndex = 6;
            this.btnViewOrders.Text = "View Orders";
            this.btnViewOrders.UseVisualStyleBackColor = false;
            // 
            // btnEditCust
            // 
            this.btnEditCust.BackColor = System.Drawing.Color.Beige;
            this.btnEditCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditCust.Location = new System.Drawing.Point(74, 315);
            this.btnEditCust.Name = "btnEditCust";
            this.btnEditCust.Size = new System.Drawing.Size(121, 38);
            this.btnEditCust.TabIndex = 2;
            this.btnEditCust.Text = "Change Information";
            this.btnEditCust.UseVisualStyleBackColor = false;
            // 
            // tabCustomerOrders
            // 
            this.tabCustomerOrders.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerOrders.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabCustomerOrders.Controls.Add(this.btnCancelOrder);
            this.tabCustomerOrders.Controls.Add(this.btnSaveOrder);
            this.tabCustomerOrders.Controls.Add(this.lblTitle2);
            this.tabCustomerOrders.Controls.Add(this.panel1);
            this.tabCustomerOrders.Controls.Add(this.btnCustInfo);
            this.tabCustomerOrders.Controls.Add(this.btnLogin2);
            this.tabCustomerOrders.Controls.Add(this.btnNextOrder);
            this.tabCustomerOrders.Controls.Add(this.btnPreviousOrder);
            this.tabCustomerOrders.Controls.Add(this.btnDeleteOrder);
            this.tabCustomerOrders.Controls.Add(this.btnEditOrder);
            this.tabCustomerOrders.Location = new System.Drawing.Point(4, 34);
            this.tabCustomerOrders.Name = "tabCustomerOrders";
            this.tabCustomerOrders.Padding = new System.Windows.Forms.Padding(3);
            this.tabCustomerOrders.Size = new System.Drawing.Size(557, 523);
            this.tabCustomerOrders.TabIndex = 1;
            this.tabCustomerOrders.Text = "Customer Orders";
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.BackColor = System.Drawing.Color.Beige;
            this.btnCancelOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelOrder.Location = new System.Drawing.Point(152, 434);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(121, 33);
            this.btnCancelOrder.TabIndex = 43;
            this.btnCancelOrder.Text = "Cancel";
            this.btnCancelOrder.UseVisualStyleBackColor = false;
            // 
            // btnSaveOrder
            // 
            this.btnSaveOrder.BackColor = System.Drawing.Color.Beige;
            this.btnSaveOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveOrder.Location = new System.Drawing.Point(152, 381);
            this.btnSaveOrder.Name = "btnSaveOrder";
            this.btnSaveOrder.Size = new System.Drawing.Size(121, 33);
            this.btnSaveOrder.TabIndex = 42;
            this.btnSaveOrder.Text = "Save";
            this.btnSaveOrder.UseVisualStyleBackColor = false;
            // 
            // lblTitle2
            // 
            this.lblTitle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle2.Location = new System.Drawing.Point(89, 4);
            this.lblTitle2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(374, 36);
            this.lblTitle2.TabIndex = 41;
            this.lblTitle2.Text = "View Orders";
            this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Beige;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tbxEmployeeID);
            this.panel1.Controls.Add(this.tbxETotalPricing);
            this.panel1.Controls.Add(this.tbxEPC);
            this.panel1.Controls.Add(this.tbxEProducts);
            this.panel1.Controls.Add(this.tbxEShipCountry);
            this.panel1.Controls.Add(this.tbxEShipCity);
            this.panel1.Controls.Add(this.tbxEShipAdd);
            this.panel1.Controls.Add(this.tbxEOrderDate);
            this.panel1.Controls.Add(this.tbxEShipping);
            this.panel1.Controls.Add(this.tbxCOCID);
            this.panel1.Controls.Add(this.tbxECOID);
            this.panel1.Controls.Add(this.lbl12);
            this.panel1.Controls.Add(this.lbl13);
            this.panel1.Controls.Add(this.lbl14);
            this.panel1.Controls.Add(this.lbl15);
            this.panel1.Controls.Add(this.lbl16);
            this.panel1.Controls.Add(this.lbl17);
            this.panel1.Controls.Add(this.lbl18);
            this.panel1.Controls.Add(this.lbl19);
            this.panel1.Controls.Add(this.lbl20);
            this.panel1.Controls.Add(this.lbl21);
            this.panel1.Controls.Add(this.lbl22);
            this.panel1.Location = new System.Drawing.Point(89, 42);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(375, 321);
            this.panel1.TabIndex = 40;
            // 
            // tbxEmployeeID
            // 
            this.tbxEmployeeID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEmployeeID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEmployeeID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEmployeeID.Location = new System.Drawing.Point(115, 292);
            this.tbxEmployeeID.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEmployeeID.Name = "tbxEmployeeID";
            this.tbxEmployeeID.Size = new System.Drawing.Size(234, 15);
            this.tbxEmployeeID.TabIndex = 45;
            // 
            // tbxETotalPricing
            // 
            this.tbxETotalPricing.BackColor = System.Drawing.Color.LightCyan;
            this.tbxETotalPricing.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxETotalPricing.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxETotalPricing.Location = new System.Drawing.Point(115, 267);
            this.tbxETotalPricing.Margin = new System.Windows.Forms.Padding(2);
            this.tbxETotalPricing.Name = "tbxETotalPricing";
            this.tbxETotalPricing.Size = new System.Drawing.Size(234, 15);
            this.tbxETotalPricing.TabIndex = 44;
            // 
            // tbxEPC
            // 
            this.tbxEPC.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEPC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEPC.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEPC.Location = new System.Drawing.Point(115, 175);
            this.tbxEPC.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEPC.Name = "tbxEPC";
            this.tbxEPC.Size = new System.Drawing.Size(234, 15);
            this.tbxEPC.TabIndex = 43;
            // 
            // tbxEProducts
            // 
            this.tbxEProducts.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEProducts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEProducts.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEProducts.Location = new System.Drawing.Point(115, 197);
            this.tbxEProducts.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEProducts.Multiline = true;
            this.tbxEProducts.Name = "tbxEProducts";
            this.tbxEProducts.Size = new System.Drawing.Size(234, 60);
            this.tbxEProducts.TabIndex = 42;
            // 
            // tbxEShipCountry
            // 
            this.tbxEShipCountry.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEShipCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEShipCountry.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEShipCountry.Location = new System.Drawing.Point(115, 150);
            this.tbxEShipCountry.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEShipCountry.Name = "tbxEShipCountry";
            this.tbxEShipCountry.Size = new System.Drawing.Size(234, 15);
            this.tbxEShipCountry.TabIndex = 41;
            // 
            // tbxEShipCity
            // 
            this.tbxEShipCity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEShipCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEShipCity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEShipCity.Location = new System.Drawing.Point(115, 128);
            this.tbxEShipCity.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEShipCity.Name = "tbxEShipCity";
            this.tbxEShipCity.Size = new System.Drawing.Size(234, 15);
            this.tbxEShipCity.TabIndex = 40;
            // 
            // tbxEShipAdd
            // 
            this.tbxEShipAdd.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEShipAdd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEShipAdd.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEShipAdd.Location = new System.Drawing.Point(115, 105);
            this.tbxEShipAdd.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEShipAdd.Name = "tbxEShipAdd";
            this.tbxEShipAdd.Size = new System.Drawing.Size(234, 15);
            this.tbxEShipAdd.TabIndex = 39;
            // 
            // tbxEOrderDate
            // 
            this.tbxEOrderDate.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEOrderDate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEOrderDate.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEOrderDate.Location = new System.Drawing.Point(115, 60);
            this.tbxEOrderDate.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEOrderDate.Name = "tbxEOrderDate";
            this.tbxEOrderDate.Size = new System.Drawing.Size(234, 15);
            this.tbxEOrderDate.TabIndex = 38;
            // 
            // tbxEShipping
            // 
            this.tbxEShipping.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEShipping.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEShipping.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEShipping.Location = new System.Drawing.Point(115, 83);
            this.tbxEShipping.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEShipping.Name = "tbxEShipping";
            this.tbxEShipping.Size = new System.Drawing.Size(234, 15);
            this.tbxEShipping.TabIndex = 37;
            // 
            // tbxCOCID
            // 
            this.tbxCOCID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCOCID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCOCID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCOCID.Location = new System.Drawing.Point(115, 37);
            this.tbxCOCID.Margin = new System.Windows.Forms.Padding(2);
            this.tbxCOCID.Name = "tbxCOCID";
            this.tbxCOCID.Size = new System.Drawing.Size(234, 15);
            this.tbxCOCID.TabIndex = 36;
            // 
            // tbxECOID
            // 
            this.tbxECOID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECOID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECOID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECOID.Location = new System.Drawing.Point(115, 14);
            this.tbxECOID.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECOID.Name = "tbxECOID";
            this.tbxECOID.Size = new System.Drawing.Size(234, 15);
            this.tbxECOID.TabIndex = 35;
            // 
            // lbl12
            // 
            this.lbl12.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.Location = new System.Drawing.Point(28, 12);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(91, 23);
            this.lbl12.TabIndex = 0;
            this.lbl12.Text = "Order ID:";
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl13
            // 
            this.lbl13.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.Location = new System.Drawing.Point(28, 35);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(91, 23);
            this.lbl13.TabIndex = 2;
            this.lbl13.Text = "Customer ID:";
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl14
            // 
            this.lbl14.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl14.Location = new System.Drawing.Point(28, 52);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(91, 23);
            this.lbl14.TabIndex = 4;
            this.lbl14.Text = "Order Date:";
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl15
            // 
            this.lbl15.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.Location = new System.Drawing.Point(28, 75);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(91, 23);
            this.lbl15.TabIndex = 6;
            this.lbl15.Text = "Shipped Date:";
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl16
            // 
            this.lbl16.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl16.Location = new System.Drawing.Point(4, 98);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(116, 23);
            this.lbl16.TabIndex = 8;
            this.lbl16.Text = "Shipped Address:";
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl17
            // 
            this.lbl17.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17.Location = new System.Drawing.Point(28, 121);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(91, 23);
            this.lbl17.TabIndex = 10;
            this.lbl17.Text = "Shipped City:";
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl18
            // 
            this.lbl18.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl18.Location = new System.Drawing.Point(-5, 136);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(124, 37);
            this.lbl18.TabIndex = 12;
            this.lbl18.Text = "Shipped Country:";
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl19
            // 
            this.lbl19.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl19.Location = new System.Drawing.Point(28, 173);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(91, 23);
            this.lbl19.TabIndex = 14;
            this.lbl19.Text = "Postal Code:";
            this.lbl19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl20
            // 
            this.lbl20.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl20.Location = new System.Drawing.Point(28, 171);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(91, 70);
            this.lbl20.TabIndex = 16;
            this.lbl20.Text = "Products:";
            this.lbl20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl21
            // 
            this.lbl21.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.Location = new System.Drawing.Point(28, 266);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(91, 23);
            this.lbl21.TabIndex = 18;
            this.lbl21.Text = "Total Price:";
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl22
            // 
            this.lbl22.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.Location = new System.Drawing.Point(28, 288);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(91, 23);
            this.lbl22.TabIndex = 20;
            this.lbl22.Text = "Employee ID:";
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCustInfo
            // 
            this.btnCustInfo.BackColor = System.Drawing.Color.Beige;
            this.btnCustInfo.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustInfo.Location = new System.Drawing.Point(406, 434);
            this.btnCustInfo.Name = "btnCustInfo";
            this.btnCustInfo.Size = new System.Drawing.Size(121, 33);
            this.btnCustInfo.TabIndex = 36;
            this.btnCustInfo.Text = "Customer Information";
            this.btnCustInfo.UseVisualStyleBackColor = false;
            // 
            // btnLogin2
            // 
            this.btnLogin2.BackColor = System.Drawing.Color.Beige;
            this.btnLogin2.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin2.Location = new System.Drawing.Point(6, 480);
            this.btnLogin2.Name = "btnLogin2";
            this.btnLogin2.Size = new System.Drawing.Size(121, 33);
            this.btnLogin2.TabIndex = 38;
            this.btnLogin2.Text = "Main Menu";
            this.btnLogin2.UseVisualStyleBackColor = false;
            // 
            // btnNextOrder
            // 
            this.btnNextOrder.BackColor = System.Drawing.Color.Beige;
            this.btnNextOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextOrder.Location = new System.Drawing.Point(406, 381);
            this.btnNextOrder.Name = "btnNextOrder";
            this.btnNextOrder.Size = new System.Drawing.Size(121, 33);
            this.btnNextOrder.TabIndex = 35;
            this.btnNextOrder.Text = "Next Page";
            this.btnNextOrder.UseVisualStyleBackColor = false;
            // 
            // btnPreviousOrder
            // 
            this.btnPreviousOrder.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousOrder.Location = new System.Drawing.Point(279, 381);
            this.btnPreviousOrder.Name = "btnPreviousOrder";
            this.btnPreviousOrder.Size = new System.Drawing.Size(121, 33);
            this.btnPreviousOrder.TabIndex = 34;
            this.btnPreviousOrder.Text = "Previous Page";
            this.btnPreviousOrder.UseVisualStyleBackColor = false;
            // 
            // btnDeleteOrder
            // 
            this.btnDeleteOrder.BackColor = System.Drawing.Color.Beige;
            this.btnDeleteOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteOrder.Location = new System.Drawing.Point(25, 434);
            this.btnDeleteOrder.Name = "btnDeleteOrder";
            this.btnDeleteOrder.Size = new System.Drawing.Size(121, 33);
            this.btnDeleteOrder.TabIndex = 33;
            this.btnDeleteOrder.Text = "Delete Order";
            this.btnDeleteOrder.UseVisualStyleBackColor = false;
            // 
            // btnEditOrder
            // 
            this.btnEditOrder.BackColor = System.Drawing.Color.Beige;
            this.btnEditOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditOrder.Location = new System.Drawing.Point(25, 381);
            this.btnEditOrder.Name = "btnEditOrder";
            this.btnEditOrder.Size = new System.Drawing.Size(121, 33);
            this.btnEditOrder.TabIndex = 32;
            this.btnEditOrder.Text = "Edit Order";
            this.btnEditOrder.UseVisualStyleBackColor = false;
            // 
            // tabEmplyeeInformation
            // 
            this.tabEmplyeeInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabEmplyeeInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabEmplyeeInformation.Controls.Add(this.btnEmpOrdersAssigned);
            this.tabEmplyeeInformation.Controls.Add(this.btnEmpCustomersAssigned);
            this.tabEmplyeeInformation.Controls.Add(this.btnCancelEmp);
            this.tabEmplyeeInformation.Controls.Add(this.lblTitle3);
            this.tabEmplyeeInformation.Controls.Add(this.panel2);
            this.tabEmplyeeInformation.Controls.Add(this.btnLogin3);
            this.tabEmplyeeInformation.Controls.Add(this.btnSaveEmp);
            this.tabEmplyeeInformation.Controls.Add(this.btnEditEmp);
            this.tabEmplyeeInformation.Location = new System.Drawing.Point(4, 34);
            this.tabEmplyeeInformation.Name = "tabEmplyeeInformation";
            this.tabEmplyeeInformation.Padding = new System.Windows.Forms.Padding(3);
            this.tabEmplyeeInformation.Size = new System.Drawing.Size(557, 523);
            this.tabEmplyeeInformation.TabIndex = 2;
            this.tabEmplyeeInformation.Text = "Employee Information";
            // 
            // btnEmpOrdersAssigned
            // 
            this.btnEmpOrdersAssigned.BackColor = System.Drawing.Color.Beige;
            this.btnEmpOrdersAssigned.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpOrdersAssigned.Location = new System.Drawing.Point(278, 375);
            this.btnEmpOrdersAssigned.Name = "btnEmpOrdersAssigned";
            this.btnEmpOrdersAssigned.Size = new System.Drawing.Size(121, 35);
            this.btnEmpOrdersAssigned.TabIndex = 18;
            this.btnEmpOrdersAssigned.Text = "Orders Assigned";
            this.btnEmpOrdersAssigned.UseVisualStyleBackColor = false;
            // 
            // btnEmpCustomersAssigned
            // 
            this.btnEmpCustomersAssigned.BackColor = System.Drawing.Color.Beige;
            this.btnEmpCustomersAssigned.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpCustomersAssigned.Location = new System.Drawing.Point(151, 375);
            this.btnEmpCustomersAssigned.Name = "btnEmpCustomersAssigned";
            this.btnEmpCustomersAssigned.Size = new System.Drawing.Size(121, 35);
            this.btnEmpCustomersAssigned.TabIndex = 17;
            this.btnEmpCustomersAssigned.Text = "Customers Assigned";
            this.btnEmpCustomersAssigned.UseVisualStyleBackColor = false;
            // 
            // btnCancelEmp
            // 
            this.btnCancelEmp.BackColor = System.Drawing.Color.Beige;
            this.btnCancelEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelEmp.Location = new System.Drawing.Point(342, 323);
            this.btnCancelEmp.Name = "btnCancelEmp";
            this.btnCancelEmp.Size = new System.Drawing.Size(121, 35);
            this.btnCancelEmp.TabIndex = 16;
            this.btnCancelEmp.Text = "Cancel";
            this.btnCancelEmp.UseVisualStyleBackColor = false;
            // 
            // lblTitle3
            // 
            this.lblTitle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle3.Location = new System.Drawing.Point(74, 36);
            this.lblTitle3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle3.Name = "lblTitle3";
            this.lblTitle3.Size = new System.Drawing.Size(403, 36);
            this.lblTitle3.TabIndex = 11;
            this.lblTitle3.Text = "Employee Information";
            this.lblTitle3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Beige;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.tbxEFax);
            this.panel2.Controls.Add(this.tbxEUID);
            this.panel2.Controls.Add(this.tbxECountry);
            this.panel2.Controls.Add(this.tbxECity);
            this.panel2.Controls.Add(this.tbxEAddress);
            this.panel2.Controls.Add(this.tbxELName);
            this.panel2.Controls.Add(this.tbxEPhone);
            this.panel2.Controls.Add(this.tbxEFName);
            this.panel2.Controls.Add(this.tbxEID);
            this.panel2.Controls.Add(this.lbl23);
            this.panel2.Controls.Add(this.lbl24);
            this.panel2.Controls.Add(this.lbl25);
            this.panel2.Controls.Add(this.lbl26);
            this.panel2.Controls.Add(this.lbl27);
            this.panel2.Controls.Add(this.lbl28);
            this.panel2.Controls.Add(this.lbl29);
            this.panel2.Controls.Add(this.lbl30);
            this.panel2.Controls.Add(this.lbl31);
            this.panel2.Location = new System.Drawing.Point(74, 74);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(404, 232);
            this.panel2.TabIndex = 12;
            // 
            // tbxEFax
            // 
            this.tbxEFax.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEFax.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEFax.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEFax.Location = new System.Drawing.Point(111, 180);
            this.tbxEFax.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEFax.Name = "tbxEFax";
            this.tbxEFax.Size = new System.Drawing.Size(234, 15);
            this.tbxEFax.TabIndex = 48;
            // 
            // tbxEUID
            // 
            this.tbxEUID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEUID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEUID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEUID.Location = new System.Drawing.Point(111, 202);
            this.tbxEUID.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEUID.Name = "tbxEUID";
            this.tbxEUID.Size = new System.Drawing.Size(234, 15);
            this.tbxEUID.TabIndex = 47;
            // 
            // tbxECountry
            // 
            this.tbxECountry.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECountry.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECountry.Location = new System.Drawing.Point(111, 157);
            this.tbxECountry.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECountry.Name = "tbxECountry";
            this.tbxECountry.Size = new System.Drawing.Size(234, 15);
            this.tbxECountry.TabIndex = 46;
            // 
            // tbxECity
            // 
            this.tbxECity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECity.Location = new System.Drawing.Point(111, 134);
            this.tbxECity.Margin = new System.Windows.Forms.Padding(2);
            this.tbxECity.Name = "tbxECity";
            this.tbxECity.Size = new System.Drawing.Size(234, 15);
            this.tbxECity.TabIndex = 45;
            // 
            // tbxEAddress
            // 
            this.tbxEAddress.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEAddress.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEAddress.Location = new System.Drawing.Point(111, 110);
            this.tbxEAddress.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEAddress.Name = "tbxEAddress";
            this.tbxEAddress.Size = new System.Drawing.Size(234, 15);
            this.tbxEAddress.TabIndex = 44;
            // 
            // tbxELName
            // 
            this.tbxELName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxELName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxELName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxELName.Location = new System.Drawing.Point(111, 65);
            this.tbxELName.Margin = new System.Windows.Forms.Padding(2);
            this.tbxELName.Name = "tbxELName";
            this.tbxELName.Size = new System.Drawing.Size(234, 15);
            this.tbxELName.TabIndex = 43;
            // 
            // tbxEPhone
            // 
            this.tbxEPhone.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEPhone.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEPhone.Location = new System.Drawing.Point(111, 87);
            this.tbxEPhone.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEPhone.Name = "tbxEPhone";
            this.tbxEPhone.Size = new System.Drawing.Size(234, 15);
            this.tbxEPhone.TabIndex = 42;
            // 
            // tbxEFName
            // 
            this.tbxEFName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEFName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEFName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEFName.Location = new System.Drawing.Point(111, 37);
            this.tbxEFName.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEFName.Name = "tbxEFName";
            this.tbxEFName.Size = new System.Drawing.Size(234, 15);
            this.tbxEFName.TabIndex = 41;
            // 
            // tbxEID
            // 
            this.tbxEID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEID.Location = new System.Drawing.Point(111, 14);
            this.tbxEID.Margin = new System.Windows.Forms.Padding(2);
            this.tbxEID.Name = "tbxEID";
            this.tbxEID.Size = new System.Drawing.Size(234, 15);
            this.tbxEID.TabIndex = 40;
            // 
            // lbl23
            // 
            this.lbl23.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.Location = new System.Drawing.Point(15, 12);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(91, 23);
            this.lbl23.TabIndex = 0;
            this.lbl23.Text = "Employee ID:";
            this.lbl23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl24
            // 
            this.lbl24.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.Location = new System.Drawing.Point(15, 35);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(91, 23);
            this.lbl24.TabIndex = 2;
            this.lbl24.Text = "First Name:";
            this.lbl24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl25
            // 
            this.lbl25.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.Location = new System.Drawing.Point(15, 58);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(91, 23);
            this.lbl25.TabIndex = 4;
            this.lbl25.Text = "Last Name:";
            this.lbl25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl26
            // 
            this.lbl26.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26.Location = new System.Drawing.Point(15, 81);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(91, 23);
            this.lbl26.TabIndex = 6;
            this.lbl26.Text = "Phone Number:";
            this.lbl26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl27
            // 
            this.lbl27.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27.Location = new System.Drawing.Point(15, 104);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(91, 23);
            this.lbl27.TabIndex = 8;
            this.lbl27.Text = "Address:";
            this.lbl27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl28
            // 
            this.lbl28.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl28.Location = new System.Drawing.Point(15, 127);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(91, 23);
            this.lbl28.TabIndex = 10;
            this.lbl28.Text = "City:";
            this.lbl28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl29
            // 
            this.lbl29.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl29.Location = new System.Drawing.Point(15, 150);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(91, 23);
            this.lbl29.TabIndex = 12;
            this.lbl29.Text = "Country:";
            this.lbl29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl30
            // 
            this.lbl30.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl30.Location = new System.Drawing.Point(15, 173);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(91, 23);
            this.lbl30.TabIndex = 14;
            this.lbl30.Text = "Fax:";
            this.lbl30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl31
            // 
            this.lbl31.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.Location = new System.Drawing.Point(15, 196);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(91, 23);
            this.lbl31.TabIndex = 16;
            this.lbl31.Text = "User ID:";
            this.lbl31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLogin3
            // 
            this.btnLogin3.BackColor = System.Drawing.Color.Beige;
            this.btnLogin3.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin3.Location = new System.Drawing.Point(6, 478);
            this.btnLogin3.Name = "btnLogin3";
            this.btnLogin3.Size = new System.Drawing.Size(121, 35);
            this.btnLogin3.TabIndex = 15;
            this.btnLogin3.Text = "Main Menu";
            this.btnLogin3.UseVisualStyleBackColor = false;
            this.btnLogin3.Click += new System.EventHandler(this.btnLogin3_Click);
            // 
            // btnSaveEmp
            // 
            this.btnSaveEmp.BackColor = System.Drawing.Color.Beige;
            this.btnSaveEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveEmp.Location = new System.Drawing.Point(215, 323);
            this.btnSaveEmp.Name = "btnSaveEmp";
            this.btnSaveEmp.Size = new System.Drawing.Size(121, 35);
            this.btnSaveEmp.TabIndex = 14;
            this.btnSaveEmp.Text = "Save";
            this.btnSaveEmp.UseVisualStyleBackColor = false;
            // 
            // btnEditEmp
            // 
            this.btnEditEmp.BackColor = System.Drawing.Color.Beige;
            this.btnEditEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditEmp.Location = new System.Drawing.Point(88, 323);
            this.btnEditEmp.Name = "btnEditEmp";
            this.btnEditEmp.Size = new System.Drawing.Size(121, 35);
            this.btnEditEmp.TabIndex = 13;
            this.btnEditEmp.Text = "Change Information";
            this.btnEditEmp.UseVisualStyleBackColor = false;
            // 
            // frmEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(565, 561);
            this.Controls.Add(this.tbcOne);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Information";
            this.Load += new System.EventHandler(this.frmEmployee_Load);
            this.tbcOne.ResumeLayout(false);
            this.tabCustomerInformation.ResumeLayout(false);
            this.pnlOne.ResumeLayout(false);
            this.pnlOne.PerformLayout();
            this.tabCustomerOrders.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabEmplyeeInformation.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcOne;
        private System.Windows.Forms.TabPage tabCustomerInformation;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlOne;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Button btnLogout1;
        private System.Windows.Forms.Button btnViewOrders;
        private System.Windows.Forms.Button btnEditCust;
        private System.Windows.Forms.TabPage tabCustomerOrders;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Button btnCustInfo;
        private System.Windows.Forms.Button btnLogin2;
        private System.Windows.Forms.Button btnNextOrder;
        private System.Windows.Forms.Button btnPreviousOrder;
        private System.Windows.Forms.Button btnDeleteOrder;
        private System.Windows.Forms.Button btnEditOrder;
        private System.Windows.Forms.Button btnCancelCust;
        private System.Windows.Forms.Button btnSaveCust;
        private System.Windows.Forms.Button btnNewCust;
        private System.Windows.Forms.Button btnRemoveCust;
        private System.Windows.Forms.Button btnNextCust;
        private System.Windows.Forms.Button btnPreviousCust;
        private System.Windows.Forms.Button btnCancelOrder;
        private System.Windows.Forms.Button btnSaveOrder;
        private System.Windows.Forms.TabPage tabEmplyeeInformation;
        private System.Windows.Forms.Button btnCancelEmp;
        private System.Windows.Forms.Label lblTitle3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Button btnLogin3;
        private System.Windows.Forms.Button btnSaveEmp;
        private System.Windows.Forms.Button btnEditEmp;
        private System.Windows.Forms.Button btnEmpOrdersAssigned;
        private System.Windows.Forms.Button btnEmpCustomersAssigned;
        private System.Windows.Forms.TextBox tbxECAddress;
        private System.Windows.Forms.TextBox tbxECLName;
        private System.Windows.Forms.TextBox tbxECPhone;
        private System.Windows.Forms.TextBox tbxECFName;
        private System.Windows.Forms.TextBox tbxECID;
        private System.Windows.Forms.TextBox tbxECPC;
        private System.Windows.Forms.TextBox tbxECFax;
        private System.Windows.Forms.TextBox tbxECUser;
        private System.Windows.Forms.TextBox tbxECCountry;
        private System.Windows.Forms.TextBox tbxECCity;
        private System.Windows.Forms.TextBox tbxEmployeeID;
        private System.Windows.Forms.TextBox tbxETotalPricing;
        private System.Windows.Forms.TextBox tbxEPC;
        private System.Windows.Forms.TextBox tbxEProducts;
        private System.Windows.Forms.TextBox tbxEShipCountry;
        private System.Windows.Forms.TextBox tbxEShipCity;
        private System.Windows.Forms.TextBox tbxEShipAdd;
        private System.Windows.Forms.TextBox tbxEOrderDate;
        private System.Windows.Forms.TextBox tbxEShipping;
        private System.Windows.Forms.TextBox tbxCOCID;
        private System.Windows.Forms.TextBox tbxECOID;
        private System.Windows.Forms.TextBox tbxEFax;
        private System.Windows.Forms.TextBox tbxEUID;
        private System.Windows.Forms.TextBox tbxECountry;
        private System.Windows.Forms.TextBox tbxECity;
        private System.Windows.Forms.TextBox tbxEAddress;
        private System.Windows.Forms.TextBox tbxELName;
        private System.Windows.Forms.TextBox tbxEPhone;
        private System.Windows.Forms.TextBox tbxEFName;
        private System.Windows.Forms.TextBox tbxEID;
    }
}