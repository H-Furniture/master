﻿
namespace HomeFurniture
{
    partial class frmResetPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlOne = new System.Windows.Forms.Panel();
            this.lblRestInstr = new System.Windows.Forms.Label();
            this.lblEmailRecover = new System.Windows.Forms.Label();
            this.tbxPassReset = new System.Windows.Forms.TextBox();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.btnRecover = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.pnlOne.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlOne
            // 
            this.pnlOne.BackColor = System.Drawing.Color.Beige;
            this.pnlOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOne.Controls.Add(this.lblRestInstr);
            this.pnlOne.Controls.Add(this.lblEmailRecover);
            this.pnlOne.Controls.Add(this.tbxPassReset);
            this.pnlOne.Location = new System.Drawing.Point(26, 57);
            this.pnlOne.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlOne.Name = "pnlOne";
            this.pnlOne.Size = new System.Drawing.Size(461, 181);
            this.pnlOne.TabIndex = 1;
            // 
            // lblRestInstr
            // 
            this.lblRestInstr.AutoSize = true;
            this.lblRestInstr.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRestInstr.Location = new System.Drawing.Point(24, 27);
            this.lblRestInstr.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRestInstr.Name = "lblRestInstr";
            this.lblRestInstr.Size = new System.Drawing.Size(409, 72);
            this.lblRestInstr.TabIndex = 0;
            this.lblRestInstr.Text = "Please enter your account email to reset your password. \r\nAn email will be sent t" +
    "o your account with instructions.";
            // 
            // lblEmailRecover
            // 
            this.lblEmailRecover.AutoSize = true;
            this.lblEmailRecover.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailRecover.Location = new System.Drawing.Point(82, 118);
            this.lblEmailRecover.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmailRecover.Name = "lblEmailRecover";
            this.lblEmailRecover.Size = new System.Drawing.Size(54, 32);
            this.lblEmailRecover.TabIndex = 1;
            this.lblEmailRecover.Text = "Email:";
            // 
            // tbxPassReset
            // 
            this.tbxPassReset.Font = new System.Drawing.Font("Javanese Text", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPassReset.Location = new System.Drawing.Point(140, 114);
            this.tbxPassReset.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxPassReset.Multiline = true;
            this.tbxPassReset.Name = "tbxPassReset";
            this.tbxPassReset.Size = new System.Drawing.Size(194, 36);
            this.tbxPassReset.TabIndex = 2;
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.BackColor = System.Drawing.Color.Beige;
            this.btnMainMenu.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainMenu.Location = new System.Drawing.Point(152, 243);
            this.btnMainMenu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(122, 37);
            this.btnMainMenu.TabIndex = 3;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.UseVisualStyleBackColor = false;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // btnRecover
            // 
            this.btnRecover.BackColor = System.Drawing.Color.Beige;
            this.btnRecover.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecover.Location = new System.Drawing.Point(26, 242);
            this.btnRecover.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRecover.Name = "btnRecover";
            this.btnRecover.Size = new System.Drawing.Size(122, 38);
            this.btnRecover.TabIndex = 2;
            this.btnRecover.Text = "Start Recovery";
            this.btnRecover.UseVisualStyleBackColor = false;
            this.btnRecover.Click += new System.EventHandler(this.btnRecover_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(119, 9);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(274, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Account Recovery";
            // 
            // lblMessage
            // 
            this.lblMessage.BackColor = System.Drawing.Color.Beige;
            this.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMessage.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(278, 243);
            this.lblMessage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(209, 37);
            this.lblMessage.TabIndex = 4;
            this.lblMessage.Text = "\r\n";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmResetPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(512, 289);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.pnlOne);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnRecover);
            this.Controls.Add(this.lblTitle);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmResetPassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reset Your Password";
            this.pnlOne.ResumeLayout(false);
            this.pnlOne.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel pnlOne;
        private System.Windows.Forms.Label lblRestInstr;
        private System.Windows.Forms.Label lblEmailRecover;
        private System.Windows.Forms.TextBox tbxPassReset;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Button btnRecover;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblMessage;
    }
}