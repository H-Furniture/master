﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using INEW2330_HomeFurniture; //added

namespace HomeFurniture
{
    public partial class frmResetUser : Form
    {
        public frmResetUser()
        {
            InitializeComponent();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            // Close this form (go back to Main Menu)
            this.Close();
        }

        private void btnRecover_Click(object sender, EventArgs e)
        {
            /* User inputs a userID or email.
             * Code determines which one was entered.
             * Code queries for that email or userID and displays it.
             */
        }
    }
}
