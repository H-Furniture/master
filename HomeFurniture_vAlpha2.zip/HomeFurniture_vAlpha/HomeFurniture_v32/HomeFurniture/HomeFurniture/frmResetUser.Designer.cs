﻿
namespace HomeFurniture
{
    partial class frmResetUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnRecover = new System.Windows.Forms.Button();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.pnlOne = new System.Windows.Forms.Panel();
            this.tbxResetUsername = new System.Windows.Forms.TextBox();
            this.lblResetUN = new System.Windows.Forms.Label();
            this.lblOutput = new System.Windows.Forms.Label();
            this.pnlOne.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(81, 18);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(274, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Account Recovery";
            // 
            // btnRecover
            // 
            this.btnRecover.BackColor = System.Drawing.Color.Beige;
            this.btnRecover.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecover.Location = new System.Drawing.Point(47, 212);
            this.btnRecover.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRecover.Name = "btnRecover";
            this.btnRecover.Size = new System.Drawing.Size(122, 38);
            this.btnRecover.TabIndex = 2;
            this.btnRecover.Text = "Recover";
            this.btnRecover.UseVisualStyleBackColor = false;
            this.btnRecover.Click += new System.EventHandler(this.btnRecover_Click);
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.BackColor = System.Drawing.Color.Beige;
            this.btnMainMenu.Font = new System.Drawing.Font("Javanese Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainMenu.Location = new System.Drawing.Point(47, 254);
            this.btnMainMenu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(122, 37);
            this.btnMainMenu.TabIndex = 4;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.UseVisualStyleBackColor = false;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // pnlOne
            // 
            this.pnlOne.BackColor = System.Drawing.Color.Beige;
            this.pnlOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOne.Controls.Add(this.tbxResetUsername);
            this.pnlOne.Controls.Add(this.lblResetUN);
            this.pnlOne.Location = new System.Drawing.Point(47, 73);
            this.pnlOne.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlOne.Name = "pnlOne";
            this.pnlOne.Size = new System.Drawing.Size(342, 135);
            this.pnlOne.TabIndex = 1;
            // 
            // tbxResetUsername
            // 
            this.tbxResetUsername.BackColor = System.Drawing.Color.LightCyan;
            this.tbxResetUsername.Font = new System.Drawing.Font("Javanese Text", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxResetUsername.Location = new System.Drawing.Point(72, 84);
            this.tbxResetUsername.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxResetUsername.Multiline = true;
            this.tbxResetUsername.Name = "tbxResetUsername";
            this.tbxResetUsername.Size = new System.Drawing.Size(194, 36);
            this.tbxResetUsername.TabIndex = 1;
            // 
            // lblResetUN
            // 
            this.lblResetUN.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResetUN.Location = new System.Drawing.Point(16, 10);
            this.lblResetUN.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblResetUN.Name = "lblResetUN";
            this.lblResetUN.Size = new System.Drawing.Size(307, 72);
            this.lblResetUN.TabIndex = 0;
            this.lblResetUN.Text = "Please enter your email to find userID, or userID to find email:";
            this.lblResetUN.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOutput
            // 
            this.lblOutput.BackColor = System.Drawing.Color.Beige;
            this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOutput.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutput.Location = new System.Drawing.Point(173, 212);
            this.lblOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(216, 79);
            this.lblOutput.TabIndex = 3;
            this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmResetUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(437, 309);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.pnlOne);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnRecover);
            this.Controls.Add(this.lblTitle);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmResetUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reset Your Information";
            this.pnlOne.ResumeLayout(false);
            this.pnlOne.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnRecover;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Panel pnlOne;
        private System.Windows.Forms.Label lblResetUN;
        private System.Windows.Forms.TextBox tbxResetUsername;
        private System.Windows.Forms.Label lblOutput;
    }
}