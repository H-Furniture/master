﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//added
using INEW2330_HomeFurniture;

namespace HomeFurniture
{
    public partial class frmNewUser : Form
    {
        public frmNewUser()
        {
            InitializeComponent();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            // Close this form (go back to Main Menu)
            this.Close();
        }

        private void btnCreateUser_Click(object sender, EventArgs e)
        {
            // Show that user has been created
            lblMessage.Text = "New user successfully created.";

            // Validate all of the input textboxes, then commit the new user data to the database




        }
    }
}
