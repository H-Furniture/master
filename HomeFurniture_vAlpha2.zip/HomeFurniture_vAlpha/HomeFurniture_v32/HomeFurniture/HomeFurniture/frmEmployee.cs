﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//added
using INEW2330_HomeFurniture;
namespace HomeFurniture
{
    public partial class frmEmployee : Form
    {
        // Create CurrencyManagers
        CurrencyManager customersManager;
        CurrencyManager ordersManager;
        CurrencyManager employeeManager;

        public frmEmployee()
        {
            InitializeComponent();
        }

        private void frmEmployee_Load(object sender, EventArgs e)
        {
            // Call data loading methods
            loadCustomerData();
            loadOrdersData();
            loadEmployeeData();

            // Set defaults
            btnSaveCust.Enabled = false;
            btnCancelCust.Enabled = false;
            btnNewCust.Enabled = false;
            btnRemoveCust.Enabled = false;

            btnDeleteOrder.Enabled = false;
            btnSaveOrder.Enabled = false;
            btnCancelOrder.Enabled = false;
            btnCustInfo.Enabled = false;

            btnSaveEmp.Enabled = false;
            btnCancelEmp.Enabled = false;
        }

        private void btnLogout1_Click(object sender, EventArgs e)
        {
            // Close form
            this.Hide();
        }

        private void btnLogout2_Click(object sender, EventArgs e)
        {
            // Close form
            this.Hide();
        }

        private void btnLogout3_Click(object sender, EventArgs e)
        {
            // Close form
            this.Hide();
        }

        private void loadCustomerData()
        {
            // Add textboxes to ProgOps to use in OpenCustomerLogin()
            ProgOps.TbxCID = tbxECID;
            ProgOps.TbxCFName = tbxECFName;
            ProgOps.TbxCLName = tbxECLName;
            ProgOps.TbxCPhone = tbxECPhone;
            ProgOps.TbxCAddress = tbxECAddress;
            ProgOps.TbxCCity = tbxECCity;
            ProgOps.TbxCState = tbxECCountry;
            ProgOps.TbxCFAX = tbxECFax;
            ProgOps.TbxCUser = tbxECUser;

            // Fill in data
            ProgOps.OpenCustomerLogin("SELECT * FROM group5sp212330.Customer, group5sp212330.Employee WHERE " +
                "Employee.UserID LIKE '" + trackingName.userName + "' AND Employee.CustomerID like Customer.CustomerID");

            // Establish CurrencyManager
            customersManager = (CurrencyManager)BindingContext[ProgOps.DTCustomer];
        }

        private void loadOrdersData()
        {
            // Add textboxes to ProgOps to use in OpenOrders()
            ProgOps.TbxOID = tbxECOID;
            ProgOps.TbxOCID = tbxCOCID;
            ProgOps.TbxODate = tbxEOrderDate;
            ProgOps.TbxOShipDate = tbxEShipDate;
            ProgOps.TbxOShipAdd = tbxEShipAdd;
            ProgOps.TbxOShipCity = tbxEShipCity;
            ProgOps.TbxOCountry = tbxEShipCountry;
            ProgOps.TbxOShipPC = tbxEOPC;
            // tbxCProduct
            // tbxCPrice
            ProgOps.TbxOEID = tbxEmployeeID;

            // Fill in data
            ProgOps.OpenOrders("SELECT * FROM group5sp212330.Orders, group5sp212300.Employee WHERE Employee.UserID LIKE '" + trackingName.userName + "'");

            // Establish CurrencyManager
            ordersManager = (CurrencyManager)BindingContext[ProgOps.DTOrders];
        }

        private void loadEmployeeData()
        {
            // Add textboxes to ProgOps to use in OpenEmployeeLogin()
            ProgOps.TbxEID = tbxEID;
            ProgOps.TbxEFName = tbxEFName;
            ProgOps.TbxELName = tbxELName;
            ProgOps.TbxEPhone = tbxEPhone;
            ProgOps.TbxEAddress = tbxEAddress;
            ProgOps.TbxECity = tbxECity;
            ProgOps.TbxEState = tbxEState;
            ProgOps.TbxEUser = tbxEUID;

            // Fill in data
            ProgOps.OpenEmployeeLogin("SELECT * FROM group5sp212330.Employee");

            // Establish CurrencyManager
            employeeManager = (CurrencyManager)BindingContext[ProgOps.DTEmployee];
        }

        private void btnPreviousCust_Click(object sender, EventArgs e)
        {
            // Move BACK a position
            customersManager.Position--;
        }

        private void btnNextCust_Click(object sender, EventArgs e)
        {
            // Move BACK a position
            customersManager.Position++;
        }

        private void btnPreviousOrder_Click(object sender, EventArgs e)
        {
            // Move BACK a position
            ordersManager.Position--;
        }

        private void btnNextOrder_Click(object sender, EventArgs e)
        {
            // Move BACK a position
            ordersManager.Position++;
        }
    }
}
