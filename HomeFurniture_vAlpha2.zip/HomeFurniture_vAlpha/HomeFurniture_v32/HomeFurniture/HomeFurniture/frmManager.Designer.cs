﻿
namespace HomeFurniture
{
    partial class frmManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabManagerInformation = new System.Windows.Forms.TabPage();
            this.btnManagerCancel = new System.Windows.Forms.Button();
            this.btnManagerSave = new System.Windows.Forms.Button();
            this.btnLogout4 = new System.Windows.Forms.Button();
            this.btnManagerEdit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbxMUID = new System.Windows.Forms.TextBox();
            this.tbxMState = new System.Windows.Forms.TextBox();
            this.tbxMCity = new System.Windows.Forms.TextBox();
            this.tbxMAddress = new System.Windows.Forms.TextBox();
            this.tbxMLName = new System.Windows.Forms.TextBox();
            this.tbxMPhone = new System.Windows.Forms.TextBox();
            this.tbxMFName = new System.Windows.Forms.TextBox();
            this.tbxMID = new System.Windows.Forms.TextBox();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl36 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tabEmployeeInformation = new System.Windows.Forms.TabPage();
            this.btnRemoveEmployee = new System.Windows.Forms.Button();
            this.btnNewEmployee = new System.Windows.Forms.Button();
            this.btnNextEmp = new System.Windows.Forms.Button();
            this.btnPreviousEmp = new System.Windows.Forms.Button();
            this.btnEmpOrdersAssigned = new System.Windows.Forms.Button();
            this.btnEmpCustomersAssigned = new System.Windows.Forms.Button();
            this.btnCancelEmp = new System.Windows.Forms.Button();
            this.lblTitle3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.tbxEUID = new System.Windows.Forms.TextBox();
            this.tbxEState = new System.Windows.Forms.TextBox();
            this.tbxECity = new System.Windows.Forms.TextBox();
            this.tbxEAddress = new System.Windows.Forms.TextBox();
            this.tbxELName = new System.Windows.Forms.TextBox();
            this.tbxEPhone = new System.Windows.Forms.TextBox();
            this.tbxEFName = new System.Windows.Forms.TextBox();
            this.tbxEID = new System.Windows.Forms.TextBox();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl26 = new System.Windows.Forms.Label();
            this.lbl27 = new System.Windows.Forms.Label();
            this.lbl28 = new System.Windows.Forms.Label();
            this.lbl29 = new System.Windows.Forms.Label();
            this.lbl30 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.btnLogout3 = new System.Windows.Forms.Button();
            this.btnSaveEmp = new System.Windows.Forms.Button();
            this.btnEditEmp = new System.Windows.Forms.Button();
            this.tabCustomerOrders = new System.Windows.Forms.TabPage();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.btnSaveOrder = new System.Windows.Forms.Button();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbxEmployeeID = new System.Windows.Forms.TextBox();
            this.tbxETotalPricing = new System.Windows.Forms.TextBox();
            this.tbxEOPC = new System.Windows.Forms.TextBox();
            this.tbxEProducts = new System.Windows.Forms.TextBox();
            this.tbxEShipCountry = new System.Windows.Forms.TextBox();
            this.tbxEShipCity = new System.Windows.Forms.TextBox();
            this.tbxEShipAdd = new System.Windows.Forms.TextBox();
            this.tbxEOrderDate = new System.Windows.Forms.TextBox();
            this.tbxEShipDate = new System.Windows.Forms.TextBox();
            this.tbxCOCID = new System.Windows.Forms.TextBox();
            this.tbxECOID = new System.Windows.Forms.TextBox();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.btnChangeEmployee = new System.Windows.Forms.Button();
            this.btnCustInfo = new System.Windows.Forms.Button();
            this.btnLogout2 = new System.Windows.Forms.Button();
            this.btnNextOrder = new System.Windows.Forms.Button();
            this.btnPreviousOrder = new System.Windows.Forms.Button();
            this.btnDeleteOrder = new System.Windows.Forms.Button();
            this.btnEditOrder = new System.Windows.Forms.Button();
            this.tabCustomerInformation = new System.Windows.Forms.TabPage();
            this.btnReassignEmployee = new System.Windows.Forms.Button();
            this.btnNewCust = new System.Windows.Forms.Button();
            this.btnRemoveCust = new System.Windows.Forms.Button();
            this.btnNextCust = new System.Windows.Forms.Button();
            this.btnPreviousCust = new System.Windows.Forms.Button();
            this.btnCancelCust = new System.Windows.Forms.Button();
            this.btnSaveCust = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlOne = new System.Windows.Forms.Panel();
            this.tbxECPC = new System.Windows.Forms.TextBox();
            this.tbxECFax = new System.Windows.Forms.TextBox();
            this.tbxECUser = new System.Windows.Forms.TextBox();
            this.tbxECCountry = new System.Windows.Forms.TextBox();
            this.tbxECCity = new System.Windows.Forms.TextBox();
            this.tbxECAddress = new System.Windows.Forms.TextBox();
            this.tbxECLName = new System.Windows.Forms.TextBox();
            this.tbxECPhone = new System.Windows.Forms.TextBox();
            this.tbxECFName = new System.Windows.Forms.TextBox();
            this.tbxECID = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.btnLogout1 = new System.Windows.Forms.Button();
            this.btnViewOrders = new System.Windows.Forms.Button();
            this.btnEditCust = new System.Windows.Forms.Button();
            this.tbcOne = new System.Windows.Forms.TabControl();
            this.tabReportViewer = new System.Windows.Forms.TabPage();
            this.btnCustomerViewer = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnEmployeeReport = new System.Windows.Forms.Button();
            this.btnManagersReport = new System.Windows.Forms.Button();
            this.btnOrdersReport = new System.Windows.Forms.Button();
            this.tabManagerInformation.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabEmployeeInformation.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabCustomerOrders.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabCustomerInformation.SuspendLayout();
            this.pnlOne.SuspendLayout();
            this.tbcOne.SuspendLayout();
            this.tabReportViewer.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabManagerInformation
            // 
            this.tabManagerInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabManagerInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabManagerInformation.Controls.Add(this.btnManagerCancel);
            this.tabManagerInformation.Controls.Add(this.btnManagerSave);
            this.tabManagerInformation.Controls.Add(this.btnLogout4);
            this.tabManagerInformation.Controls.Add(this.btnManagerEdit);
            this.tabManagerInformation.Controls.Add(this.label1);
            this.tabManagerInformation.Controls.Add(this.panel3);
            this.tabManagerInformation.Location = new System.Drawing.Point(4, 38);
            this.tabManagerInformation.Margin = new System.Windows.Forms.Padding(4);
            this.tabManagerInformation.Name = "tabManagerInformation";
            this.tabManagerInformation.Padding = new System.Windows.Forms.Padding(4);
            this.tabManagerInformation.Size = new System.Drawing.Size(745, 644);
            this.tabManagerInformation.TabIndex = 3;
            this.tabManagerInformation.Text = "Manager Information";
            // 
            // btnManagerCancel
            // 
            this.btnManagerCancel.BackColor = System.Drawing.Color.Beige;
            this.btnManagerCancel.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagerCancel.Location = new System.Drawing.Point(465, 443);
            this.btnManagerCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnManagerCancel.Name = "btnManagerCancel";
            this.btnManagerCancel.Size = new System.Drawing.Size(161, 46);
            this.btnManagerCancel.TabIndex = 16;
            this.btnManagerCancel.Text = "Cancel";
            this.btnManagerCancel.UseVisualStyleBackColor = false;
            // 
            // btnManagerSave
            // 
            this.btnManagerSave.BackColor = System.Drawing.Color.Beige;
            this.btnManagerSave.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagerSave.Location = new System.Drawing.Point(296, 443);
            this.btnManagerSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnManagerSave.Name = "btnManagerSave";
            this.btnManagerSave.Size = new System.Drawing.Size(161, 46);
            this.btnManagerSave.TabIndex = 15;
            this.btnManagerSave.Text = "Save";
            this.btnManagerSave.UseVisualStyleBackColor = false;
            // 
            // btnLogout4
            // 
            this.btnLogout4.BackColor = System.Drawing.Color.Beige;
            this.btnLogout4.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout4.Location = new System.Drawing.Point(11, 581);
            this.btnLogout4.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout4.Name = "btnLogout4";
            this.btnLogout4.Size = new System.Drawing.Size(161, 47);
            this.btnLogout4.TabIndex = 14;
            this.btnLogout4.Text = "Main Menu";
            this.btnLogout4.UseVisualStyleBackColor = false;
            this.btnLogout4.Click += new System.EventHandler(this.btnLogout4_Click);
            // 
            // btnManagerEdit
            // 
            this.btnManagerEdit.BackColor = System.Drawing.Color.Beige;
            this.btnManagerEdit.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagerEdit.Location = new System.Drawing.Point(125, 443);
            this.btnManagerEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnManagerEdit.Name = "btnManagerEdit";
            this.btnManagerEdit.Size = new System.Drawing.Size(161, 46);
            this.btnManagerEdit.TabIndex = 13;
            this.btnManagerEdit.Text = "Change Information";
            this.btnManagerEdit.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(103, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(537, 44);
            this.label1.TabIndex = 7;
            this.label1.Text = "Manager Information";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Beige;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.tbxMUID);
            this.panel3.Controls.Add(this.tbxMState);
            this.panel3.Controls.Add(this.tbxMCity);
            this.panel3.Controls.Add(this.tbxMAddress);
            this.panel3.Controls.Add(this.tbxMLName);
            this.panel3.Controls.Add(this.tbxMPhone);
            this.panel3.Controls.Add(this.tbxMFName);
            this.panel3.Controls.Add(this.tbxMID);
            this.panel3.Controls.Add(this.lbl32);
            this.panel3.Controls.Add(this.lbl33);
            this.panel3.Controls.Add(this.lbl34);
            this.panel3.Controls.Add(this.lbl35);
            this.panel3.Controls.Add(this.lbl36);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Location = new System.Drawing.Point(103, 156);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(537, 255);
            this.panel3.TabIndex = 8;
            // 
            // tbxMUID
            // 
            this.tbxMUID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMUID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMUID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMUID.Location = new System.Drawing.Point(137, 218);
            this.tbxMUID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxMUID.Name = "tbxMUID";
            this.tbxMUID.Size = new System.Drawing.Size(367, 19);
            this.tbxMUID.TabIndex = 52;
            // 
            // tbxMState
            // 
            this.tbxMState.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMState.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMState.Location = new System.Drawing.Point(137, 190);
            this.tbxMState.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxMState.Name = "tbxMState";
            this.tbxMState.Size = new System.Drawing.Size(367, 19);
            this.tbxMState.TabIndex = 50;
            // 
            // tbxMCity
            // 
            this.tbxMCity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMCity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMCity.Location = new System.Drawing.Point(137, 162);
            this.tbxMCity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxMCity.Name = "tbxMCity";
            this.tbxMCity.Size = new System.Drawing.Size(367, 19);
            this.tbxMCity.TabIndex = 49;
            // 
            // tbxMAddress
            // 
            this.tbxMAddress.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMAddress.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMAddress.Location = new System.Drawing.Point(137, 134);
            this.tbxMAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxMAddress.Name = "tbxMAddress";
            this.tbxMAddress.Size = new System.Drawing.Size(367, 19);
            this.tbxMAddress.TabIndex = 48;
            // 
            // tbxMLName
            // 
            this.tbxMLName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMLName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMLName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMLName.Location = new System.Drawing.Point(137, 78);
            this.tbxMLName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxMLName.Name = "tbxMLName";
            this.tbxMLName.Size = new System.Drawing.Size(367, 19);
            this.tbxMLName.TabIndex = 47;
            // 
            // tbxMPhone
            // 
            this.tbxMPhone.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMPhone.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMPhone.Location = new System.Drawing.Point(137, 106);
            this.tbxMPhone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxMPhone.Name = "tbxMPhone";
            this.tbxMPhone.Size = new System.Drawing.Size(367, 19);
            this.tbxMPhone.TabIndex = 46;
            // 
            // tbxMFName
            // 
            this.tbxMFName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMFName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMFName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMFName.Location = new System.Drawing.Point(137, 49);
            this.tbxMFName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxMFName.Name = "tbxMFName";
            this.tbxMFName.Size = new System.Drawing.Size(367, 19);
            this.tbxMFName.TabIndex = 45;
            // 
            // tbxMID
            // 
            this.tbxMID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxMID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxMID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxMID.Location = new System.Drawing.Point(137, 21);
            this.tbxMID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxMID.Name = "tbxMID";
            this.tbxMID.Size = new System.Drawing.Size(367, 19);
            this.tbxMID.TabIndex = 44;
            // 
            // lbl32
            // 
            this.lbl32.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.Location = new System.Drawing.Point(19, 15);
            this.lbl32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(121, 28);
            this.lbl32.TabIndex = 0;
            this.lbl32.Text = "Manager ID:";
            this.lbl32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl33
            // 
            this.lbl33.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.Location = new System.Drawing.Point(19, 43);
            this.lbl33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(121, 28);
            this.lbl33.TabIndex = 2;
            this.lbl33.Text = "First Name:";
            this.lbl33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl34
            // 
            this.lbl34.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl34.Location = new System.Drawing.Point(19, 71);
            this.lbl34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(121, 28);
            this.lbl34.TabIndex = 4;
            this.lbl34.Text = "Last Name:";
            this.lbl34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl35
            // 
            this.lbl35.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl35.Location = new System.Drawing.Point(19, 100);
            this.lbl35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(121, 28);
            this.lbl35.TabIndex = 6;
            this.lbl35.Text = "Phone Number:";
            this.lbl35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl36
            // 
            this.lbl36.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl36.Location = new System.Drawing.Point(19, 128);
            this.lbl36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(121, 28);
            this.lbl36.TabIndex = 8;
            this.lbl36.Text = "Address:";
            this.lbl36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 156);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 28);
            this.label8.TabIndex = 10;
            this.label8.Text = "City:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(19, 185);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 28);
            this.label9.TabIndex = 12;
            this.label9.Text = "State:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(19, 213);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 28);
            this.label11.TabIndex = 16;
            this.label11.Text = "User ID:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabEmployeeInformation
            // 
            this.tabEmployeeInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabEmployeeInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabEmployeeInformation.Controls.Add(this.btnRemoveEmployee);
            this.tabEmployeeInformation.Controls.Add(this.btnNewEmployee);
            this.tabEmployeeInformation.Controls.Add(this.btnNextEmp);
            this.tabEmployeeInformation.Controls.Add(this.btnPreviousEmp);
            this.tabEmployeeInformation.Controls.Add(this.btnEmpOrdersAssigned);
            this.tabEmployeeInformation.Controls.Add(this.btnEmpCustomersAssigned);
            this.tabEmployeeInformation.Controls.Add(this.btnCancelEmp);
            this.tabEmployeeInformation.Controls.Add(this.lblTitle3);
            this.tabEmployeeInformation.Controls.Add(this.panel2);
            this.tabEmployeeInformation.Controls.Add(this.btnLogout3);
            this.tabEmployeeInformation.Controls.Add(this.btnSaveEmp);
            this.tabEmployeeInformation.Controls.Add(this.btnEditEmp);
            this.tabEmployeeInformation.Location = new System.Drawing.Point(4, 38);
            this.tabEmployeeInformation.Margin = new System.Windows.Forms.Padding(4);
            this.tabEmployeeInformation.Name = "tabEmployeeInformation";
            this.tabEmployeeInformation.Padding = new System.Windows.Forms.Padding(4);
            this.tabEmployeeInformation.Size = new System.Drawing.Size(745, 644);
            this.tabEmployeeInformation.TabIndex = 2;
            this.tabEmployeeInformation.Text = "Employee Information";
            // 
            // btnRemoveEmployee
            // 
            this.btnRemoveEmployee.BackColor = System.Drawing.Color.Beige;
            this.btnRemoveEmployee.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveEmployee.Location = new System.Drawing.Point(291, 519);
            this.btnRemoveEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.btnRemoveEmployee.Name = "btnRemoveEmployee";
            this.btnRemoveEmployee.Size = new System.Drawing.Size(161, 46);
            this.btnRemoveEmployee.TabIndex = 30;
            this.btnRemoveEmployee.Text = "Remove";
            this.btnRemoveEmployee.UseVisualStyleBackColor = false;
            // 
            // btnNewEmployee
            // 
            this.btnNewEmployee.BackColor = System.Drawing.Color.Beige;
            this.btnNewEmployee.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewEmployee.Location = new System.Drawing.Point(460, 519);
            this.btnNewEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.btnNewEmployee.Name = "btnNewEmployee";
            this.btnNewEmployee.Size = new System.Drawing.Size(161, 46);
            this.btnNewEmployee.TabIndex = 29;
            this.btnNewEmployee.Text = "Add New Employee";
            this.btnNewEmployee.UseVisualStyleBackColor = false;
            // 
            // btnNextEmp
            // 
            this.btnNextEmp.BackColor = System.Drawing.Color.Beige;
            this.btnNextEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextEmp.Location = new System.Drawing.Point(457, 390);
            this.btnNextEmp.Margin = new System.Windows.Forms.Padding(4);
            this.btnNextEmp.Name = "btnNextEmp";
            this.btnNextEmp.Size = new System.Drawing.Size(161, 46);
            this.btnNextEmp.TabIndex = 28;
            this.btnNextEmp.Text = "Next Page";
            this.btnNextEmp.UseVisualStyleBackColor = false;
            this.btnNextEmp.Click += new System.EventHandler(this.btnNextEmp_Click);
            // 
            // btnPreviousEmp
            // 
            this.btnPreviousEmp.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousEmp.Location = new System.Drawing.Point(121, 390);
            this.btnPreviousEmp.Margin = new System.Windows.Forms.Padding(4);
            this.btnPreviousEmp.Name = "btnPreviousEmp";
            this.btnPreviousEmp.Size = new System.Drawing.Size(161, 46);
            this.btnPreviousEmp.TabIndex = 27;
            this.btnPreviousEmp.Text = "Previous Page";
            this.btnPreviousEmp.UseVisualStyleBackColor = false;
            this.btnPreviousEmp.Click += new System.EventHandler(this.btnPreviousEmp_Click);
            // 
            // btnEmpOrdersAssigned
            // 
            this.btnEmpOrdersAssigned.BackColor = System.Drawing.Color.Beige;
            this.btnEmpOrdersAssigned.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpOrdersAssigned.Location = new System.Drawing.Point(288, 390);
            this.btnEmpOrdersAssigned.Margin = new System.Windows.Forms.Padding(4);
            this.btnEmpOrdersAssigned.Name = "btnEmpOrdersAssigned";
            this.btnEmpOrdersAssigned.Size = new System.Drawing.Size(161, 46);
            this.btnEmpOrdersAssigned.TabIndex = 26;
            this.btnEmpOrdersAssigned.Text = "Orders Assigned";
            this.btnEmpOrdersAssigned.UseVisualStyleBackColor = false;
            // 
            // btnEmpCustomersAssigned
            // 
            this.btnEmpCustomersAssigned.BackColor = System.Drawing.Color.Beige;
            this.btnEmpCustomersAssigned.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpCustomersAssigned.Location = new System.Drawing.Point(121, 519);
            this.btnEmpCustomersAssigned.Margin = new System.Windows.Forms.Padding(4);
            this.btnEmpCustomersAssigned.Name = "btnEmpCustomersAssigned";
            this.btnEmpCustomersAssigned.Size = new System.Drawing.Size(161, 46);
            this.btnEmpCustomersAssigned.TabIndex = 25;
            this.btnEmpCustomersAssigned.Text = "Customers Assigned";
            this.btnEmpCustomersAssigned.UseVisualStyleBackColor = false;
            // 
            // btnCancelEmp
            // 
            this.btnCancelEmp.BackColor = System.Drawing.Color.Beige;
            this.btnCancelEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelEmp.Location = new System.Drawing.Point(460, 455);
            this.btnCancelEmp.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelEmp.Name = "btnCancelEmp";
            this.btnCancelEmp.Size = new System.Drawing.Size(161, 46);
            this.btnCancelEmp.TabIndex = 24;
            this.btnCancelEmp.Text = "Cancel";
            this.btnCancelEmp.UseVisualStyleBackColor = false;
            // 
            // lblTitle3
            // 
            this.lblTitle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle3.Location = new System.Drawing.Point(103, 39);
            this.lblTitle3.Name = "lblTitle3";
            this.lblTitle3.Size = new System.Drawing.Size(537, 44);
            this.lblTitle3.TabIndex = 19;
            this.lblTitle3.Text = "Employee Information";
            this.lblTitle3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Beige;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.textBox10);
            this.panel2.Controls.Add(this.tbxEUID);
            this.panel2.Controls.Add(this.tbxEState);
            this.panel2.Controls.Add(this.tbxECity);
            this.panel2.Controls.Add(this.tbxEAddress);
            this.panel2.Controls.Add(this.tbxELName);
            this.panel2.Controls.Add(this.tbxEPhone);
            this.panel2.Controls.Add(this.tbxEFName);
            this.panel2.Controls.Add(this.tbxEID);
            this.panel2.Controls.Add(this.lbl23);
            this.panel2.Controls.Add(this.lbl24);
            this.panel2.Controls.Add(this.lbl25);
            this.panel2.Controls.Add(this.lbl26);
            this.panel2.Controls.Add(this.lbl27);
            this.panel2.Controls.Add(this.lbl28);
            this.panel2.Controls.Add(this.lbl29);
            this.panel2.Controls.Add(this.lbl30);
            this.panel2.Controls.Add(this.lbl31);
            this.panel2.Location = new System.Drawing.Point(103, 86);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(537, 285);
            this.panel2.TabIndex = 20;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.LightCyan;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(139, 218);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(367, 19);
            this.textBox10.TabIndex = 43;
            // 
            // tbxEUID
            // 
            this.tbxEUID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEUID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEUID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEUID.Location = new System.Drawing.Point(139, 247);
            this.tbxEUID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEUID.Name = "tbxEUID";
            this.tbxEUID.Size = new System.Drawing.Size(367, 19);
            this.tbxEUID.TabIndex = 42;
            // 
            // tbxEState
            // 
            this.tbxEState.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEState.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEState.Location = new System.Drawing.Point(139, 190);
            this.tbxEState.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEState.Name = "tbxEState";
            this.tbxEState.Size = new System.Drawing.Size(367, 19);
            this.tbxEState.TabIndex = 41;
            // 
            // tbxECity
            // 
            this.tbxECity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECity.Location = new System.Drawing.Point(139, 162);
            this.tbxECity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECity.Name = "tbxECity";
            this.tbxECity.Size = new System.Drawing.Size(367, 19);
            this.tbxECity.TabIndex = 40;
            // 
            // tbxEAddress
            // 
            this.tbxEAddress.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEAddress.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEAddress.Location = new System.Drawing.Point(139, 134);
            this.tbxEAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEAddress.Name = "tbxEAddress";
            this.tbxEAddress.Size = new System.Drawing.Size(367, 19);
            this.tbxEAddress.TabIndex = 39;
            // 
            // tbxELName
            // 
            this.tbxELName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxELName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxELName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxELName.Location = new System.Drawing.Point(139, 78);
            this.tbxELName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxELName.Name = "tbxELName";
            this.tbxELName.Size = new System.Drawing.Size(367, 19);
            this.tbxELName.TabIndex = 38;
            // 
            // tbxEPhone
            // 
            this.tbxEPhone.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEPhone.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEPhone.Location = new System.Drawing.Point(139, 106);
            this.tbxEPhone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEPhone.Name = "tbxEPhone";
            this.tbxEPhone.Size = new System.Drawing.Size(367, 19);
            this.tbxEPhone.TabIndex = 37;
            // 
            // tbxEFName
            // 
            this.tbxEFName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEFName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEFName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEFName.Location = new System.Drawing.Point(139, 49);
            this.tbxEFName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEFName.Name = "tbxEFName";
            this.tbxEFName.Size = new System.Drawing.Size(367, 19);
            this.tbxEFName.TabIndex = 36;
            // 
            // tbxEID
            // 
            this.tbxEID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEID.Location = new System.Drawing.Point(139, 21);
            this.tbxEID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEID.Name = "tbxEID";
            this.tbxEID.Size = new System.Drawing.Size(367, 19);
            this.tbxEID.TabIndex = 35;
            // 
            // lbl23
            // 
            this.lbl23.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.Location = new System.Drawing.Point(20, 15);
            this.lbl23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(121, 28);
            this.lbl23.TabIndex = 0;
            this.lbl23.Text = "Employee ID:";
            this.lbl23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl24
            // 
            this.lbl24.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.Location = new System.Drawing.Point(20, 43);
            this.lbl24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(121, 28);
            this.lbl24.TabIndex = 2;
            this.lbl24.Text = "First Name:";
            this.lbl24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl25
            // 
            this.lbl25.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.Location = new System.Drawing.Point(20, 71);
            this.lbl25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(121, 28);
            this.lbl25.TabIndex = 4;
            this.lbl25.Text = "Last Name:";
            this.lbl25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl26
            // 
            this.lbl26.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26.Location = new System.Drawing.Point(20, 100);
            this.lbl26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(121, 28);
            this.lbl26.TabIndex = 6;
            this.lbl26.Text = "Phone Number:";
            this.lbl26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl27
            // 
            this.lbl27.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27.Location = new System.Drawing.Point(20, 128);
            this.lbl27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(121, 28);
            this.lbl27.TabIndex = 8;
            this.lbl27.Text = "Address:";
            this.lbl27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl28
            // 
            this.lbl28.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl28.Location = new System.Drawing.Point(20, 156);
            this.lbl28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(121, 28);
            this.lbl28.TabIndex = 10;
            this.lbl28.Text = "City:";
            this.lbl28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl29
            // 
            this.lbl29.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl29.Location = new System.Drawing.Point(20, 185);
            this.lbl29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(121, 28);
            this.lbl29.TabIndex = 12;
            this.lbl29.Text = "State:";
            this.lbl29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl30
            // 
            this.lbl30.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl30.Location = new System.Drawing.Point(20, 213);
            this.lbl30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(121, 28);
            this.lbl30.TabIndex = 14;
            this.lbl30.Text = "Fax:";
            this.lbl30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl31
            // 
            this.lbl31.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.Location = new System.Drawing.Point(20, 241);
            this.lbl31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(121, 28);
            this.lbl31.TabIndex = 16;
            this.lbl31.Text = "User ID:";
            this.lbl31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLogout3
            // 
            this.btnLogout3.BackColor = System.Drawing.Color.Beige;
            this.btnLogout3.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout3.Location = new System.Drawing.Point(8, 583);
            this.btnLogout3.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout3.Name = "btnLogout3";
            this.btnLogout3.Size = new System.Drawing.Size(161, 46);
            this.btnLogout3.TabIndex = 23;
            this.btnLogout3.Text = "Main Menu";
            this.btnLogout3.UseVisualStyleBackColor = false;
            this.btnLogout3.Click += new System.EventHandler(this.btnLogout3_Click);
            // 
            // btnSaveEmp
            // 
            this.btnSaveEmp.BackColor = System.Drawing.Color.Beige;
            this.btnSaveEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveEmp.Location = new System.Drawing.Point(291, 455);
            this.btnSaveEmp.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveEmp.Name = "btnSaveEmp";
            this.btnSaveEmp.Size = new System.Drawing.Size(161, 46);
            this.btnSaveEmp.TabIndex = 22;
            this.btnSaveEmp.Text = "Save";
            this.btnSaveEmp.UseVisualStyleBackColor = false;
            // 
            // btnEditEmp
            // 
            this.btnEditEmp.BackColor = System.Drawing.Color.Beige;
            this.btnEditEmp.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditEmp.Location = new System.Drawing.Point(121, 455);
            this.btnEditEmp.Margin = new System.Windows.Forms.Padding(4);
            this.btnEditEmp.Name = "btnEditEmp";
            this.btnEditEmp.Size = new System.Drawing.Size(161, 46);
            this.btnEditEmp.TabIndex = 21;
            this.btnEditEmp.Text = "Change Information";
            this.btnEditEmp.UseVisualStyleBackColor = false;
            // 
            // tabCustomerOrders
            // 
            this.tabCustomerOrders.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerOrders.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabCustomerOrders.Controls.Add(this.btnCancelOrder);
            this.tabCustomerOrders.Controls.Add(this.btnSaveOrder);
            this.tabCustomerOrders.Controls.Add(this.lblTitle2);
            this.tabCustomerOrders.Controls.Add(this.panel1);
            this.tabCustomerOrders.Controls.Add(this.btnChangeEmployee);
            this.tabCustomerOrders.Controls.Add(this.btnCustInfo);
            this.tabCustomerOrders.Controls.Add(this.btnLogout2);
            this.tabCustomerOrders.Controls.Add(this.btnNextOrder);
            this.tabCustomerOrders.Controls.Add(this.btnPreviousOrder);
            this.tabCustomerOrders.Controls.Add(this.btnDeleteOrder);
            this.tabCustomerOrders.Controls.Add(this.btnEditOrder);
            this.tabCustomerOrders.Location = new System.Drawing.Point(4, 38);
            this.tabCustomerOrders.Margin = new System.Windows.Forms.Padding(4);
            this.tabCustomerOrders.Name = "tabCustomerOrders";
            this.tabCustomerOrders.Padding = new System.Windows.Forms.Padding(4);
            this.tabCustomerOrders.Size = new System.Drawing.Size(745, 644);
            this.tabCustomerOrders.TabIndex = 1;
            this.tabCustomerOrders.Text = "Customer Orders";
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnCancelOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelOrder.Location = new System.Drawing.Point(205, 464);
            this.btnCancelOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(161, 46);
            this.btnCancelOrder.TabIndex = 43;
            this.btnCancelOrder.Text = "Cancel";
            this.btnCancelOrder.UseVisualStyleBackColor = false;
            // 
            // btnSaveOrder
            // 
            this.btnSaveOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnSaveOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveOrder.Location = new System.Drawing.Point(375, 464);
            this.btnSaveOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveOrder.Name = "btnSaveOrder";
            this.btnSaveOrder.Size = new System.Drawing.Size(161, 46);
            this.btnSaveOrder.TabIndex = 42;
            this.btnSaveOrder.Text = "Save";
            this.btnSaveOrder.UseVisualStyleBackColor = false;
            // 
            // lblTitle2
            // 
            this.lblTitle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle2.Location = new System.Drawing.Point(121, 5);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(499, 44);
            this.lblTitle2.TabIndex = 41;
            this.lblTitle2.Text = "View Orders";
            this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Beige;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.tbxEmployeeID);
            this.panel1.Controls.Add(this.tbxETotalPricing);
            this.panel1.Controls.Add(this.tbxEOPC);
            this.panel1.Controls.Add(this.tbxEProducts);
            this.panel1.Controls.Add(this.tbxEShipCountry);
            this.panel1.Controls.Add(this.tbxEShipCity);
            this.panel1.Controls.Add(this.tbxEShipAdd);
            this.panel1.Controls.Add(this.tbxEOrderDate);
            this.panel1.Controls.Add(this.tbxEShipDate);
            this.panel1.Controls.Add(this.tbxCOCID);
            this.panel1.Controls.Add(this.tbxECOID);
            this.panel1.Controls.Add(this.lbl12);
            this.panel1.Controls.Add(this.lbl13);
            this.panel1.Controls.Add(this.lbl14);
            this.panel1.Controls.Add(this.lbl15);
            this.panel1.Controls.Add(this.lbl16);
            this.panel1.Controls.Add(this.lbl17);
            this.panel1.Controls.Add(this.lbl18);
            this.panel1.Controls.Add(this.lbl19);
            this.panel1.Controls.Add(this.lbl20);
            this.panel1.Controls.Add(this.lbl21);
            this.panel1.Controls.Add(this.lbl22);
            this.panel1.Location = new System.Drawing.Point(121, 52);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(499, 394);
            this.panel1.TabIndex = 40;
            // 
            // tbxEmployeeID
            // 
            this.tbxEmployeeID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEmployeeID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEmployeeID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEmployeeID.Location = new System.Drawing.Point(153, 361);
            this.tbxEmployeeID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEmployeeID.Name = "tbxEmployeeID";
            this.tbxEmployeeID.Size = new System.Drawing.Size(312, 19);
            this.tbxEmployeeID.TabIndex = 56;
            // 
            // tbxETotalPricing
            // 
            this.tbxETotalPricing.BackColor = System.Drawing.Color.LightCyan;
            this.tbxETotalPricing.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxETotalPricing.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxETotalPricing.Location = new System.Drawing.Point(153, 332);
            this.tbxETotalPricing.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxETotalPricing.Name = "tbxETotalPricing";
            this.tbxETotalPricing.Size = new System.Drawing.Size(312, 19);
            this.tbxETotalPricing.TabIndex = 55;
            // 
            // tbxEOPC
            // 
            this.tbxEOPC.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEOPC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEOPC.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEOPC.Location = new System.Drawing.Point(153, 217);
            this.tbxEOPC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEOPC.Name = "tbxEOPC";
            this.tbxEOPC.Size = new System.Drawing.Size(312, 19);
            this.tbxEOPC.TabIndex = 54;
            // 
            // tbxEProducts
            // 
            this.tbxEProducts.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEProducts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEProducts.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEProducts.Location = new System.Drawing.Point(153, 246);
            this.tbxEProducts.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEProducts.Multiline = true;
            this.tbxEProducts.Name = "tbxEProducts";
            this.tbxEProducts.Size = new System.Drawing.Size(312, 74);
            this.tbxEProducts.TabIndex = 53;
            // 
            // tbxEShipCountry
            // 
            this.tbxEShipCountry.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEShipCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEShipCountry.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEShipCountry.Location = new System.Drawing.Point(153, 190);
            this.tbxEShipCountry.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEShipCountry.Name = "tbxEShipCountry";
            this.tbxEShipCountry.Size = new System.Drawing.Size(312, 19);
            this.tbxEShipCountry.TabIndex = 52;
            // 
            // tbxEShipCity
            // 
            this.tbxEShipCity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEShipCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEShipCity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEShipCity.Location = new System.Drawing.Point(153, 161);
            this.tbxEShipCity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEShipCity.Name = "tbxEShipCity";
            this.tbxEShipCity.Size = new System.Drawing.Size(312, 19);
            this.tbxEShipCity.TabIndex = 51;
            // 
            // tbxEShipAdd
            // 
            this.tbxEShipAdd.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEShipAdd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEShipAdd.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEShipAdd.Location = new System.Drawing.Point(153, 133);
            this.tbxEShipAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEShipAdd.Name = "tbxEShipAdd";
            this.tbxEShipAdd.Size = new System.Drawing.Size(312, 19);
            this.tbxEShipAdd.TabIndex = 50;
            // 
            // tbxEOrderDate
            // 
            this.tbxEOrderDate.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEOrderDate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEOrderDate.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEOrderDate.Location = new System.Drawing.Point(153, 76);
            this.tbxEOrderDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEOrderDate.Name = "tbxEOrderDate";
            this.tbxEOrderDate.Size = new System.Drawing.Size(312, 19);
            this.tbxEOrderDate.TabIndex = 49;
            // 
            // tbxEShipDate
            // 
            this.tbxEShipDate.BackColor = System.Drawing.Color.LightCyan;
            this.tbxEShipDate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxEShipDate.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxEShipDate.Location = new System.Drawing.Point(153, 105);
            this.tbxEShipDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxEShipDate.Name = "tbxEShipDate";
            this.tbxEShipDate.Size = new System.Drawing.Size(312, 19);
            this.tbxEShipDate.TabIndex = 48;
            // 
            // tbxCOCID
            // 
            this.tbxCOCID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxCOCID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxCOCID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxCOCID.Location = new System.Drawing.Point(153, 48);
            this.tbxCOCID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxCOCID.Name = "tbxCOCID";
            this.tbxCOCID.Size = new System.Drawing.Size(312, 19);
            this.tbxCOCID.TabIndex = 47;
            // 
            // tbxECOID
            // 
            this.tbxECOID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECOID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECOID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECOID.Location = new System.Drawing.Point(153, 20);
            this.tbxECOID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECOID.Name = "tbxECOID";
            this.tbxECOID.Size = new System.Drawing.Size(312, 19);
            this.tbxECOID.TabIndex = 46;
            // 
            // lbl12
            // 
            this.lbl12.Location = new System.Drawing.Point(25, 14);
            this.lbl12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(121, 28);
            this.lbl12.TabIndex = 22;
            this.lbl12.Text = "Order ID:";
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl13
            // 
            this.lbl13.Location = new System.Drawing.Point(25, 42);
            this.lbl13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(121, 28);
            this.lbl13.TabIndex = 24;
            this.lbl13.Text = "Customer ID:";
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl14
            // 
            this.lbl14.Location = new System.Drawing.Point(25, 70);
            this.lbl14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(121, 28);
            this.lbl14.TabIndex = 26;
            this.lbl14.Text = "Order Date:";
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl15
            // 
            this.lbl15.Location = new System.Drawing.Point(25, 98);
            this.lbl15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(121, 28);
            this.lbl15.TabIndex = 28;
            this.lbl15.Text = "Shipped Date:";
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl16
            // 
            this.lbl16.Location = new System.Drawing.Point(4, 127);
            this.lbl16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(143, 28);
            this.lbl16.TabIndex = 30;
            this.lbl16.Text = "Shipped Address:";
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl17
            // 
            this.lbl17.Location = new System.Drawing.Point(25, 155);
            this.lbl17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(121, 28);
            this.lbl17.TabIndex = 32;
            this.lbl17.Text = "Shipped City:";
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl18
            // 
            this.lbl18.Location = new System.Drawing.Point(4, 183);
            this.lbl18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(143, 28);
            this.lbl18.TabIndex = 34;
            this.lbl18.Text = "Shipped Country:";
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl19
            // 
            this.lbl19.Location = new System.Drawing.Point(25, 210);
            this.lbl19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(121, 28);
            this.lbl19.TabIndex = 36;
            this.lbl19.Text = "Postal Code:";
            this.lbl19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl20
            // 
            this.lbl20.Location = new System.Drawing.Point(25, 240);
            this.lbl20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(121, 86);
            this.lbl20.TabIndex = 38;
            this.lbl20.Text = "Products:";
            this.lbl20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl21
            // 
            this.lbl21.Location = new System.Drawing.Point(25, 326);
            this.lbl21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(121, 28);
            this.lbl21.TabIndex = 40;
            this.lbl21.Text = "Total Price:";
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl22
            // 
            this.lbl22.Location = new System.Drawing.Point(25, 354);
            this.lbl22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(121, 28);
            this.lbl22.TabIndex = 42;
            this.lbl22.Text = "Employee ID:";
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnChangeEmployee
            // 
            this.btnChangeEmployee.BackColor = System.Drawing.SystemColors.Info;
            this.btnChangeEmployee.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangeEmployee.Location = new System.Drawing.Point(544, 464);
            this.btnChangeEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.btnChangeEmployee.Name = "btnChangeEmployee";
            this.btnChangeEmployee.Size = new System.Drawing.Size(161, 46);
            this.btnChangeEmployee.TabIndex = 37;
            this.btnChangeEmployee.Text = "Change Employee";
            this.btnChangeEmployee.UseVisualStyleBackColor = false;
            // 
            // btnCustInfo
            // 
            this.btnCustInfo.BackColor = System.Drawing.SystemColors.Info;
            this.btnCustInfo.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustInfo.Location = new System.Drawing.Point(544, 517);
            this.btnCustInfo.Margin = new System.Windows.Forms.Padding(4);
            this.btnCustInfo.Name = "btnCustInfo";
            this.btnCustInfo.Size = new System.Drawing.Size(161, 46);
            this.btnCustInfo.TabIndex = 36;
            this.btnCustInfo.Text = "Customer Information";
            this.btnCustInfo.UseVisualStyleBackColor = false;
            // 
            // btnLogout2
            // 
            this.btnLogout2.BackColor = System.Drawing.SystemColors.Info;
            this.btnLogout2.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout2.Location = new System.Drawing.Point(36, 570);
            this.btnLogout2.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout2.Name = "btnLogout2";
            this.btnLogout2.Size = new System.Drawing.Size(161, 46);
            this.btnLogout2.TabIndex = 38;
            this.btnLogout2.Text = "Main Menu";
            this.btnLogout2.UseVisualStyleBackColor = false;
            this.btnLogout2.Click += new System.EventHandler(this.btnLogout2_Click);
            // 
            // btnNextOrder
            // 
            this.btnNextOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnNextOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextOrder.Location = new System.Drawing.Point(375, 517);
            this.btnNextOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnNextOrder.Name = "btnNextOrder";
            this.btnNextOrder.Size = new System.Drawing.Size(161, 46);
            this.btnNextOrder.TabIndex = 35;
            this.btnNextOrder.Text = "Next Page";
            this.btnNextOrder.UseVisualStyleBackColor = false;
            this.btnNextOrder.Click += new System.EventHandler(this.btnNextOrder_Click);
            // 
            // btnPreviousOrder
            // 
            this.btnPreviousOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnPreviousOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousOrder.Location = new System.Drawing.Point(205, 517);
            this.btnPreviousOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnPreviousOrder.Name = "btnPreviousOrder";
            this.btnPreviousOrder.Size = new System.Drawing.Size(161, 46);
            this.btnPreviousOrder.TabIndex = 34;
            this.btnPreviousOrder.Text = "Previous Page";
            this.btnPreviousOrder.UseVisualStyleBackColor = false;
            this.btnPreviousOrder.Click += new System.EventHandler(this.btnPreviousOrder_Click);
            // 
            // btnDeleteOrder
            // 
            this.btnDeleteOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnDeleteOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteOrder.Location = new System.Drawing.Point(36, 517);
            this.btnDeleteOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnDeleteOrder.Name = "btnDeleteOrder";
            this.btnDeleteOrder.Size = new System.Drawing.Size(161, 46);
            this.btnDeleteOrder.TabIndex = 33;
            this.btnDeleteOrder.Text = "Delete Order";
            this.btnDeleteOrder.UseVisualStyleBackColor = false;
            // 
            // btnEditOrder
            // 
            this.btnEditOrder.BackColor = System.Drawing.SystemColors.Info;
            this.btnEditOrder.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditOrder.Location = new System.Drawing.Point(36, 464);
            this.btnEditOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnEditOrder.Name = "btnEditOrder";
            this.btnEditOrder.Size = new System.Drawing.Size(161, 46);
            this.btnEditOrder.TabIndex = 32;
            this.btnEditOrder.Text = "Edit Order";
            this.btnEditOrder.UseVisualStyleBackColor = false;
            // 
            // tabCustomerInformation
            // 
            this.tabCustomerInformation.BackColor = System.Drawing.Color.PowderBlue;
            this.tabCustomerInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabCustomerInformation.Controls.Add(this.btnReassignEmployee);
            this.tabCustomerInformation.Controls.Add(this.btnNewCust);
            this.tabCustomerInformation.Controls.Add(this.btnRemoveCust);
            this.tabCustomerInformation.Controls.Add(this.btnNextCust);
            this.tabCustomerInformation.Controls.Add(this.btnPreviousCust);
            this.tabCustomerInformation.Controls.Add(this.btnCancelCust);
            this.tabCustomerInformation.Controls.Add(this.btnSaveCust);
            this.tabCustomerInformation.Controls.Add(this.lblTitle);
            this.tabCustomerInformation.Controls.Add(this.pnlOne);
            this.tabCustomerInformation.Controls.Add(this.btnLogout1);
            this.tabCustomerInformation.Controls.Add(this.btnViewOrders);
            this.tabCustomerInformation.Controls.Add(this.btnEditCust);
            this.tabCustomerInformation.Location = new System.Drawing.Point(4, 38);
            this.tabCustomerInformation.Margin = new System.Windows.Forms.Padding(4);
            this.tabCustomerInformation.Name = "tabCustomerInformation";
            this.tabCustomerInformation.Padding = new System.Windows.Forms.Padding(4);
            this.tabCustomerInformation.Size = new System.Drawing.Size(745, 644);
            this.tabCustomerInformation.TabIndex = 0;
            this.tabCustomerInformation.Text = "Customer Information";
            // 
            // btnReassignEmployee
            // 
            this.btnReassignEmployee.BackColor = System.Drawing.Color.Beige;
            this.btnReassignEmployee.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReassignEmployee.Location = new System.Drawing.Point(284, 517);
            this.btnReassignEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.btnReassignEmployee.Name = "btnReassignEmployee";
            this.btnReassignEmployee.Size = new System.Drawing.Size(161, 46);
            this.btnReassignEmployee.TabIndex = 9;
            this.btnReassignEmployee.Text = "Reassign Employee";
            this.btnReassignEmployee.UseVisualStyleBackColor = false;
            // 
            // btnNewCust
            // 
            this.btnNewCust.BackColor = System.Drawing.Color.Beige;
            this.btnNewCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewCust.Location = new System.Drawing.Point(476, 517);
            this.btnNewCust.Margin = new System.Windows.Forms.Padding(4);
            this.btnNewCust.Name = "btnNewCust";
            this.btnNewCust.Size = new System.Drawing.Size(161, 46);
            this.btnNewCust.TabIndex = 10;
            this.btnNewCust.Text = "Add New Customer";
            this.btnNewCust.UseVisualStyleBackColor = false;
            // 
            // btnRemoveCust
            // 
            this.btnRemoveCust.BackColor = System.Drawing.Color.Beige;
            this.btnRemoveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveCust.Location = new System.Drawing.Point(476, 452);
            this.btnRemoveCust.Margin = new System.Windows.Forms.Padding(4);
            this.btnRemoveCust.Name = "btnRemoveCust";
            this.btnRemoveCust.Size = new System.Drawing.Size(161, 46);
            this.btnRemoveCust.TabIndex = 7;
            this.btnRemoveCust.Text = "Remove Customer";
            this.btnRemoveCust.UseVisualStyleBackColor = false;
            // 
            // btnNextCust
            // 
            this.btnNextCust.BackColor = System.Drawing.Color.Beige;
            this.btnNextCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextCust.Location = new System.Drawing.Point(476, 386);
            this.btnNextCust.Margin = new System.Windows.Forms.Padding(4);
            this.btnNextCust.Name = "btnNextCust";
            this.btnNextCust.Size = new System.Drawing.Size(161, 46);
            this.btnNextCust.TabIndex = 4;
            this.btnNextCust.Text = "Next Customer";
            this.btnNextCust.UseVisualStyleBackColor = false;
            this.btnNextCust.Click += new System.EventHandler(this.btnNextCust_Click);
            // 
            // btnPreviousCust
            // 
            this.btnPreviousCust.BackColor = System.Drawing.Color.Beige;
            this.btnPreviousCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousCust.Location = new System.Drawing.Point(284, 386);
            this.btnPreviousCust.Margin = new System.Windows.Forms.Padding(4);
            this.btnPreviousCust.Name = "btnPreviousCust";
            this.btnPreviousCust.Size = new System.Drawing.Size(161, 46);
            this.btnPreviousCust.TabIndex = 3;
            this.btnPreviousCust.Text = "Previous Customer";
            this.btnPreviousCust.UseVisualStyleBackColor = false;
            this.btnPreviousCust.Click += new System.EventHandler(this.btnPreviousCust_Click);
            // 
            // btnCancelCust
            // 
            this.btnCancelCust.BackColor = System.Drawing.Color.Beige;
            this.btnCancelCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelCust.Location = new System.Drawing.Point(99, 517);
            this.btnCancelCust.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelCust.Name = "btnCancelCust";
            this.btnCancelCust.Size = new System.Drawing.Size(161, 46);
            this.btnCancelCust.TabIndex = 8;
            this.btnCancelCust.Text = "Cancel";
            this.btnCancelCust.UseVisualStyleBackColor = false;
            // 
            // btnSaveCust
            // 
            this.btnSaveCust.BackColor = System.Drawing.Color.Beige;
            this.btnSaveCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCust.Location = new System.Drawing.Point(99, 452);
            this.btnSaveCust.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveCust.Name = "btnSaveCust";
            this.btnSaveCust.Size = new System.Drawing.Size(161, 46);
            this.btnSaveCust.TabIndex = 5;
            this.btnSaveCust.Text = "Save";
            this.btnSaveCust.UseVisualStyleBackColor = false;
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(99, 11);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(537, 44);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Customer Information";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlOne
            // 
            this.pnlOne.BackColor = System.Drawing.Color.Beige;
            this.pnlOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOne.Controls.Add(this.tbxECPC);
            this.pnlOne.Controls.Add(this.tbxECFax);
            this.pnlOne.Controls.Add(this.tbxECUser);
            this.pnlOne.Controls.Add(this.tbxECCountry);
            this.pnlOne.Controls.Add(this.tbxECCity);
            this.pnlOne.Controls.Add(this.tbxECAddress);
            this.pnlOne.Controls.Add(this.tbxECLName);
            this.pnlOne.Controls.Add(this.tbxECPhone);
            this.pnlOne.Controls.Add(this.tbxECFName);
            this.pnlOne.Controls.Add(this.tbxECID);
            this.pnlOne.Controls.Add(this.lbl1);
            this.pnlOne.Controls.Add(this.lbl2);
            this.pnlOne.Controls.Add(this.lbl3);
            this.pnlOne.Controls.Add(this.lbl4);
            this.pnlOne.Controls.Add(this.lbl5);
            this.pnlOne.Controls.Add(this.lbl6);
            this.pnlOne.Controls.Add(this.lbl7);
            this.pnlOne.Controls.Add(this.lbl8);
            this.pnlOne.Controls.Add(this.lbl9);
            this.pnlOne.Controls.Add(this.lbl10);
            this.pnlOne.Location = new System.Drawing.Point(99, 57);
            this.pnlOne.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlOne.Name = "pnlOne";
            this.pnlOne.Size = new System.Drawing.Size(537, 313);
            this.pnlOne.TabIndex = 1;
            // 
            // tbxECPC
            // 
            this.tbxECPC.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECPC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECPC.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECPC.Location = new System.Drawing.Point(147, 274);
            this.tbxECPC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECPC.Name = "tbxECPC";
            this.tbxECPC.Size = new System.Drawing.Size(367, 19);
            this.tbxECPC.TabIndex = 44;
            // 
            // tbxECFax
            // 
            this.tbxECFax.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECFax.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECFax.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECFax.Location = new System.Drawing.Point(147, 217);
            this.tbxECFax.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECFax.Name = "tbxECFax";
            this.tbxECFax.Size = new System.Drawing.Size(367, 19);
            this.tbxECFax.TabIndex = 43;
            // 
            // tbxECUser
            // 
            this.tbxECUser.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECUser.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECUser.Location = new System.Drawing.Point(147, 246);
            this.tbxECUser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECUser.Name = "tbxECUser";
            this.tbxECUser.Size = new System.Drawing.Size(367, 19);
            this.tbxECUser.TabIndex = 42;
            // 
            // tbxECCountry
            // 
            this.tbxECCountry.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECCountry.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECCountry.Location = new System.Drawing.Point(147, 190);
            this.tbxECCountry.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECCountry.Name = "tbxECCountry";
            this.tbxECCountry.Size = new System.Drawing.Size(367, 19);
            this.tbxECCountry.TabIndex = 41;
            // 
            // tbxECCity
            // 
            this.tbxECCity.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECCity.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECCity.Location = new System.Drawing.Point(147, 161);
            this.tbxECCity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECCity.Name = "tbxECCity";
            this.tbxECCity.Size = new System.Drawing.Size(367, 19);
            this.tbxECCity.TabIndex = 40;
            // 
            // tbxECAddress
            // 
            this.tbxECAddress.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECAddress.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECAddress.Location = new System.Drawing.Point(147, 133);
            this.tbxECAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECAddress.Name = "tbxECAddress";
            this.tbxECAddress.Size = new System.Drawing.Size(367, 19);
            this.tbxECAddress.TabIndex = 39;
            // 
            // tbxECLName
            // 
            this.tbxECLName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECLName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECLName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECLName.Location = new System.Drawing.Point(147, 76);
            this.tbxECLName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECLName.Name = "tbxECLName";
            this.tbxECLName.Size = new System.Drawing.Size(367, 19);
            this.tbxECLName.TabIndex = 38;
            // 
            // tbxECPhone
            // 
            this.tbxECPhone.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECPhone.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECPhone.Location = new System.Drawing.Point(147, 105);
            this.tbxECPhone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECPhone.Name = "tbxECPhone";
            this.tbxECPhone.Size = new System.Drawing.Size(367, 19);
            this.tbxECPhone.TabIndex = 37;
            // 
            // tbxECFName
            // 
            this.tbxECFName.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECFName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECFName.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECFName.Location = new System.Drawing.Point(147, 48);
            this.tbxECFName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECFName.Name = "tbxECFName";
            this.tbxECFName.Size = new System.Drawing.Size(367, 19);
            this.tbxECFName.TabIndex = 36;
            // 
            // tbxECID
            // 
            this.tbxECID.BackColor = System.Drawing.Color.LightCyan;
            this.tbxECID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxECID.Font = new System.Drawing.Font("Javanese Text", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxECID.Location = new System.Drawing.Point(147, 20);
            this.tbxECID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxECID.Name = "tbxECID";
            this.tbxECID.Size = new System.Drawing.Size(367, 19);
            this.tbxECID.TabIndex = 35;
            // 
            // lbl1
            // 
            this.lbl1.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(19, 14);
            this.lbl1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(121, 28);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Customer ID:";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl2
            // 
            this.lbl2.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(19, 42);
            this.lbl2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(121, 28);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "First Name:";
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl3
            // 
            this.lbl3.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(19, 70);
            this.lbl3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(121, 28);
            this.lbl3.TabIndex = 4;
            this.lbl3.Text = "Last Name:";
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl4
            // 
            this.lbl4.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.Location = new System.Drawing.Point(19, 98);
            this.lbl4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(121, 28);
            this.lbl4.TabIndex = 6;
            this.lbl4.Text = "Phone Number:";
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl5
            // 
            this.lbl5.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(19, 127);
            this.lbl5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(121, 28);
            this.lbl5.TabIndex = 8;
            this.lbl5.Text = "Address:";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl6
            // 
            this.lbl6.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.Location = new System.Drawing.Point(19, 155);
            this.lbl6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(121, 28);
            this.lbl6.TabIndex = 10;
            this.lbl6.Text = "City:";
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl7
            // 
            this.lbl7.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.Location = new System.Drawing.Point(19, 185);
            this.lbl7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(121, 28);
            this.lbl7.TabIndex = 12;
            this.lbl7.Text = "Country:";
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl8
            // 
            this.lbl8.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.Location = new System.Drawing.Point(19, 212);
            this.lbl8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(121, 28);
            this.lbl8.TabIndex = 14;
            this.lbl8.Text = "Fax:";
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl9
            // 
            this.lbl9.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.Location = new System.Drawing.Point(19, 240);
            this.lbl9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(121, 28);
            this.lbl9.TabIndex = 16;
            this.lbl9.Text = "User ID:";
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl10
            // 
            this.lbl10.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10.Location = new System.Drawing.Point(19, 270);
            this.lbl10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(121, 28);
            this.lbl10.TabIndex = 18;
            this.lbl10.Text = "Postal Code:";
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLogout1
            // 
            this.btnLogout1.BackColor = System.Drawing.Color.Beige;
            this.btnLogout1.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout1.Location = new System.Drawing.Point(8, 583);
            this.btnLogout1.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout1.Name = "btnLogout1";
            this.btnLogout1.Size = new System.Drawing.Size(161, 46);
            this.btnLogout1.TabIndex = 11;
            this.btnLogout1.Text = "Main Menu";
            this.btnLogout1.UseVisualStyleBackColor = false;
            this.btnLogout1.Click += new System.EventHandler(this.btnLogout1_Click);
            // 
            // btnViewOrders
            // 
            this.btnViewOrders.BackColor = System.Drawing.Color.Beige;
            this.btnViewOrders.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewOrders.Location = new System.Drawing.Point(284, 452);
            this.btnViewOrders.Margin = new System.Windows.Forms.Padding(4);
            this.btnViewOrders.Name = "btnViewOrders";
            this.btnViewOrders.Size = new System.Drawing.Size(161, 46);
            this.btnViewOrders.TabIndex = 6;
            this.btnViewOrders.Text = "View Orders";
            this.btnViewOrders.UseVisualStyleBackColor = false;
            // 
            // btnEditCust
            // 
            this.btnEditCust.BackColor = System.Drawing.Color.Beige;
            this.btnEditCust.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditCust.Location = new System.Drawing.Point(99, 386);
            this.btnEditCust.Margin = new System.Windows.Forms.Padding(4);
            this.btnEditCust.Name = "btnEditCust";
            this.btnEditCust.Size = new System.Drawing.Size(161, 46);
            this.btnEditCust.TabIndex = 2;
            this.btnEditCust.Text = "Change Information";
            this.btnEditCust.UseVisualStyleBackColor = false;
            // 
            // tbcOne
            // 
            this.tbcOne.Controls.Add(this.tabCustomerInformation);
            this.tbcOne.Controls.Add(this.tabCustomerOrders);
            this.tbcOne.Controls.Add(this.tabEmployeeInformation);
            this.tbcOne.Controls.Add(this.tabManagerInformation);
            this.tbcOne.Controls.Add(this.tabReportViewer);
            this.tbcOne.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcOne.Font = new System.Drawing.Font("Javanese Text", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcOne.Location = new System.Drawing.Point(0, 0);
            this.tbcOne.Margin = new System.Windows.Forms.Padding(4);
            this.tbcOne.Multiline = true;
            this.tbcOne.Name = "tbcOne";
            this.tbcOne.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tbcOne.SelectedIndex = 0;
            this.tbcOne.Size = new System.Drawing.Size(753, 686);
            this.tbcOne.TabIndex = 0;
            // 
            // tabReportViewer
            // 
            this.tabReportViewer.BackColor = System.Drawing.Color.PowderBlue;
            this.tabReportViewer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabReportViewer.Controls.Add(this.btnOrdersReport);
            this.tabReportViewer.Controls.Add(this.btnManagersReport);
            this.tabReportViewer.Controls.Add(this.btnEmployeeReport);
            this.tabReportViewer.Controls.Add(this.label2);
            this.tabReportViewer.Controls.Add(this.btnCustomerViewer);
            this.tabReportViewer.Location = new System.Drawing.Point(4, 38);
            this.tabReportViewer.Margin = new System.Windows.Forms.Padding(4);
            this.tabReportViewer.Name = "tabReportViewer";
            this.tabReportViewer.Padding = new System.Windows.Forms.Padding(4);
            this.tabReportViewer.Size = new System.Drawing.Size(745, 644);
            this.tabReportViewer.TabIndex = 4;
            this.tabReportViewer.Text = "Report Viewer";
            // 
            // btnCustomerViewer
            // 
            this.btnCustomerViewer.BackColor = System.Drawing.Color.Beige;
            this.btnCustomerViewer.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerViewer.Location = new System.Drawing.Point(228, 148);
            this.btnCustomerViewer.Margin = new System.Windows.Forms.Padding(4);
            this.btnCustomerViewer.Name = "btnCustomerViewer";
            this.btnCustomerViewer.Size = new System.Drawing.Size(285, 68);
            this.btnCustomerViewer.TabIndex = 14;
            this.btnCustomerViewer.Text = "Customer\'s Report";
            this.btnCustomerViewer.UseVisualStyleBackColor = false;
            this.btnCustomerViewer.Click += new System.EventHandler(this.btnCustomerViewer_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(117, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(537, 44);
            this.label2.TabIndex = 15;
            this.label2.Text = "Report Viewer";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnEmployeeReport
            // 
            this.btnEmployeeReport.BackColor = System.Drawing.Color.Beige;
            this.btnEmployeeReport.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeReport.Location = new System.Drawing.Point(228, 249);
            this.btnEmployeeReport.Margin = new System.Windows.Forms.Padding(4);
            this.btnEmployeeReport.Name = "btnEmployeeReport";
            this.btnEmployeeReport.Size = new System.Drawing.Size(285, 68);
            this.btnEmployeeReport.TabIndex = 16;
            this.btnEmployeeReport.Text = "Employee\'s Report";
            this.btnEmployeeReport.UseVisualStyleBackColor = false;
            this.btnEmployeeReport.Click += new System.EventHandler(this.btnEmployeeReport_Click);
            // 
            // btnManagersReport
            // 
            this.btnManagersReport.BackColor = System.Drawing.Color.Beige;
            this.btnManagersReport.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManagersReport.Location = new System.Drawing.Point(228, 360);
            this.btnManagersReport.Margin = new System.Windows.Forms.Padding(4);
            this.btnManagersReport.Name = "btnManagersReport";
            this.btnManagersReport.Size = new System.Drawing.Size(285, 68);
            this.btnManagersReport.TabIndex = 17;
            this.btnManagersReport.Text = "Manager\'s Report";
            this.btnManagersReport.UseVisualStyleBackColor = false;
            this.btnManagersReport.Click += new System.EventHandler(this.btnManagersReport_Click);
            // 
            // btnOrdersReport
            // 
            this.btnOrdersReport.BackColor = System.Drawing.Color.Beige;
            this.btnOrdersReport.Font = new System.Drawing.Font("Javanese Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrdersReport.Location = new System.Drawing.Point(228, 468);
            this.btnOrdersReport.Margin = new System.Windows.Forms.Padding(4);
            this.btnOrdersReport.Name = "btnOrdersReport";
            this.btnOrdersReport.Size = new System.Drawing.Size(285, 68);
            this.btnOrdersReport.TabIndex = 18;
            this.btnOrdersReport.Text = "Order\'s Report";
            this.btnOrdersReport.UseVisualStyleBackColor = false;
            this.btnOrdersReport.Click += new System.EventHandler(this.btnOrdersReport_Click);
            // 
            // frmManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(753, 686);
            this.Controls.Add(this.tbcOne);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmManager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manger Information";
            this.Load += new System.EventHandler(this.frmOrders_Load);
            this.tabManagerInformation.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabEmployeeInformation.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabCustomerOrders.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabCustomerInformation.ResumeLayout(false);
            this.pnlOne.ResumeLayout(false);
            this.pnlOne.PerformLayout();
            this.tbcOne.ResumeLayout(false);
            this.tabReportViewer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabManagerInformation;
        private System.Windows.Forms.Button btnManagerCancel;
        private System.Windows.Forms.Button btnManagerSave;
        private System.Windows.Forms.Button btnLogout4;
        private System.Windows.Forms.Button btnManagerEdit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbxMUID;
        private System.Windows.Forms.TextBox tbxMState;
        private System.Windows.Forms.TextBox tbxMCity;
        private System.Windows.Forms.TextBox tbxMAddress;
        private System.Windows.Forms.TextBox tbxMLName;
        private System.Windows.Forms.TextBox tbxMPhone;
        private System.Windows.Forms.TextBox tbxMFName;
        private System.Windows.Forms.TextBox tbxMID;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl36;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabEmployeeInformation;
        private System.Windows.Forms.Button btnRemoveEmployee;
        private System.Windows.Forms.Button btnNewEmployee;
        private System.Windows.Forms.Button btnNextEmp;
        private System.Windows.Forms.Button btnPreviousEmp;
        private System.Windows.Forms.Button btnEmpOrdersAssigned;
        private System.Windows.Forms.Button btnEmpCustomersAssigned;
        private System.Windows.Forms.Button btnCancelEmp;
        private System.Windows.Forms.Label lblTitle3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox tbxEUID;
        private System.Windows.Forms.TextBox tbxEState;
        private System.Windows.Forms.TextBox tbxECity;
        private System.Windows.Forms.TextBox tbxEAddress;
        private System.Windows.Forms.TextBox tbxELName;
        private System.Windows.Forms.TextBox tbxEPhone;
        private System.Windows.Forms.TextBox tbxEFName;
        private System.Windows.Forms.TextBox tbxEID;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Button btnLogout3;
        private System.Windows.Forms.Button btnSaveEmp;
        private System.Windows.Forms.Button btnEditEmp;
        private System.Windows.Forms.TabPage tabCustomerOrders;
        private System.Windows.Forms.Button btnCancelOrder;
        private System.Windows.Forms.Button btnSaveOrder;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbxEmployeeID;
        private System.Windows.Forms.TextBox tbxETotalPricing;
        private System.Windows.Forms.TextBox tbxEOPC;
        private System.Windows.Forms.TextBox tbxEProducts;
        private System.Windows.Forms.TextBox tbxEShipCountry;
        private System.Windows.Forms.TextBox tbxEShipCity;
        private System.Windows.Forms.TextBox tbxEShipAdd;
        private System.Windows.Forms.TextBox tbxEOrderDate;
        private System.Windows.Forms.TextBox tbxEShipDate;
        private System.Windows.Forms.TextBox tbxCOCID;
        private System.Windows.Forms.TextBox tbxECOID;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Button btnChangeEmployee;
        private System.Windows.Forms.Button btnCustInfo;
        private System.Windows.Forms.Button btnLogout2;
        private System.Windows.Forms.Button btnNextOrder;
        private System.Windows.Forms.Button btnPreviousOrder;
        private System.Windows.Forms.Button btnDeleteOrder;
        private System.Windows.Forms.Button btnEditOrder;
        private System.Windows.Forms.TabPage tabCustomerInformation;
        private System.Windows.Forms.Button btnReassignEmployee;
        private System.Windows.Forms.Button btnNewCust;
        private System.Windows.Forms.Button btnRemoveCust;
        private System.Windows.Forms.Button btnNextCust;
        private System.Windows.Forms.Button btnPreviousCust;
        private System.Windows.Forms.Button btnCancelCust;
        private System.Windows.Forms.Button btnSaveCust;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlOne;
        private System.Windows.Forms.TextBox tbxECPC;
        private System.Windows.Forms.TextBox tbxECFax;
        private System.Windows.Forms.TextBox tbxECUser;
        private System.Windows.Forms.TextBox tbxECCountry;
        private System.Windows.Forms.TextBox tbxECCity;
        private System.Windows.Forms.TextBox tbxECAddress;
        private System.Windows.Forms.TextBox tbxECLName;
        private System.Windows.Forms.TextBox tbxECPhone;
        private System.Windows.Forms.TextBox tbxECFName;
        private System.Windows.Forms.TextBox tbxECID;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Button btnLogout1;
        private System.Windows.Forms.Button btnViewOrders;
        private System.Windows.Forms.Button btnEditCust;
        private System.Windows.Forms.TabControl tbcOne;
        private System.Windows.Forms.TabPage tabReportViewer;
        private System.Windows.Forms.Button btnCustomerViewer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnOrdersReport;
        private System.Windows.Forms.Button btnManagersReport;
        private System.Windows.Forms.Button btnEmployeeReport;
    }
}