﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//added
using INEW2330_HomeFurniture;
using HomeFurniture;

namespace HomeFurniture
{
    public partial class frmCustomer : Form
    {
        // Create CurrencyManagers
        CurrencyManager customersManager;
        CurrencyManager ordersManager;

        public frmCustomer()
        {
            InitializeComponent();
        }
     
        private void frmCustomer_Load(object sender, EventArgs e)
        {
            // Call data loading methods
            loadCustomerData();
            loadOrdersData();

            // Set defaults
            btnSaveCust.Enabled = false;
            btnDeleteOrder.Enabled = false;
        }

        private void btnLogout2_Click(object sender, EventArgs e)
        {
            // Close form
            this.Hide();
        }
        private void btnLogout1_Click(object sender, EventArgs e)
        {
            // Close form
            this.Hide();
        }

        private void btnPreviousOrder_Click(object sender, EventArgs e)
        {
            // Move BACK a position
            ordersManager.Position--;
        }

        private void btnNextOrder_Click(object sender, EventArgs e)
        {
            // Move to NEXT a position
            ordersManager.Position++;
        }

        private void loadCustomerData()
        {
            // Add textboxes to ProgOps to use in OpenCustomerLogin()
            ProgOps.TbxCID = tbxCID;
            ProgOps.TbxCFName = tbxCFName;
            ProgOps.TbxCLName = tbxCLName;
            ProgOps.TbxCPhone = tbxCPhone;
            ProgOps.TbxCAddress = tbxCAddress;
            ProgOps.TbxCCity = tbxCCity;
            ProgOps.TbxCState = tbxCState;
            ProgOps.TbxCFAX = tbxCFax;
            ProgOps.TbxCUser = tbxCUser;

            // Fill in data
            ProgOps.OpenCustomerLogin("SELECT * FROM group5sp212330.Customer WHERE UserID LIKE '" + trackingName.userName + "'");

            // Establish CurrencyManager
            customersManager = (CurrencyManager)BindingContext[ProgOps.DTCustomer];
        }


        private void loadOrdersData()
        {
            // Add textboxes to ProgOps to use in OpenOrders()
            ProgOps.TbxOID = tbxCOID;
            ProgOps.TbxOCID = tbxCOCID;
            ProgOps.TbxODate = tbxCOD;
            ProgOps.TbxOShipDate = tbxCShipDate;
            ProgOps.TbxOShipAdd = tbxCShipAdd;
            ProgOps.TbxOShipCity = tbxCShipCity;
            ProgOps.TbxOCountry = tbxCShipCountry;
            ProgOps.TbxOShipPC = tbxCOPC;
            //ProgOps.tbxO = tbxCOPC;
            // tbxCProduct
            // tbxCPrice
            ProgOps.TbxOEID = tbxCEmpID;

            // Fill in data
            ProgOps.OpenOrders("SELECT * FROM group5sp212330.Orders, group5sp212330.Customer WHERE UserID LIKE '" + trackingName.userName + "'");

            // Establish CurrencyManager
            ordersManager = (CurrencyManager)BindingContext[ProgOps.DTOrders];
        }
    }
}
